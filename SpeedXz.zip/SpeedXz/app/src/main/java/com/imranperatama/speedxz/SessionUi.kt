package com.imranperatama.speedxz

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SessionBanner(vm: AppViewModel) {
    if (SessionState.active) {
        Panel {
            Txt("SESI AKTIF", size = 11, color = Good, weight = FontWeight.Bold, spacing = 2.5f)
            Txt(SessionState.label, size = 22, weight = FontWeight.Black, italic = true)
            Spacer(Modifier.height(4.dp))
            Txt(
                "Aplikasi non-sistem ditutup berkala. Di dalam game, tarik garis merah di tepi layar atau ketuk gelembung Xz untuk membuka panel.",
                size = 12, color = Muted
            )
            Spacer(Modifier.height(10.dp))
            SlantButton("AKHIRI SESI", Modifier.fillMaxWidth(), small = true) { vm.restoreDefaults() }
        }
    }
}

@Composable
fun SessionHistory(vm: AppViewModel) {
    val list = remember(SessionState.version) { vm.loadSessions() }
    if (list.isNotEmpty()) {
        val fmt = remember { SimpleDateFormat("dd MMM HH:mm", Locale("id", "ID")) }
        Panel {
            Txt("RIWAYAT SESI", size = 11, color = RedGlow, weight = FontWeight.Bold, spacing = 2.5f)
            Txt("Bandingkan hanya sesi dengan kondisi yang mirip.", size = 12, color = Muted)
            Spacer(Modifier.height(8.dp))
            list.take(5).forEach { r ->
                val fps = if (r.avgFps >= 0) "${r.avgFps}" else "N/A"
                Txt("${r.label}  ${fmt.format(Date(r.startMs))}", size = 14, weight = FontWeight.Bold)
                Txt(
                    "${r.durSec / 60} mnt | RAM bebas ${r.avgFreeMb} MB | FPS $fps | suhu maks ${String.format("%.1f", r.maxTemp)} C | ditutup ${r.killed}",
                    size = 12, color = Muted
                )
                Spacer(Modifier.height(6.dp))
            }
        }
    }
}
