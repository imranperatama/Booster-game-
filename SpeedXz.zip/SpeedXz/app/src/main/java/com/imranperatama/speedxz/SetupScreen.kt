package com.imranperatama.speedxz

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
private fun Step(
    n: Int,
    title: String,
    desc: String,
    done: Boolean,
    action: String,
    onClick: () -> Unit
) {
    Panel {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                Modifier.clip(SlantShape(6f)).background(if (done) Good else Red)
                    .padding(horizontal = 14.dp, vertical = 4.dp)
            ) {
                Txt(if (done) "OK" else n.toString(), size = 14, color = if (done) Bg else TextMain, weight = FontWeight.Black, italic = true)
            }
            Txt(title, Modifier.weight(1f), size = 16, weight = FontWeight.Bold)
        }
        Spacer(Modifier.height(6.dp))
        Txt(desc, size = 13, color = Muted)
        Spacer(Modifier.height(10.dp))
        SlantButton(action, Modifier.fillMaxWidth(), filled = !done, small = true) { onClick() }
    }
}

@Composable
fun SetupScreen(vm: AppViewModel) {
    val ready = vm.shzReady
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenTitle("HUBUNGKAN", "Ikuti urutan ini sekali saja. Status berubah sendiri saat kamu kembali ke sini.")

        Panel {
            Txt(
                if (ready) "SHIZUKU TERHUBUNG" else "SHIZUKU BELUM TERHUBUNG",
                size = 18, color = if (ready) Good else Warn, weight = FontWeight.Black, italic = true
            )
            Spacer(Modifier.height(4.dp))
            Txt(
                "Tanpa Shizuku, Boost hanya lewat Android biasa dan beberapa tombol membuka pengaturan HP. " +
                    "Dengan Shizuku, Boost menutup aplikasi sungguhan, Mode Game dan Pembersih jalan penuh.",
                size = 13, color = Muted
            )
            Spacer(Modifier.height(10.dp))
            SlantButton("NYALAKAN DEBUG OTOMATIS", Modifier.fillMaxWidth()) { vm.autoEnable() }
            Spacer(Modifier.height(4.dp))
            Txt("Berfungsi setelah langkah 6. Debug nirkabel tetap butuh Wi-Fi tersambung.", size = 12, color = Muted)
        }

        Step(
            1, "Pasang Shizuku",
            "Aplikasi gratis yang memberi izin sistem ke aplikasi lain. Cari Shizuku di Play Store.",
            vm.shzInstalled, if (vm.shzInstalled) "BUKA SHIZUKU" else "UNDUH SHIZUKU"
        ) { vm.openShizuku() }

        Step(
            2, "Aktifkan Opsi Pengembang",
            "Buka Tentang ponsel, lalu ketuk Nomor build sebanyak 7 kali. Di beberapa HP letaknya di Informasi perangkat lunak.",
            vm.devOn, if (vm.devOn) "BUKA OPSI PENGEMBANG" else "BUKA TENTANG PONSEL"
        ) { vm.openSettings(if (vm.devOn) "dev" else "about") }

        Step(
            3, "Nyalakan Debug Nirkabel",
            "Sambungkan HP ke Wi-Fi. Di Opsi pengembang, nyalakan Debug nirkabel. Jika HP tidak punya, nyalakan Debug USB.",
            vm.wifiOn || vm.usbOn, "BUKA DEBUG NIRKABEL"
        ) { vm.openSettings("wifi") }

        Step(
            4, "Mulai Shizuku",
            "Di aplikasi Shizuku pilih Mulai lewat Debug nirkabel. Saat diminta, buka Pairing dan masukkan kode dari notifikasi. Cukup sekali.",
            vm.shzRunning, "BUKA SHIZUKU"
        ) { vm.openShizuku() }

        Step(
            5, "Izinkan Speed Xz",
            "Setelah Shizuku berjalan, tekan tombol ini lalu pilih Izinkan.",
            vm.shzGranted, "BERI IZIN"
        ) { vm.requestShizuku() }

        Step(
            6, "Nyala otomatis (sekali)",
            "Beri Speed Xz izin pengaturan aman. Setelah itu Opsi pengembang dan Debug bisa dinyalakan dari satu tombol, " +
                "dan di Android 13 ke atas Shizuku bisa mulai sendiri setelah HP restart (atur di aplikasi Shizuku).",
            vm.secureOk, "BERI IZIN OTOMATIS"
        ) { vm.grantAuto() }

        Step(
            7, "Jendela mengambang",
            "Izin Tampil di atas aplikasi lain, untuk jendela Xz yang muncul saat main game. Langkah 6 sudah memberikannya otomatis. " +
                "Tanpa izin ini game tetap diboost, hanya tidak ada jendela.",
            vm.overlayOk, if (vm.shzReady) "BERI IZIN JENDELA" else "BUKA IZIN JENDELA"
        ) { vm.openOverlaySettings() }

        Panel {
            Txt("CARA LAIN: LEWAT KOMPUTER", size = 11, color = RedGlow, weight = FontWeight.Bold, spacing = 2.5f)
            Spacer(Modifier.height(4.dp))
            Txt("Sambungkan HP ke komputer dengan Debug USB, lalu jalankan perintah ini:", size = 13, color = Muted)
            Spacer(Modifier.height(6.dp))
            Txt(vm.adbCommand, size = 12, color = RedGlow, weight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            SlantButton("SALIN PERINTAH", Modifier.fillMaxWidth(), filled = false, small = true) { vm.copy(vm.adbCommand) }
        }

        Panel {
            Txt("TENTANG", size = 11, color = RedGlow, weight = FontWeight.Bold, spacing = 2.5f)
            Txt("Speed Xz x Imran Peratama", size = 18, weight = FontWeight.Black, italic = true)
            Txt("Semua data dibaca dan diproses di HP ini. Tidak ada yang dikirim ke server.", size = 12, color = Muted)
            Spacer(Modifier.height(10.dp))
            SlantButton("PUTAR INTRO LAGI", Modifier.fillMaxWidth(), filled = false, small = true) { vm.replayIntro() }
        }
        Spacer(Modifier.height(12.dp))
    }
}
