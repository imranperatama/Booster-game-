package com.imranperatama.speedxz

import android.Manifest
import android.app.SearchManager
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.KeyEvent
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class PlayResult(val ok: Boolean, val msg: String, val now: String)

/**
 * Pemutar musik untuk Mode Bantai. Dua jalur resmi Android, tanpa API key dan tanpa mengambil lagu dari situs:
 * 1. Lagu yang ada di HP (MediaStore), diputar sendiri oleh Speed Xz.
 * 2. Jika tidak ada di HP: minta aplikasi musik yang sudah terpasang (Spotify, YouTube Music, dll)
 *    memutar lagu itu lewat perintah standar Android "putar dari pencarian", lalu game dikembalikan ke depan.
 */
object Music {
    private class Track(val id: Long, val title: String, val artist: String, val url: String = "")

    private val APPS = listOf(
        "com.spotify.music" to "Spotify",
        "com.google.android.apps.youtube.music" to "YouTube Music",
        "com.bytedance.resso" to "Resso",
        "com.tencent.ibg.joox" to "JOOX",
        "deezer.android.app" to "Deezer",
        "com.apple.android.music" to "Apple Music",
        "com.soundcloud.android" to "SoundCloud",
        "com.amazon.mp3" to "Amazon Music"
    )

    private val main = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var queue: List<Track> = emptyList()
    private var pos = 0
    private var focus: AudioFocusRequest? = null
    private var external = false

    fun audioPerm(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    fun hasAudioPerm(ctx: Context): Boolean =
        ctx.checkSelfPermission(audioPerm()) == PackageManager.PERMISSION_GRANTED

    private fun label(t: Track): String =
        if (t.artist.isBlank() || t.artist == "<unknown>") t.title else t.title + " - " + t.artist

    private fun findLocal(ctx: Context, query: String): List<Track> {
        if (!hasAudioPerm(ctx)) return emptyList()
        val q = query.lowercase()
        val tokens = q.split(Regex("\\s+")).filter { it.length >= 2 }.take(5)
        if (tokens.isEmpty()) return emptyList()
        val sel = StringBuilder("is_music != 0")
        val args = ArrayList<String>()
        for (t in tokens) {
            sel.append(" AND (title LIKE ? OR artist LIKE ?)")
            args.add("%" + t + "%")
            args.add("%" + t + "%")
        }
        val out = ArrayList<Track>()
        try {
            val c = ctx.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST),
                sel.toString(), args.toTypedArray(), "title ASC"
            )
            if (c != null) {
                while (c.moveToNext() && out.size < 40) {
                    out.add(Track(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: ""))
                }
                c.close()
            }
        } catch (e: Throwable) {
        }
        out.sortBy { if (it.title.lowercase() == q) 0 else 1 }
        return out
    }

    private fun attrs(): AudioAttributes =
        AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()

    private fun requestFocus(ctx: Context) {
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(attrs())
                .setOnAudioFocusChangeListener { change ->
                    if (change == AudioManager.AUDIOFOCUS_LOSS) {
                        try {
                            player?.pause()
                        } catch (e: Throwable) {
                        }
                    }
                }
                .build()
            focus = req
            am.requestAudioFocus(req)
        } catch (e: Throwable) {
        }
    }

    private fun releasePlayer() {
        val p = player
        player = null
        if (p != null) {
            try {
                p.release()
            } catch (e: Throwable) {
            }
        }
    }

    private fun startTrack(ctx: Context, i: Int): Boolean {
        val t = queue.getOrNull(i) ?: return false
        pos = i
        releasePlayer()
        return try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(attrs())
            if (t.url.isNotEmpty()) mp.setDataSource(t.url)
            else mp.setDataSource(ctx, ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, t.id))
            mp.setOnPreparedListener { it.start() }
            mp.setOnCompletionListener { next(ctx) }
            mp.setOnErrorListener { _, _, _ ->
                releasePlayer()
                true
            }
            mp.prepareAsync()
            player = mp
            requestFocus(ctx)
            true
        } catch (e: Throwable) {
            false
        }
    }

    private fun key(ctx: Context, code: Int) {
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        } catch (e: Throwable) {
        }
    }

    private fun installed(ctx: Context, pkg: String): Boolean = try {
        ctx.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: Throwable) {
        false
    }

    /** Cari di HP dulu, kalau tidak ada minta aplikasi musik terpasang. */
    fun play(ctx: Context, query: String, game: String): PlayResult {
        val q = query.trim()
        if (q.isEmpty()) return PlayResult(false, "Judul lagunya kosong.", "")
        val local = findLocal(ctx, q)
        if (local.isNotEmpty()) {
            external = false
            queue = local
            return if (startTrack(ctx, 0)) {
                PlayResult(true, "Memutar dari HP: " + label(local[0]), "HP: " + label(local[0]))
            } else {
                PlayResult(false, "Lagu ketemu di HP tapi gagal diputar.", "")
            }
        }
        val aud = findAudius(q)
        if (aud.isNotEmpty()) {
            external = false
            queue = aud
            return if (startTrack(ctx, 0)) {
                PlayResult(true, "Memutar dari internet: " + label(aud[0]), "Audius: " + label(aud[0]))
            } else {
                PlayResult(false, "Lagu ketemu tapi gagal diputar. Cek internet.", "")
            }
        }
        val cid = GameEngine.prefs(ctx).getString("jamendo_id", "")?.trim() ?: ""
        if (cid.isNotEmpty()) {
            val net = findJamendo(cid, q)
            if (net.isNotEmpty()) {
                external = false
                queue = net
                return if (startTrack(ctx, 0)) {
                    PlayResult(true, "Memutar dari Jamendo: " + label(net[0]), "Jamendo: " + label(net[0]))
                } else {
                    PlayResult(false, "Lagu ketemu di Jamendo tapi gagal diputar. Cek internet.", "")
                }
            }
        }
        // App musik lain hanya dipakai jika kamu memilihnya sendiri (music_pkg); bawaan: tidak.
        if ((GameEngine.prefs(ctx).getString("music_pkg", "") ?: "").isNotEmpty()) return playExternal(ctx, q, game)
        val why = if (cid.isEmpty()) "Lagu \"$q\" tidak ketemu di HP maupun Audius (isinya musik independen, lagu band besar biasanya tidak ada). Opsional: isi Client ID Jamendo di tab SETUP untuk sumber tambahan."
        else "Lagu \"$q\" tidak ketemu di HP, Audius, maupun Jamendo (isinya musik independen, lagu band besar biasanya tidak ada). Coba judul atau artis lain."
        return PlayResult(false, why, "")
    }

    /** Audius: musik gratis tanpa iklan dan tanpa API key. Isinya musisi independen. */
    private fun findAudius(q: String): List<Track> {
        val out = ArrayList<Track>()
        try {
            val u = "https://api.audius.co/v1/tracks/search?app_name=speedxz&limit=10&query=" + URLEncoder.encode(q, "UTF-8")
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            val body = c.inputStream.bufferedReader().use { it.readText() }
            val arr = JSONObject(body).optJSONArray("data")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val id = o.optString("id")
                    if (id.isEmpty() || o.optBoolean("is_streamable", true).not()) continue
                    val who = o.optJSONObject("user")?.optString("name") ?: ""
                    out.add(Track(0L, o.optString("title"), who, "https://api.audius.co/v1/tracks/" + id + "/stream?app_name=speedxz"))
                }
            }
        } catch (e: Throwable) {
        }
        return out
    }

    /** Jamendo: musik berlisensi bebas, gratis, tanpa iklan. Butuh client_id gratis dari devportal.jamendo.com. */
    private fun findJamendo(cid: String, q: String): List<Track> {
        val out = ArrayList<Track>()
        try {
            val u = "https://api.jamendo.com/v3.0/tracks/?client_id=" + URLEncoder.encode(cid, "UTF-8") +
                "&format=json&limit=10&audioformat=mp32&search=" + URLEncoder.encode(q, "UTF-8")
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            val body = c.inputStream.bufferedReader().use { it.readText() }
            val arr = JSONObject(body).optJSONArray("results")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val a = o.optString("audio")
                    if (a.startsWith("http")) out.add(Track(0L, o.optString("name"), o.optString("artist_name"), a))
                }
            }
        } catch (e: Throwable) {
        }
        return out
    }

    private fun playExternal(ctx: Context, q: String, game: String): PlayResult {
        val pref = GameEngine.prefs(ctx).getString("music_pkg", "") ?: ""
        val have = APPS.filter { installed(ctx, it.first) }
        val chosen = have.firstOrNull { it.first == pref } ?: have.firstOrNull()
        if (chosen == null) {
            val why = if (hasAudioPerm(ctx)) "Tidak ada lagu \"$q\" di HP dan belum ada aplikasi musik terpasang (Spotify, YouTube Music, dll)."
            else "Izin musik HP belum diberikan (tab SETUP, langkah 10) dan belum ada aplikasi musik terpasang."
            return PlayResult(false, why, "")
        }
        val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
        i.setPackage(chosen.first)
        i.putExtra(SearchManager.QUERY, q)
        i.putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
        i.putExtra(MediaStore.EXTRA_MEDIA_TITLE, q)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(i)
        } catch (e: Throwable) {
            return PlayResult(false, chosen.second + " menolak perintah putar. Buka dan putar manual.", "")
        }
        releasePlayer()
        external = true
        if (game.isNotEmpty()) {
            main.postDelayed({
                try {
                    val back = ctx.packageManager.getLaunchIntentForPackage(game)
                    if (back != null) {
                        back.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                        ctx.startActivity(back)
                    }
                } catch (e: Throwable) {
                }
            }, 1800L)
        }
        return PlayResult(
            true,
            "Meminta " + chosen.second + " memutar \"" + q + "\". Game dikembalikan ke depan. Kalau lagunya salah, ketik judul lengkap beserta artisnya.",
            chosen.second + ": " + q
        )
    }

    fun pause(ctx: Context): String {
        val mp = player
        if (mp != null && !external) {
            try {
                mp.pause()
            } catch (e: Throwable) {
            }
            return "Lagu dijeda."
        }
        key(ctx, KeyEvent.KEYCODE_MEDIA_PAUSE)
        return "Perintah jeda dikirim ke aplikasi musik."
    }

    fun resume(ctx: Context): String {
        val mp = player
        if (mp != null && !external) {
            try {
                mp.start()
            } catch (e: Throwable) {
            }
            return "Lagu dilanjutkan."
        }
        key(ctx, KeyEvent.KEYCODE_MEDIA_PLAY)
        return "Perintah lanjut dikirim ke aplikasi musik."
    }

    fun toggle(ctx: Context): String {
        val mp = player
        if (mp != null && !external) {
            return try {
                if (mp.isPlaying) pause(ctx) else resume(ctx)
            } catch (e: Throwable) {
                "Pemutar tidak siap."
            }
        }
        key(ctx, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
        return "Perintah jeda atau lanjut dikirim ke aplikasi musik."
    }

    fun next(ctx: Context): String {
        if (!external && queue.isNotEmpty()) {
            val n = (pos + 1) % queue.size
            return if (startTrack(ctx, n)) "Berikutnya: " + label(queue[n]) else "Gagal memutar lagu berikutnya."
        }
        key(ctx, KeyEvent.KEYCODE_MEDIA_NEXT)
        return "Perintah lagu berikutnya dikirim."
    }

    fun prev(ctx: Context): String {
        if (!external && queue.isNotEmpty()) {
            val n = if (pos - 1 < 0) queue.size - 1 else pos - 1
            return if (startTrack(ctx, n)) "Sebelumnya: " + label(queue[n]) else "Gagal memutar lagu sebelumnya."
        }
        key(ctx, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
        return "Perintah lagu sebelumnya dikirim."
    }

    /** Hentikan pemutar sendiri dan lepaskan fokus audio. Dipanggil saat sesi game berakhir. */
    fun stop(ctx: Context): String {
        releasePlayer()
        queue = emptyList()
        try {
            val f = focus
            if (f != null) {
                (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).abandonAudioFocusRequest(f)
            }
        } catch (e: Throwable) {
        }
        focus = null
        if (external) key(ctx, KeyEvent.KEYCODE_MEDIA_PAUSE)
        external = false
        return "Musik berhenti."
    }
}
