package com.imranperatama.speedxz

/** Perintah yang dikenali dari ketikan di chat jendela Xz. Jalan tanpa AI, jadi tetap bisa walau API key habis. */
class Cmd(val type: String, val arg: String = "", val alt: String = "")

object CmdParser {
    private val filler = Regex("\\s+(dong|donk|ya|yah|bang|bro|sekarang|aja|saja|deh|please|plis)$")
    private val punct = Regex("[.!?]+$")
    private val resume = Regex("^(lanjut(kan)?|putar(kan)?|play|setel(kan)?|mainkan)(\\s+(lagu|musik))?(nya)?$")
    private val pause = Regex("^(jeda|pause|stop|berhenti|matikan|hentikan)(\\s+dulu)?(\\s+(lagu|musik)(nya)?)?$")
    private val next = Regex("^((lagu|musik)\\s+)?(berikutnya|selanjutnya|next|skip|ganti lagu|lagu lain)$|^(putar|putarkan)\\s+(lagu\\s+)?(berikutnya|selanjutnya)$")
    private val prev = Regex("^((lagu|musik)\\s+)?(sebelumnya|prev|previous)$")
    private val play = Regex("^(tolong\\s+)?(putar(kan)?|setel(kan)?|pasang(kan)?|mainkan|play|dengerin|denger)\\s*(in)?\\s*(saya|aku|gua|gue|kan)?\\s*(lagu|musik|lagunya)?\\s*(berjudul|judul)?\\s*(.+)$")
    private val bantai = Regex("^(aktifkan |nyalakan |mulai )?mode bantai( on| aktif)?$")
    private val lesson = Regex("^((aku|saya|gua|gue|tadi) )*(kalah|menang|mati|gagal|kebunuh|ketembak|dibantai)\\b.*$")
    private val note = Regex("^ingat( ini)?[: ]+.+$")

    private fun clean(s: String): String {
        var t = s.trim().trim('"', '\'', '“', '”')
        while (true) {
            val n = filler.replace(t, "").trim()
            if (n == t) break
            t = n
        }
        return t
    }

    fun parse(text: String): Cmd? {
        val t = punct.replace(text.trim().lowercase().replace(Regex("\\s+"), " "), "").trim()
        if (t.isEmpty()) return null
        val base = clean(t)
        if (bantai.matches(base)) return Cmd("bantai")
        if (pause.matches(base)) return Cmd("pause")
        if (next.matches(base)) return Cmd("next")
        if (prev.matches(base)) return Cmd("prev")
        if (resume.matches(base)) return Cmd("resume")
        val m = play.find(base)
        if (m != null) {
            val raw = clean(m.groupValues[m.groupValues.size - 1])
            val parts = raw.split(Regex("\\s+(atau|or)\\s+|\\s*,\\s*")).map { clean(it) }.filter { it.isNotEmpty() }
            if (parts.isNotEmpty()) return Cmd("play", parts[0], if (parts.size > 1) parts[1] else "")
        }
        if (lesson.matches(t) && (t.length >= 15 || t.contains("karena"))) {
            return Cmd("lesson", text.trim(), if (t.contains("menang")) "menang" else "kalah")
        }
        if (note.matches(t)) return Cmd("lesson", text.trim(), "catatan")
        return null
    }
}
