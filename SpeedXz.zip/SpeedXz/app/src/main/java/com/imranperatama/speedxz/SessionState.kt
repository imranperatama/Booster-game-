package com.imranperatama.speedxz

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

/** Status sesi game yang bisa diamati UI. Diisi oleh GameService. */
object SessionState {
    var pkg by mutableStateOf("")
    var label by mutableStateOf("")
    var version by mutableStateOf(0)
    val active: Boolean get() = pkg.isNotEmpty()
}

data class SessionRec(
    val label: String,
    val startMs: Long,
    val durSec: Int,
    val avgFreeMb: Int,
    val maxTemp: Double,
    val avgFps: Int,
    val killed: Int
)

/** Riwayat 20 sesi terakhir, disimpan lokal di HP. */
object SessionLog {
    private const val KEY = "sessions"

    fun load(ctx: Context): List<SessionRec> {
        val raw = GameEngine.prefs(ctx).getString(KEY, null) ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                SessionRec(
                    o.optString("label"),
                    o.optLong("start"),
                    o.optInt("dur"),
                    o.optInt("free"),
                    o.optDouble("temp"),
                    o.optInt("fps", -1),
                    o.optInt("killed")
                )
            }
        } catch (e: Throwable) {
            emptyList()
        }
    }

    fun add(ctx: Context, r: SessionRec) {
        val list = (listOf(r) + load(ctx)).take(20)
        val a = JSONArray()
        for (s in list) {
            val o = JSONObject()
            o.put("label", s.label)
            o.put("start", s.startMs)
            o.put("dur", s.durSec)
            o.put("free", s.avgFreeMb)
            o.put("temp", s.maxTemp)
            o.put("fps", s.avgFps)
            o.put("killed", s.killed)
            a.put(o)
        }
        GameEngine.prefs(ctx).edit().putString(KEY, a.toString()).apply()
    }
}
