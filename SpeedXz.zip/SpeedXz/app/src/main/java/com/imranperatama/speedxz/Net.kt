package com.imranperatama.speedxz

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.telephony.TelephonyManager
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

/** kind: wifi, cell, none, unknown. level: 0 sampai 4, atau -1 jika tidak diketahui. */
class NetInfo(val kind: String, val level: Int, val rssi: Int, val label: String)

/** Pembacaan jaringan dan ping. Tanpa izin lokasi: yang dibaca hanya kekuatan sinyal, bukan nama jaringan. */
object Net {
    private const val PING_HOST = "8.8.8.8"

    private fun wifiLevel(rssi: Int): Int = when {
        rssi >= -55 -> 4
        rssi >= -65 -> 3
        rssi >= -75 -> 2
        rssi >= -85 -> 1
        else -> 0
    }

    private fun cellLevel(ctx: Context): Int {
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
                val s = tm.signalStrength
                if (s != null) return s.level
            }
        } catch (e: Throwable) {
        }
        if (Sh.granted()) {
            val r = Sh.run("dumpsys telephony.registry | grep -o -m1 'level=[0-9]'")
            val m = Regex("level=([0-9])").find(r.out)
            if (m != null) return m.groupValues[1].toInt().coerceIn(0, 4)
        }
        return -1
    }

    @Suppress("DEPRECATION")
    fun read(ctx: Context): NetInfo {
        try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val net = cm.activeNetwork ?: return NetInfo("none", -1, 0, "Offline")
            val caps = cm.getNetworkCapabilities(net) ?: return NetInfo("none", -1, 0, "Offline")
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                val info = wm.connectionInfo
                val rssi = info?.rssi ?: -127
                val lvl = wifiLevel(rssi)
                return NetInfo("wifi", lvl, rssi, "Wi-Fi $lvl/4 ($rssi dBm)")
            }
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                val lvl = cellLevel(ctx)
                return NetInfo("cell", lvl, 0, if (lvl >= 0) "Seluler $lvl/4" else "Seluler")
            }
            return NetInfo("unknown", -1, 0, "Terhubung")
        } catch (e: Throwable) {
            return NetInfo("unknown", -1, 0, "N/A")
        }
    }

    fun pingMs(): Int = try {
        val p = ProcessBuilder("ping", "-c", "1", "-W", "1", PING_HOST).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().use { it.readText() }
        p.waitFor(3, TimeUnit.SECONDS)
        val m = Regex("time=([0-9.]+)").find(out)
        if (m != null) m.groupValues[1].toDouble().roundToInt() else -1
    } catch (e: Throwable) {
        -1
    }

    /** Rata-rata beberapa ping. -1 jika semuanya gagal. */
    fun pingAvg(n: Int): Int {
        var sum = 0
        var cnt = 0
        for (i in 0 until n) {
            val v = pingMs()
            if (v >= 0) {
                sum += v
                cnt++
            }
        }
        return if (cnt > 0) sum / cnt else -1
    }
}
