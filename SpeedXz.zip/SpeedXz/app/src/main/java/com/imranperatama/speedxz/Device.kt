package com.imranperatama.speedxz

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.view.Display

data class DeviceFacts(
    val name: String,
    val codename: String,
    val android: String,
    val chip: String,
    val cores: Int,
    val hz: Int,
    val maxHz: Int
)

data class Batt(
    val level: Int = 0,
    val temp: Double = 0.0,
    val charging: Boolean = false,
    val health: String = "-",
    val voltage: Int = 0
)

object Device {
    fun facts(ctx: Context): DeviceFacts {
        val man = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        val name = if (Build.MODEL.startsWith(Build.MANUFACTURER, ignoreCase = true)) Build.MODEL else "$man ${Build.MODEL}"
        val chip = if (Build.VERSION.SDK_INT >= 31 &&
            Build.SOC_MODEL.isNotBlank() && Build.SOC_MODEL != Build.UNKNOWN
        ) {
            "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}".replace(Build.UNKNOWN, "").trim()
        } else {
            Build.HARDWARE
        }
        var hz = 60
        var maxHz = 60
        try {
            val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            val d = dm.getDisplay(Display.DEFAULT_DISPLAY)
            hz = d.refreshRate.toInt()
            maxHz = d.supportedModes.maxOfOrNull { it.refreshRate.toInt() } ?: hz
        } catch (e: Throwable) {
        }
        return DeviceFacts(
            name = name,
            codename = Build.DEVICE,
            android = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            chip = chip,
            cores = Runtime.getRuntime().availableProcessors(),
            hz = hz,
            maxHz = maxHz
        )
    }

    /** total dan tersedia, dalam MB */
    fun memory(ctx: Context): Pair<Long, Long> {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return Pair(mi.totalMem / 1048576L, mi.availMem / 1048576L)
    }

    /** total dan bebas, dalam GB */
    fun storage(): Pair<Double, Double> {
        val st = StatFs(Environment.getDataDirectory().path)
        val total = st.blockCountLong * st.blockSizeLong
        val free = st.availableBlocksLong * st.blockSizeLong
        return Pair(total / 1073741824.0, free / 1073741824.0)
    }

    fun battery(ctx: Context): Batt {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return Batt()
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        val health = when (i.getIntExtra(BatteryManager.EXTRA_HEALTH, 0)) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Bagus"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Terlalu panas"
            BatteryManager.BATTERY_HEALTH_COLD -> "Terlalu dingin"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Rusak"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Tegangan lebih"
            else -> "Tidak diketahui"
        }
        return Batt(
            level = pct,
            temp = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0,
            charging = charging,
            health = health,
            voltage = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
        )
    }
}
