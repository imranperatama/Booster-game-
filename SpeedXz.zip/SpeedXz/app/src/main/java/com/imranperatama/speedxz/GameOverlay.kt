package com.imranperatama.speedxz

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt

data class LiveStats(
    val fps: Int,
    val cpu: Int,
    val freeMb: Long,
    val temp: Double,
    val zone: Double,
    val thermal: String,
    val pingMs: Int,
    val elapsedSec: Int,
    val killed: Int
)

class OverlayActions(
    val boost: () -> Unit,
    val dnd: () -> Unit,
    val dim: () -> Unit,
    val clean: () -> Unit,
    val ai: (String) -> Unit,
    val end: () -> Unit
)

/** Jajar genjang miring, bentuk khas Speed Xz, untuk latar panel dan tombol. */
class SlantDrawable(
    private val fill: Int,
    private val stroke: Int,
    private val slantPx: Float,
    private val strokePx: Float
) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    override fun draw(canvas: Canvas) {
        val r = bounds
        val s = min(slantPx, r.width() / 3f)
        val inset = strokePx / 2f
        path.reset()
        path.moveTo(r.left + s, r.top + inset)
        path.lineTo(r.right - inset, r.top + inset)
        path.lineTo(r.right - s, r.bottom - inset)
        path.lineTo(r.left + inset, r.bottom - inset)
        path.close()
        paint.style = Paint.Style.FILL
        paint.color = fill
        canvas.drawPath(path, paint)
        if (strokePx > 0f) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = strokePx
            paint.color = stroke
            canvas.drawPath(path, paint)
        }
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Garis tipis di tepi layar sebagai petunjuk tempat menarik untuk memunculkan jendela. */
private class EdgeStrip(ctx: Context, private val left: Boolean) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x99E8142C.toInt() }

    override fun onDraw(canvas: Canvas) {
        val w = 3f * resources.displayMetrics.density
        val h = height.toFloat()
        val x0 = if (left) 0f else width - w
        canvas.drawRoundRect(x0, h * 0.2f, x0 + w, h * 0.8f, w, w, paint)
    }
}

/**
 * Jendela mengambang Speed Xz di atas game. Dibuat dari View bawaan Android (bukan Compose)
 * supaya tidak membebani GPU game. Tanpa animasi kecuali kedipan peringatan overheat.
 * - Gelembung logo Xz: geser bebas, ketuk untuk membuka panel.
 * - Hilang sendiri setelah 10 detik tidak disentuh, atau saat ditarik ke pojok layar.
 * - Munculkan lagi dengan menarik (atau mengetuk) garis merah di tepi layar.
 * - Panel hanya diperbarui saat terbuka.
 */
class GameOverlay(
    private val ctx: Context,
    private val gameLabel: String,
    private val act: OverlayActions
) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val prefs = ctx.getSharedPreferences("speedxz", Context.MODE_PRIVATE)

    private var bubble: ImageView? = null
    private var strip: View? = null
    private var panel: FrameLayout? = null
    private var started = false
    private var bubbleY = 0
    private val hideRunnable = Runnable { hideBubble() }

    private var tvFps: TextView? = null
    private var tvCpu: TextView? = null
    private var tvRam: TextView? = null
    private var tvBat: TextView? = null
    private var tvSoc: TextView? = null
    private var tvPing: TextView? = null
    private var tvInfo: TextView? = null
    private var tvWarn: TextView? = null
    private var tvAi: TextView? = null
    private var btnDnd: TextView? = null
    private var btnDim: TextView? = null

    private var dndOn = false
    private var dimOn = false
    private var warnOn = false
    private var warnText = ""
    private var aiText = ""
    private var last: LiveStats? = null

    private val RED = 0xFFE8142C.toInt()
    private val WHITE = 0xFFF4EFEF.toInt()
    private val MUTED = 0xFF9A8F92.toInt()
    private val WARN = 0xFFFFB020.toInt()
    private val GOOD = 0xFF3DDC84.toInt()

    private val blink = object : Runnable {
        override fun run() {
            if (!warnOn) return
            val dim = (tvWarn?.alpha ?: 1f) > 0.5f
            tvWarn?.alpha = if (dim) 0.25f else 1f
            bubble?.alpha = if (dim) 0.45f else 1f
            main.postDelayed(this, 700L)
        }
    }

    private fun dp(v: Int): Int = (v * ctx.resources.displayMetrics.density).roundToInt()

    @Suppress("DEPRECATION")
    private fun screen(): Pair<Int, Int> {
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        return Pair(m.widthPixels, m.heightPixels)
    }

    private fun runMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else main.post { block() }
    }

    private fun lp(w: Int, h: Int): WindowManager.LayoutParams {
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        val p = WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        return p
    }

    fun isPanelOpen(): Boolean = panel != null

    // ---------------- siklus ----------------
    fun start() {
        runMain {
            if (started) return@runMain
            started = true
            val h = screen().second
            bubbleY = prefs.getInt("bubble_y", h / 3).coerceIn(dp(24), h - dp(80))
            showBubble()
        }
    }

    fun stop() {
        runMain {
            main.removeCallbacksAndMessages(null)
            bubble?.let { safeRemove(it) }
            strip?.let { safeRemove(it) }
            panel?.let { safeRemove(it) }
            bubble = null
            strip = null
            panel = null
            started = false
        }
    }

    private fun safeRemove(v: View) {
        try {
            wm.removeView(v)
        } catch (ex: Throwable) {
        }
    }

    // ---------------- gelembung ----------------
    @SuppressLint("ClickableViewAccessibility")
    private fun showBubble() {
        removeStrip()
        if (bubble != null) return
        val size = dp(52)
        val v = ImageView(ctx)
        v.setImageResource(R.drawable.xz_bubble)
        v.scaleType = ImageView.ScaleType.FIT_CENTER
        val sw = screen().first
        val left = prefs.getBoolean("dock_left", false)
        val p = lp(size, size)
        p.x = if (left) dp(6) else sw - size - dp(6)
        p.y = bubbleY

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = p.x
                    startY = p.y
                    moved = false
                    main.removeCallbacks(hideRunnable)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && (abs(dx) > dp(8) || abs(dy) > dp(8))) moved = true
                    if (moved) {
                        val s = screen()
                        p.x = (startX + dx).roundToInt().coerceIn(0, s.first - size)
                        p.y = (startY + dy).roundToInt().coerceIn(0, s.second - size)
                        try {
                            wm.updateViewLayout(v, p)
                        } catch (ex: Throwable) {
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (!moved) {
                        if (e.action == MotionEvent.ACTION_UP) togglePanel()
                    } else {
                        onDragEnd(p, size)
                    }
                    if (panel == null && bubble != null) scheduleHide()
                    true
                }
                else -> false
            }
        }
        try {
            wm.addView(v, p)
        } catch (ex: Throwable) {
            return
        }
        bubble = v
        applyWarnToBubble()
        scheduleHide()
    }

    private fun applyWarnToBubble() {
        val b = bubble ?: return
        if (warnOn) b.setColorFilter(0x88E8142C.toInt(), PorterDuff.Mode.SRC_ATOP) else {
            b.clearColorFilter()
            b.alpha = 1f
        }
    }

    private fun onDragEnd(p: WindowManager.LayoutParams, size: Int) {
        val s = screen()
        val sw = s.first
        val sh = s.second
        bubbleY = p.y
        val cx = p.x + size / 2
        prefs.edit().putInt("bubble_y", bubbleY).putBoolean("dock_left", cx < sw / 2).apply()
        // Pojok layar: dekat tepi kiri/kanan DAN dekat atas/bawah
        val nearSide = p.x < dp(72) || p.x + size > sw - dp(72)
        val nearTopBottom = p.y < dp(96) || p.y + size > sh - dp(96)
        if (nearSide && nearTopBottom) hideBubble()
    }

    private fun scheduleHide() {
        main.removeCallbacks(hideRunnable)
        if (panel == null) main.postDelayed(hideRunnable, 10_000L)
    }

    private fun hideBubble() {
        main.removeCallbacks(hideRunnable)
        val v = bubble ?: return
        if (panel != null) return
        bubble = null
        safeRemove(v)
        showStrip()
    }

    // ---------------- garis tepi layar ----------------
    @SuppressLint("ClickableViewAccessibility")
    private fun showStrip() {
        if (strip != null) return
        val s = screen()
        val left = prefs.getBoolean("dock_left", false)
        val w = dp(40)
        val h = dp(170)
        val v = EdgeStrip(ctx, left)
        val p = lp(w, h)
        p.x = if (left) 0 else s.first - w
        p.y = (bubbleY - h / 2 + dp(26)).coerceIn(0, s.second - h)

        var downX = 0f
        var done = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    done = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val inward = if (left) dx else -dx
                    if (!done && inward > dp(32)) {
                        done = true
                        reveal()
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!done && abs(e.rawX - downX) < dp(8)) reveal()
                    true
                }
                else -> true
            }
        }
        // Minta sistem tidak memakai area ini untuk gestur kembali, supaya tarikan dari tepi sampai ke kita
        v.addOnLayoutChangeListener { view, l, t, r, b, _, _, _, _ ->
            if (Build.VERSION.SDK_INT >= 29) {
                try {
                    view.systemGestureExclusionRects = listOf(Rect(0, 0, r - l, b - t))
                } catch (ex: Throwable) {
                }
            }
        }
        try {
            wm.addView(v, p)
        } catch (ex: Throwable) {
            return
        }
        strip = v
    }

    private fun removeStrip() {
        strip?.let { safeRemove(it) }
        strip = null
    }

    private fun reveal() {
        removeStrip()
        showBubble()
    }

    // ---------------- panel ----------------
    private fun togglePanel() {
        if (panel != null) closePanel() else openPanel()
    }

    private fun closePanel() {
        panel?.let { safeRemove(it) }
        panel = null
        tvFps = null
        tvCpu = null
        tvRam = null
        tvBat = null
        tvSoc = null
        tvPing = null
        tvInfo = null
        tvWarn = null
        tvAi = null
        btnDnd = null
        btnDim = null
        scheduleHide()
    }

    private fun openPanel() {
        main.removeCallbacks(hideRunnable)
        val s = screen()
        val landscape = s.first > s.second
        val w = min(if (landscape) dp(600) else dp(340), (s.first * 0.92f).toInt())
        val root = buildPanel(landscape)
        root.measure(
            View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val h = min(root.measuredHeight, (s.second * 0.94f).toInt())
        val p = lp(w, h)
        p.gravity = Gravity.CENTER
        p.x = 0
        p.y = 0
        try {
            wm.addView(root, p)
        } catch (ex: Throwable) {
            return
        }
        panel = root
        last?.let { applyStats(it) }
        applyWarnToPanel()
        tvAi?.text = aiText
    }

    private fun tv(text: String, sp: Float, color: Int): TextView {
        val t = TextView(ctx)
        t.text = text
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.setTextColor(color)
        t.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
        return t
    }

    private fun cell(label: String): Pair<LinearLayout, TextView> {
        val c = LinearLayout(ctx)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(4), dp(6), dp(4), dp(6))
        c.addView(tv(label, 10f, MUTED))
        val v = tv("-", 16f, WHITE)
        c.addView(v)
        return Pair(c, v)
    }

    private fun row(vararg cells: View): LinearLayout {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        for (c in cells) r.addView(c, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        return r
    }

    private fun btn(text: String, filled: Boolean, sp: Float = 12f, onClick: () -> Unit): TextView {
        val b = tv(text, sp, WHITE)
        b.gravity = Gravity.CENTER
        b.setPadding(dp(8), dp(9), dp(8), dp(9))
        b.background = if (filled) {
            SlantDrawable(RED, 0, dp(10).toFloat(), 0f)
        } else {
            SlantDrawable(0xFF1C1316.toInt(), RED, dp(10).toFloat(), dp(1).toFloat())
        }
        b.setOnClickListener { onClick() }
        return b
    }

    private fun btnRow(vararg items: View): LinearLayout {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        for (x in items) {
            val p = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            p.setMargins(dp(3), dp(3), dp(3), dp(3))
            r.addView(x, p)
        }
        return r
    }

    private fun buildPanel(landscape: Boolean): FrameLayout {
        val root = FrameLayout(ctx)
        root.background = SlantDrawable(0xF2070708.toInt(), RED, dp(18).toFloat(), dp(2).toFloat())
        val scroll = ScrollView(ctx)
        scroll.isVerticalScrollBarEnabled = false
        val body = LinearLayout(ctx)
        body.setPadding(dp(24), dp(10), dp(28), dp(12))
        if (landscape) {
            body.orientation = LinearLayout.HORIZONTAL
            body.addView(leftColumn(), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val rp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.1f)
            rp.setMargins(dp(12), 0, 0, 0)
            body.addView(rightColumn(), rp)
        } else {
            body.orientation = LinearLayout.VERTICAL
            body.addView(leftColumn())
            body.addView(rightColumn())
        }
        scroll.addView(body)
        root.addView(scroll)
        return root
    }

    private fun leftColumn(): LinearLayout {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL

        val head = FrameLayout(ctx)
        val logo = ImageView(ctx)
        logo.setImageResource(R.drawable.xz_logo)
        logo.scaleType = ImageView.ScaleType.FIT_START
        head.addView(logo, FrameLayout.LayoutParams(dp(190), dp(52), Gravity.START or Gravity.CENTER_VERTICAL))
        val close = tv("TUTUP", 11f, MUTED)
        close.setPadding(dp(8), dp(8), dp(4), dp(8))
        close.setOnClickListener { closePanel() }
        head.addView(
            close,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.END or Gravity.CENTER_VERTICAL
            )
        )
        col.addView(head)

        val title = tv(gameLabel.uppercase(), 13f, 0xFFFF4D5E.toInt())
        title.setSingleLine(true)
        col.addView(title)
        val info = tv("Sesi 00:00", 11f, MUTED)
        tvInfo = info
        col.addView(info)

        val warn = tv(warnText, 13f, 0xFFFF4D5E.toInt())
        warn.visibility = View.GONE
        warn.setPadding(0, dp(6), 0, dp(2))
        tvWarn = warn
        col.addView(warn)

        val fps = cell("FPS (perkiraan)")
        val cpu = cell("CPU")
        val ram = cell("RAM BEBAS")
        val bat = cell("SUHU BATERAI")
        val soc = cell("SUHU CPU")
        val ping = cell("PING")
        tvFps = fps.second
        tvCpu = cpu.second
        tvRam = ram.second
        tvBat = bat.second
        tvSoc = soc.second
        tvPing = ping.second
        col.addView(row(fps.first, cpu.first, ram.first))
        col.addView(row(bat.first, soc.first, ping.first))
        return col
    }

    private fun rightColumn(): LinearLayout {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL

        val bBoost = btn("BOOST ULANG", true) { act.boost() }
        val bDnd = btn(if (dndOn) "JANGAN GANGGU: ON" else "JANGAN GANGGU: OFF", false) { act.dnd() }
        val bDim = btn(if (dimOn) "REDUP: ON" else "REDUP LAYAR: OFF", false) { act.dim() }
        val bClean = btn("BERSIH CACHE", false) { act.clean() }
        val bHide = btn("SEMBUNYIKAN", false) {
            closePanel()
            hideBubble()
        }
        val bEnd = btn("AKHIRI SESI", true) { act.end() }
        btnDnd = bDnd
        btnDim = bDim
        col.addView(btnRow(bBoost, bDnd))
        col.addView(btnRow(bDim, bClean))
        col.addView(btnRow(bHide, bEnd))

        val ai = tv("TANYA AI (GEMINI)", 10f, MUTED)
        ai.setPadding(dp(4), dp(8), 0, dp(2))
        col.addView(ai)
        col.addView(
            btnRow(
                btn("ANALISIS", false, 11f) { act.ai("analisis") },
                btn("KENAPA PANAS", false, 11f) { act.ai("panas") },
                btn("KENAPA LAG", false, 11f) { act.ai("lag") }
            )
        )
        val out = tv(aiText, 12f, WHITE)
        out.typeface = Typeface.DEFAULT
        out.setPadding(dp(4), dp(4), dp(4), dp(2))
        tvAi = out
        col.addView(out)
        return col
    }

    // ---------------- data ----------------
    private fun applyStats(s: LiveStats) {
        tvFps?.text = if (s.fps >= 0) "${s.fps}" else "N/A"
        tvCpu?.text = if (s.cpu >= 0) "${s.cpu}%" else "N/A"
        tvRam?.text = "${s.freeMb} MB"
        tvBat?.text = String.format("%.1f C", s.temp)
        tvBat?.setTextColor(if (s.temp >= 43.0) WARN else WHITE)
        tvSoc?.text = if (s.zone >= 0) String.format("%.0f C", s.zone) else "N/A"
        tvSoc?.setTextColor(if (s.zone >= 75.0) WARN else WHITE)
        tvPing?.text = if (s.pingMs >= 0) "${s.pingMs} ms" else "N/A"
        val m = s.elapsedSec / 60
        val sec = s.elapsedSec % 60
        tvInfo?.text = String.format("Sesi %02d:%02d | thermal %s | ditutup %d", m, sec, s.thermal, s.killed)
    }

    /** Dipanggil tiap siklus pemantau. Hanya menggambar ulang jika panel terbuka. */
    fun update(s: LiveStats) {
        runMain {
            last = s
            if (panel != null) applyStats(s)
        }
    }

    private fun applyWarnToPanel() {
        val w = tvWarn ?: return
        w.text = warnText
        w.visibility = if (warnOn) View.VISIBLE else View.GONE
    }

    fun setWarn(on: Boolean, text: String) {
        runMain {
            warnText = text
            val was = warnOn
            warnOn = on
            applyWarnToPanel()
            applyWarnToBubble()
            if (on && !was) main.postDelayed(blink, 700L)
            if (!on) {
                main.removeCallbacks(blink)
                tvWarn?.alpha = 1f
                bubble?.alpha = 1f
            }
        }
    }

    fun setDnd(on: Boolean) {
        runMain {
            dndOn = on
            btnDnd?.text = if (on) "JANGAN GANGGU: ON" else "JANGAN GANGGU: OFF"
        }
    }

    fun setDim(on: Boolean) {
        runMain {
            dimOn = on
            btnDim?.text = if (on) "REDUP: ON" else "REDUP LAYAR: OFF"
        }
    }

    fun setAi(text: String) {
        runMain {
            aiText = text
            tvAi?.text = text
        }
    }

    fun toast(msg: String) {
        runMain {
            try {
                Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
            } catch (ex: Throwable) {
            }
        }
    }

    fun toastLong(msg: String) {
        runMain {
            try {
                Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
            } catch (ex: Throwable) {
            }
        }
    }
}
