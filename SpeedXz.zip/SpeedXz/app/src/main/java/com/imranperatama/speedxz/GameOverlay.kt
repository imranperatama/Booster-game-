package com.imranperatama.speedxz

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt

data class LiveStats(
    val fps: Int,
    val cpu: Int,
    val freeMb: Long,
    val totalMb: Long,
    val temp: Double,
    val zone: Double,
    val thermal: String,
    val pingMs: Int,
    val net: String,
    val elapsedSec: Int,
    val killed: Int
)

class OverlayActions(
    val boost: () -> Unit,
    val dnd: () -> Unit,
    val dim: () -> Unit,
    val clean: () -> Unit,
    val ask: (String) -> Unit,
    val maxPerf: () -> Unit,
    val signal: () -> Unit,
    val smart: () -> Unit,
    val end: () -> Unit
)

/** Jajar genjang miring, bentuk khas Speed Xz, untuk latar panel dan tombol. */
class SlantDrawable(
    private val fill: Int,
    private val stroke: Int,
    private val slantPx: Float,
    private val strokePx: Float
) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    override fun draw(canvas: Canvas) {
        val r = bounds
        val s = min(slantPx, r.width() / 3f)
        val inset = strokePx / 2f
        path.reset()
        path.moveTo(r.left + s, r.top + inset)
        path.lineTo(r.right - inset, r.top + inset)
        path.lineTo(r.right - s, r.bottom - inset)
        path.lineTo(r.left + inset, r.bottom - inset)
        path.close()
        paint.style = Paint.Style.FILL
        paint.color = fill
        canvas.drawPath(path, paint)
        if (strokePx > 0f) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = strokePx
            paint.color = stroke
            canvas.drawPath(path, paint)
        }
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Garis tipis di tepi layar sebagai petunjuk tempat menarik untuk memunculkan jendela. */
private class EdgeStrip(ctx: Context, private val left: Boolean) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x99E8142C.toInt() }

    override fun onDraw(canvas: Canvas) {
        val w = 3f * resources.displayMetrics.density
        val h = height.toFloat()
        val x0 = if (left) 0f else width - w
        canvas.drawRoundRect(x0, h * 0.2f, x0 + w, h * 0.8f, w, w, paint)
    }
}

/** Akar panel. Tombol Kembali hanya menutup papan ketik saat sedang mengetik, selain itu diteruskan ke game. */
private class PanelRoot(ctx: Context, private val typing: () -> Boolean, private val stop: () -> Unit) : FrameLayout(ctx) {
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_BACK && typing()) {
            if (event.action == KeyEvent.ACTION_UP) stop()
            return true
        }
        return super.dispatchKeyEvent(event)
    }
}

/**
 * Jendela mengambang Speed Xz di atas game. Dibuat dari View bawaan Android (bukan Compose)
 * supaya tidak membebani GPU game. Tanpa animasi kecuali kedipan peringatan overheat.
 * - Gelembung logo Xz: geser bebas, ketuk untuk membuka panel.
 * - Hilang sendiri setelah 10 detik tidak disentuh, atau saat ditarik ke pojok layar.
 * - Munculkan lagi dengan menarik (atau mengetuk) garis merah di tepi layar.
 * - Panel punya tiga tab: PANTAU (angka langsung), AI (chat Gemini), OPTIMAL (kinerja max dan sinyal).
 * - Panel hanya diperbarui saat terbuka. Jendela hanya bisa menerima papan ketik saat tab AI sedang dipakai mengetik.
 */
class GameOverlay(
    private val ctx: Context,
    private val gameLabel: String,
    private val act: OverlayActions
) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val prefs = ctx.getSharedPreferences("speedxz", Context.MODE_PRIVATE)

    private var bubble: ImageView? = null
    private var strip: View? = null
    private var panel: PanelRoot? = null
    private var panelP: WindowManager.LayoutParams? = null
    private var started = false
    private var bubbleY = 0
    private val hideRunnable = Runnable { hideBubble() }

    private val pages = ArrayList<View>()
    private val tabBtns = ArrayList<TextView>()
    private var curTab = 0
    private var typing = false
    private var fullH = 0
    private var compactH = 0

    private var tvFps: TextView? = null
    private var tvCpu: TextView? = null
    private var tvRam: TextView? = null
    private var tvUsed: TextView? = null
    private var tvBat: TextView? = null
    private var tvSoc: TextView? = null
    private var tvPing: TextView? = null
    private var tvNet: TextView? = null
    private var tvTherm: TextView? = null
    private var tvInfo: TextView? = null
    private var tvWarn: TextView? = null
    private var btnDnd: TextView? = null
    private var btnDim: TextView? = null
    private var btnSmart: TextView? = null
    private var chatBox: LinearLayout? = null
    private var chatScroll: ScrollView? = null
    private var tvAiStatus: TextView? = null
    private var etAi: EditText? = null
    private var tvOpt: TextView? = null

    private var dndOn = false
    private var dimOn = false
    private var smartOn = true
    private var warnOn = false
    private var warnText = ""
    private var chat: List<AiMsg> = emptyList()
    private var aiStatus = ""
    private var optText = ""
    private var last: LiveStats? = null

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val RED = 0xFFE8142C.toInt()
    private val WHITE = 0xFFF4EFEF.toInt()
    private val MUTED = 0xFF9A8F92.toInt()
    private val WARN = 0xFFFFB020.toInt()
    private val GOOD = 0xFF3DDC84.toInt()

    private val blink = object : Runnable {
        override fun run() {
            if (!warnOn) return
            val dim = (tvWarn?.alpha ?: 1f) > 0.5f
            tvWarn?.alpha = if (dim) 0.25f else 1f
            bubble?.alpha = if (dim) 0.45f else 1f
            main.postDelayed(this, 700L)
        }
    }

    private fun dp(v: Int): Int = (v * ctx.resources.displayMetrics.density).roundToInt()

    @Suppress("DEPRECATION")
    private fun screen(): Pair<Int, Int> {
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        return Pair(m.widthPixels, m.heightPixels)
    }

    private fun runMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else main.post { block() }
    }

    private fun lp(w: Int, h: Int): WindowManager.LayoutParams {
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        val p = WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        return p
    }

    fun isPanelOpen(): Boolean = panel != null

    // ---------------- siklus ----------------
    fun start() {
        runMain {
            if (started) return@runMain
            started = true
            val h = screen().second
            bubbleY = prefs.getInt("bubble_y", h / 3).coerceIn(dp(24), h - dp(80))
            showBubble()
        }
    }

    fun stop() {
        runMain {
            main.removeCallbacksAndMessages(null)
            bubble?.let { safeRemove(it) }
            strip?.let { safeRemove(it) }
            panel?.let { safeRemove(it) }
            bubble = null
            strip = null
            panel = null
            started = false
        }
    }

    private fun safeRemove(v: View) {
        try {
            wm.removeView(v)
        } catch (ex: Throwable) {
        }
    }

    // ---------------- gelembung ----------------
    @SuppressLint("ClickableViewAccessibility")
    private fun showBubble() {
        removeStrip()
        if (bubble != null) return
        val size = dp(52)
        val v = ImageView(ctx)
        v.setImageResource(R.drawable.xz_bubble)
        v.scaleType = ImageView.ScaleType.FIT_CENTER
        val sw = screen().first
        val left = prefs.getBoolean("dock_left", false)
        val p = lp(size, size)
        p.x = if (left) dp(6) else sw - size - dp(6)
        p.y = bubbleY

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = p.x
                    startY = p.y
                    moved = false
                    main.removeCallbacks(hideRunnable)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && (abs(dx) > dp(8) || abs(dy) > dp(8))) moved = true
                    if (moved) {
                        val s = screen()
                        p.x = (startX + dx).roundToInt().coerceIn(0, s.first - size)
                        p.y = (startY + dy).roundToInt().coerceIn(0, s.second - size)
                        try {
                            wm.updateViewLayout(v, p)
                        } catch (ex: Throwable) {
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (!moved) {
                        if (e.action == MotionEvent.ACTION_UP) togglePanel()
                    } else {
                        onDragEnd(p, size)
                    }
                    if (panel == null && bubble != null) scheduleHide()
                    true
                }
                else -> false
            }
        }
        try {
            wm.addView(v, p)
        } catch (ex: Throwable) {
            return
        }
        bubble = v
        applyWarnToBubble()
        scheduleHide()
    }

    private fun applyWarnToBubble() {
        val b = bubble ?: return
        if (warnOn) b.setColorFilter(0x88E8142C.toInt(), PorterDuff.Mode.SRC_ATOP) else {
            b.clearColorFilter()
            b.alpha = 1f
        }
    }

    private fun onDragEnd(p: WindowManager.LayoutParams, size: Int) {
        val s = screen()
        val sw = s.first
        val sh = s.second
        bubbleY = p.y
        val cx = p.x + size / 2
        prefs.edit().putInt("bubble_y", bubbleY).putBoolean("dock_left", cx < sw / 2).apply()
        // Pojok layar: dekat tepi kiri/kanan DAN dekat atas/bawah
        val nearSide = p.x < dp(72) || p.x + size > sw - dp(72)
        val nearTopBottom = p.y < dp(96) || p.y + size > sh - dp(96)
        if (nearSide && nearTopBottom) hideBubble()
    }

    private fun scheduleHide() {
        main.removeCallbacks(hideRunnable)
        if (panel == null) main.postDelayed(hideRunnable, 10_000L)
    }

    private fun hideBubble() {
        main.removeCallbacks(hideRunnable)
        val v = bubble ?: return
        if (panel != null) return
        bubble = null
        safeRemove(v)
        showStrip()
    }

    // ---------------- garis tepi layar ----------------
    @SuppressLint("ClickableViewAccessibility")
    private fun showStrip() {
        if (strip != null) return
        val s = screen()
        val left = prefs.getBoolean("dock_left", false)
        val w = dp(40)
        val h = dp(170)
        val v = EdgeStrip(ctx, left)
        val p = lp(w, h)
        p.x = if (left) 0 else s.first - w
        p.y = (bubbleY - h / 2 + dp(26)).coerceIn(0, s.second - h)

        var downX = 0f
        var done = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    done = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val inward = if (left) dx else -dx
                    if (!done && inward > dp(32)) {
                        done = true
                        reveal()
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!done && abs(e.rawX - downX) < dp(8)) reveal()
                    true
                }
                else -> true
            }
        }
        // Minta sistem tidak memakai area ini untuk gestur kembali, supaya tarikan dari tepi sampai ke kita
        v.addOnLayoutChangeListener { view, l, t, r, b, _, _, _, _ ->
            if (Build.VERSION.SDK_INT >= 29) {
                try {
                    view.systemGestureExclusionRects = listOf(Rect(0, 0, r - l, b - t))
                } catch (ex: Throwable) {
                }
            }
        }
        try {
            wm.addView(v, p)
        } catch (ex: Throwable) {
            return
        }
        strip = v
    }

    private fun removeStrip() {
        strip?.let { safeRemove(it) }
        strip = null
    }

    private fun reveal() {
        removeStrip()
        showBubble()
    }

    // ---------------- panel ----------------
    private fun togglePanel() {
        if (panel != null) closePanel() else openPanel()
    }

    private fun closePanel() {
        setTyping(false)
        panel?.let { safeRemove(it) }
        panel = null
        panelP = null
        pages.clear()
        tabBtns.clear()
        tvFps = null
        tvCpu = null
        tvRam = null
        tvUsed = null
        tvBat = null
        tvSoc = null
        tvPing = null
        tvNet = null
        tvTherm = null
        tvInfo = null
        tvWarn = null
        btnDnd = null
        btnDim = null
        btnSmart = null
        chatBox = null
        chatScroll = null
        tvAiStatus = null
        etAi = null
        tvOpt = null
        scheduleHide()
    }

    private fun openPanel() {
        main.removeCallbacks(hideRunnable)
        val s = screen()
        val landscape = s.first > s.second
        val w = min(if (landscape) dp(560) else dp(340), (s.first * 0.94f).toInt())
        val h = min(if (landscape) dp(380) else dp(540), (s.second * 0.92f).toInt())
        fullH = h
        compactH = min(h, (s.second * 0.46f).toInt())
        val root = buildPanel(landscape)
        val p = lp(w, h)
        p.gravity = Gravity.CENTER
        p.x = 0
        p.y = 0
        p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
        try {
            wm.addView(root, p)
        } catch (ex: Throwable) {
            return
        }
        panel = root
        panelP = p
        typing = false
        last?.let { applyStats(it) }
        applyWarnToPanel()
        renderChat()
        tvOpt?.text = optText
        setTab(curTab)
    }

    /**
     * Saat mengetik di tab AI, jendela dibuat bisa fokus (supaya papan ketik muncul) dan dipindah ke atas
     * dengan tinggi lebih kecil supaya tidak tertutup papan ketik. Selesai mengetik, semuanya dikembalikan
     * dan game kembali menerima sentuhan penuh.
     */
    private fun setTyping(on: Boolean) {
        val r = panel ?: return
        val p = panelP ?: return
        if (typing == on) return
        typing = on
        val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        if (on) {
            p.flags = p.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
            p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            p.y = dp(4)
            p.height = compactH
        } else {
            p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            p.gravity = Gravity.CENTER
            p.y = 0
            p.height = fullH
        }
        try {
            wm.updateViewLayout(r, p)
        } catch (ex: Throwable) {
        }
        val et = etAi
        if (on) {
            if (et != null) {
                et.post {
                    et.requestFocus()
                    imm.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
                }
            }
        } else {
            if (et != null) et.clearFocus()
            try {
                imm.hideSoftInputFromWindow(r.windowToken, 0)
            } catch (ex: Throwable) {
            }
        }
        if (on) scrollChat()
    }

    private fun setTab(i: Int) {
        curTab = i
        if (i != 1) setTyping(false)
        for (k in pages.indices) pages[k].visibility = if (k == i) View.VISIBLE else View.GONE
        for (k in tabBtns.indices) {
            tabBtns[k].background = if (k == i) {
                SlantDrawable(RED, 0, dp(8).toFloat(), 0f)
            } else {
                SlantDrawable(0xFF1C1316.toInt(), RED, dp(8).toFloat(), dp(1).toFloat())
            }
        }
        if (i == 1) scrollChat()
    }

    private fun tv(text: String, sp: Float, color: Int): TextView {
        val t = TextView(ctx)
        t.text = text
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.setTextColor(color)
        t.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
        return t
    }

    private fun plainTv(text: String, sp: Float, color: Int): TextView {
        val t = tv(text, sp, color)
        t.typeface = Typeface.DEFAULT
        return t
    }

    private fun cell(label: String): Pair<LinearLayout, TextView> {
        val c = LinearLayout(ctx)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(4), dp(5), dp(4), dp(5))
        c.addView(tv(label, 10f, MUTED))
        val v = tv("-", 16f, WHITE)
        c.addView(v)
        return Pair(c, v)
    }

    private fun row(vararg cells: View): LinearLayout {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        for (c in cells) r.addView(c, LinearLayout.LayoutParams(0, WRAP, 1f))
        return r
    }

    private fun btn(text: String, filled: Boolean, sp: Float = 12f, onClick: () -> Unit): TextView {
        val b = tv(text, sp, WHITE)
        b.gravity = Gravity.CENTER
        b.setPadding(dp(8), dp(9), dp(8), dp(9))
        b.background = if (filled) {
            SlantDrawable(RED, 0, dp(10).toFloat(), 0f)
        } else {
            SlantDrawable(0xFF1C1316.toInt(), RED, dp(10).toFloat(), dp(1).toFloat())
        }
        b.setOnClickListener { onClick() }
        return b
    }

    private fun btnRow(vararg items: View): LinearLayout {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        for (x in items) {
            val p = LinearLayout.LayoutParams(0, WRAP, 1f)
            p.setMargins(dp(3), dp(3), dp(3), dp(3))
            r.addView(x, p)
        }
        return r
    }

    private fun buildPanel(landscape: Boolean): PanelRoot {
        val root = PanelRoot(ctx, { typing }, { setTyping(false) })
        root.background = SlantDrawable(0xF2070708.toInt(), RED, dp(18).toFloat(), dp(2).toFloat())
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(22), dp(6), dp(26), dp(10))

        val head = FrameLayout(ctx)
        val logo = ImageView(ctx)
        logo.setImageResource(R.drawable.xz_logo)
        logo.scaleType = ImageView.ScaleType.FIT_START
        head.addView(logo, FrameLayout.LayoutParams(dp(150), dp(40), Gravity.START or Gravity.CENTER_VERTICAL))
        val close = tv("TUTUP", 11f, MUTED)
        close.setPadding(dp(8), dp(8), dp(4), dp(8))
        close.setOnClickListener { closePanel() }
        head.addView(close, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.END or Gravity.CENTER_VERTICAL))
        col.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))

        val tabs = LinearLayout(ctx)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabBtns.clear()
        val names = listOf("PANTAU", "AI", "OPTIMAL")
        for (i in names.indices) {
            val b = tv(names[i], 12f, WHITE)
            b.gravity = Gravity.CENTER
            b.setPadding(dp(6), dp(8), dp(6), dp(8))
            b.setOnClickListener { setTab(i) }
            tabBtns.add(b)
            val lp3 = LinearLayout.LayoutParams(0, WRAP, 1f)
            lp3.setMargins(dp(3), dp(2), dp(3), dp(4))
            tabs.addView(b, lp3)
        }
        col.addView(tabs, LinearLayout.LayoutParams(MATCH, WRAP))

        val content = FrameLayout(ctx)
        pages.clear()
        pages.add(buildMonitor(landscape))
        pages.add(buildChat())
        pages.add(buildOpt())
        for (v in pages) content.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        col.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))

        root.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        return root
    }

    // ---- tab PANTAU ----
    private fun buildMonitor(landscape: Boolean): ScrollView {
        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        val body = LinearLayout(ctx)
        body.orientation = if (landscape) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL

        val left = LinearLayout(ctx)
        left.orientation = LinearLayout.VERTICAL
        val title = tv(gameLabel.uppercase(), 13f, 0xFFFF4D5E.toInt())
        title.setSingleLine(true)
        left.addView(title)
        val info = tv("Sesi 00:00", 11f, MUTED)
        tvInfo = info
        left.addView(info)
        val warn = tv(warnText, 13f, 0xFFFF4D5E.toInt())
        warn.visibility = View.GONE
        warn.setPadding(0, dp(6), 0, dp(2))
        tvWarn = warn
        left.addView(warn)

        val fps = cell("FPS")
        val cpu = cell("CPU")
        val soc = cell("SUHU CPU")
        val ram = cell("RAM BEBAS")
        val used = cell("RAM PAKAI")
        val bat = cell("SUHU BATERAI")
        val ping = cell("PING")
        val net = cell("SINYAL")
        val therm = cell("THERMAL")
        net.second.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        tvFps = fps.second
        tvCpu = cpu.second
        tvSoc = soc.second
        tvRam = ram.second
        tvUsed = used.second
        tvBat = bat.second
        tvPing = ping.second
        tvNet = net.second
        tvTherm = therm.second
        left.addView(row(fps.first, cpu.first, soc.first))
        left.addView(row(ram.first, used.first, bat.first))
        left.addView(row(ping.first, net.first, therm.first))

        val right = LinearLayout(ctx)
        right.orientation = LinearLayout.VERTICAL
        val bBoost = btn("BOOST ULANG", true) { act.boost() }
        val bDnd = btn(if (dndOn) "JANGAN GANGGU: ON" else "JANGAN GANGGU: OFF", false) { act.dnd() }
        val bDim = btn(if (dimOn) "REDUP: ON" else "REDUP LAYAR: OFF", false) { act.dim() }
        val bClean = btn("BERSIH CACHE", false) { act.clean() }
        val bHide = btn("SEMBUNYIKAN", false) {
            closePanel()
            hideBubble()
        }
        val bEnd = btn("AKHIRI SESI", true) { act.end() }
        btnDnd = bDnd
        btnDim = bDim
        right.addView(btnRow(bBoost, bDnd))
        right.addView(btnRow(bDim, bClean))
        right.addView(btnRow(bHide, bEnd))

        if (landscape) {
            body.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))
            val rp = LinearLayout.LayoutParams(0, WRAP, 1f)
            rp.setMargins(dp(12), dp(8), 0, 0)
            body.addView(right, rp)
        } else {
            body.addView(left)
            body.addView(right)
        }
        sv.addView(body)
        return sv
    }

    // ---- tab AI ----
    private fun chip(label: String, question: String): TextView =
        btn(label, false, 10f) {
            setTyping(false)
            act.ask(question)
        }

    private fun buildChat(): LinearLayout {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL

        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(2), dp(4), dp(2), dp(4))
        sv.addView(box)
        chatBox = box
        chatScroll = sv
        col.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val st = plainTv("", 11f, MUTED)
        st.setPadding(dp(4), dp(2), dp(4), dp(2))
        tvAiStatus = st
        col.addView(st)

        col.addView(
            btnRow(
                chip("ANALISIS", "Analisis kondisi HP-ku saat main dan beri langkah singkat untuk memperbaikinya."),
                chip("PANAS?", "HP-ku mulai panas saat main. Kenapa, dan apa yang bisa kulakukan sekarang?"),
                chip("LAG?", "Game terasa patah-patah. Kemungkinan penyebabnya dari data ini dan apa yang bisa kulakukan?"),
                chip("SINYAL?", "Ping dan sinyalku terasa jelek saat main. Apa penyebabnya dan apa yang bisa kulakukan?")
            )
        )

        val inputRow = LinearLayout(ctx)
        inputRow.orientation = LinearLayout.HORIZONTAL
        inputRow.gravity = Gravity.CENTER_VERTICAL
        val et = EditText(ctx)
        et.hint = "Tanya AI booster..."
        et.setHintTextColor(MUTED)
        et.setTextColor(WHITE)
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        et.setSingleLine(true)
        et.imeOptions = EditorInfo.IME_ACTION_SEND or EditorInfo.IME_FLAG_NO_EXTRACT_UI or EditorInfo.IME_FLAG_NO_FULLSCREEN
        et.background = SlantDrawable(0xFF1C1316.toInt(), RED, dp(8).toFloat(), dp(1).toFloat())
        et.setPadding(dp(14), dp(8), dp(16), dp(8))
        et.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) setTyping(true)
            false
        }
        et.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEND) {
                sendFromInput()
                true
            } else {
                false
            }
        }
        etAi = et
        inputRow.addView(et, LinearLayout.LayoutParams(0, WRAP, 1f))
        val send = btn("KIRIM", true, 12f) { sendFromInput() }
        val sp = LinearLayout.LayoutParams(WRAP, WRAP)
        sp.setMargins(dp(4), 0, 0, 0)
        inputRow.addView(send, sp)
        col.addView(inputRow, LinearLayout.LayoutParams(MATCH, WRAP))
        return col
    }

    private fun sendFromInput() {
        val et = etAi ?: return
        val t = et.text.toString().trim()
        if (t.isEmpty()) return
        et.setText("")
        setTyping(false)
        act.ask(t)
    }

    private fun plain(text: String): String =
        text.replace("**", "").replace("__", "").replace("`", "")
            .replace(Regex("(?m)^#+\\s*"), "")
            .replace(Regex("(?m)^\\s*[*]\\s+"), "- ")

    private fun renderChat() {
        val box = chatBox ?: return
        box.removeAllViews()
        if (chat.isEmpty()) {
            val h = plainTv("Tanya apa saja soal HP dan game: panas, lag, RAM, sinyal. AI membaca angka HP-mu saat ini.", 12f, MUTED)
            h.setPadding(dp(4), dp(6), dp(4), dp(6))
            box.addView(h)
        }
        for (m in chat) {
            val t = TextView(ctx)
            t.text = plain(m.text)
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            t.setTextColor(WHITE)
            t.maxWidth = dp(280)
            t.setPadding(dp(14), dp(8), dp(14), dp(8))
            t.background = if (m.fromUser) {
                SlantDrawable(0xFF8A0B1A.toInt(), 0, dp(8).toFloat(), 0f)
            } else {
                SlantDrawable(0xFF1C1316.toInt(), 0xFF3A2A2E.toInt(), dp(8).toFloat(), dp(1).toFloat())
            }
            val lpp = LinearLayout.LayoutParams(WRAP, WRAP)
            lpp.gravity = if (m.fromUser) Gravity.END else Gravity.START
            lpp.setMargins(dp(2), dp(3), dp(2), dp(3))
            box.addView(t, lpp)
        }
        tvAiStatus?.text = aiStatus
        scrollChat()
    }

    private fun scrollChat() {
        val sv = chatScroll ?: return
        sv.post { sv.fullScroll(View.FOCUS_DOWN) }
    }

    // ---- tab OPTIMAL ----
    private fun smartLabel(): String = if (smartOn) "AUTO PINTAR: ON (jaga RAM dan suhu)" else "AUTO PINTAR: OFF"

    private fun buildOpt(): ScrollView {
        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val d = plainTv("Mekanisme pintar: memeriksa suhu, RAM, dan jaringan dulu, lalu memilih langkah yang aman untuk HP-mu.", 11f, MUTED)
        d.setPadding(dp(4), dp(6), dp(4), dp(6))
        col.addView(d)
        col.addView(btnRow(btn("OPTIMALKAN KINERJA MAX", true, 13f) { act.maxPerf() }))
        col.addView(btnRow(btn("OPTIMALKAN SINYAL", true, 13f) { act.signal() }))
        val sm = btn(smartLabel(), false, 12f) { act.smart() }
        btnSmart = sm
        col.addView(btnRow(sm))
        val out = plainTv(optText, 12f, WHITE)
        out.setPadding(dp(4), dp(8), dp(4), dp(4))
        tvOpt = out
        col.addView(out)
        sv.addView(col)
        return sv
    }

    // ---------------- data ----------------
    private fun applyStats(s: LiveStats) {
        tvFps?.text = if (s.fps >= 0) "${s.fps}" else "N/A"
        tvCpu?.text = if (s.cpu >= 0) "${s.cpu}%" else "N/A"
        tvRam?.text = "${s.freeMb} MB"
        val lowRam = s.totalMb > 0 && s.freeMb * 100 / s.totalMb < 12
        tvRam?.setTextColor(if (lowRam) WARN else WHITE)
        tvUsed?.text = if (s.totalMb > 0) "${s.totalMb - s.freeMb} MB" else "N/A"
        tvBat?.text = String.format("%.1f C", s.temp)
        tvBat?.setTextColor(if (s.temp >= 43.0) WARN else WHITE)
        tvSoc?.text = if (s.zone >= 0) String.format("%.0f C", s.zone) else "N/A"
        tvSoc?.setTextColor(if (s.zone >= 75.0) WARN else WHITE)
        tvPing?.text = if (s.pingMs >= 0) "${s.pingMs} ms" else "N/A"
        tvNet?.text = s.net
        tvTherm?.text = s.thermal
        val m = s.elapsedSec / 60
        val sec = s.elapsedSec % 60
        tvInfo?.text = String.format("Sesi %02d:%02d | aplikasi latar ditutup %d", m, sec, s.killed)
    }

    /** Dipanggil tiap siklus pemantau. Hanya menggambar ulang jika panel terbuka. */
    fun update(s: LiveStats) {
        runMain {
            last = s
            if (panel != null) applyStats(s)
        }
    }

    private fun applyWarnToPanel() {
        val w = tvWarn ?: return
        w.text = warnText
        w.visibility = if (warnOn) View.VISIBLE else View.GONE
    }

    fun setWarn(on: Boolean, text: String) {
        runMain {
            warnText = text
            val was = warnOn
            warnOn = on
            applyWarnToPanel()
            applyWarnToBubble()
            if (on && !was) main.postDelayed(blink, 700L)
            if (!on) {
                main.removeCallbacks(blink)
                tvWarn?.alpha = 1f
                bubble?.alpha = 1f
            }
        }
    }

    fun setDnd(on: Boolean) {
        runMain {
            dndOn = on
            btnDnd?.text = if (on) "JANGAN GANGGU: ON" else "JANGAN GANGGU: OFF"
        }
    }

    fun setDim(on: Boolean) {
        runMain {
            dimOn = on
            btnDim?.text = if (on) "REDUP: ON" else "REDUP LAYAR: OFF"
        }
    }

    fun setChat(msgs: List<AiMsg>, status: String) {
        runMain {
            chat = msgs
            aiStatus = status
            renderChat()
        }
    }

    fun setOpt(text: String) {
        runMain {
            optText = text
            tvOpt?.text = text
        }
    }

    fun setSmart(on: Boolean) {
        runMain {
            smartOn = on
            btnSmart?.text = smartLabel()
        }
    }

    fun toast(msg: String) {
        runMain {
            try {
                Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
            } catch (ex: Throwable) {
            }
        }
    }

    fun toastLong(msg: String) {
        runMain {
            try {
                Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
            } catch (ex: Throwable) {
            }
        }
    }
}
