package com.imranperatama.speedxz

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
private fun Field(
    value: String,
    onChange: (String) -> Unit,
    hint: String,
    modifier: Modifier = Modifier,
    password: Boolean = false,
    single: Boolean = true
) {
    Box(
        modifier.clip(SlantShape(8f)).background(Panel2)
            .padding(start = 18.dp, end = 22.dp, top = 11.dp, bottom = 11.dp)
    ) {
        if (value.isEmpty()) Txt(hint, size = 14, color = Muted)
        BasicTextField(
            value = value,
            onValueChange = onChange,
            singleLine = single,
            textStyle = TextStyle(color = TextMain, fontSize = 14.sp),
            cursorBrush = SolidColor(Red),
            visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun AiScreen(vm: AppViewModel) {
    var key by remember { mutableStateOf(vm.aiKey) }
    var model by remember { mutableStateOf(vm.aiModel) }
    var q by remember { mutableStateOf("") }
    var open by remember { mutableStateOf(vm.aiKey.isBlank()) }
    val list = rememberLazyListState()
    LaunchedEffect(vm.aiMsgs.size, vm.aiBusy) {
        val n = vm.aiMsgs.size + (if (vm.aiBusy) 1 else 0)
        if (n > 0) list.scrollToItem(n - 1)
    }

    Column(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        ScreenTitle("AI GEMINI", "Tanya soal HP dan game. Jawaban memakai angka HP-mu saat ini.")

        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Txt(
                    if (vm.aiKey.isBlank()) "API KEY BELUM DIISI" else "API KEY TERSIMPAN",
                    Modifier.weight(1f), size = 11,
                    color = if (vm.aiKey.isBlank()) Warn else Good, weight = FontWeight.Bold, spacing = 2f
                )
                SlantButton(if (open) "TUTUP" else "UBAH", filled = false, small = true) { open = !open }
            }
            if (open) {
                Spacer(Modifier.height(8.dp))
                Field(key, { key = it }, "API key Gemini", Modifier.fillMaxWidth(), password = true)
                Spacer(Modifier.height(8.dp))
                Field(model, { model = it }, "Nama model, contoh gemini-3.8-flash", Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Txt(
                    "Buat API key di aistudio.google.com. Key hanya disimpan di HP ini. Saat kamu bertanya, " +
                        "pertanyaan dan ringkasan angka HP dikirim ke Google. Tidak ada yang dikirim otomatis.",
                    size = 12, color = Muted
                )
                Spacer(Modifier.height(8.dp))
                SlantButton("SIMPAN", Modifier.fillMaxWidth(), small = true) {
                    vm.saveAi(key, model)
                    open = false
                }
            }
        }

        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            state = list,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (vm.aiMsgs.isEmpty() && !vm.aiBusy) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Txt("COBA TANYA", size = 11, color = RedGlow, weight = FontWeight.Bold, spacing = 2.5f)
                        SlantButton("Tips setting game di HP-ku", Modifier.fillMaxWidth(), filled = false, small = true) {
                            vm.askAi("Beri tips setting supaya game di HP-ku lebih lancar.")
                        }
                        SlantButton("Kenapa HP-ku cepat panas?", Modifier.fillMaxWidth(), filled = false, small = true) {
                            vm.askAi("Kenapa HP-ku cepat panas dan apa yang bisa kulakukan?")
                        }
                        SlantButton("Cara hemat baterai saat main", Modifier.fillMaxWidth(), filled = false, small = true) {
                            vm.askAi("Bagaimana cara menghemat baterai saat main game tanpa merusak performa?")
                        }
                    }
                }
            }
            itemsIndexed(vm.aiMsgs) { _, m ->
                Box(
                    Modifier.fillMaxWidth().clip(SlantShape(10f))
                        .background(if (m.fromUser) RedDeep else PanelColor)
                        .padding(start = 18.dp, end = 22.dp, top = 10.dp, bottom = 10.dp)
                ) {
                    Txt(m.text, size = 14)
                }
            }
            if (vm.aiBusy) {
                item { Txt("Gemini sedang menjawab...", size = 13, color = Muted, italic = true) }
            }
            if (vm.aiError.isNotEmpty()) {
                item { Txt(vm.aiError, size = 13, color = Warn) }
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Field(q, { q = it }, "Tulis pertanyaan", Modifier.weight(1f))
            SlantButton("KIRIM", enabled = !vm.aiBusy && q.isNotBlank(), small = true) {
                vm.askAi(q)
                q = ""
            }
        }
        if (vm.aiMsgs.isNotEmpty()) {
            SlantButton("HAPUS PERCAKAPAN", Modifier.fillMaxWidth(), filled = false, small = true) { vm.clearAi() }
        }
        Spacer(Modifier.height(6.dp))
    }
}
