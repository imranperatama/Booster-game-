package com.imranperatama.speedxz

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

/**
 * Sesi game: selama game dimainkan layanan ini
 *  - menutup aplikasi non-sistem yang hidup lagi (tiap 30 detik, dari yang paling rakus RAM),
 *  - memantau FPS, CPU, RAM, suhu baterai, suhu zona thermal CPU, dan ping,
 *  - memperingatkan saat HP mulai terlalu panas,
 *  - menampilkan jendela mengambang Xz dan menjawab pertanyaan lewat Gemini,
 *  - mengembalikan pengaturan HP saat game ditutup atau sesi diakhiri.
 * Pemantau berjalan lebih jarang saat panel tertutup supaya tidak mengganggu game.
 */
class GameService : Service() {
    companion object {
        const val EXTRA_PKG = "pkg"
        const val ACTION_STOP = "com.imranperatama.speedxz.STOP"
        private const val CH_RUN = "speedxz_game"
        private const val CH_INFO = "speedxz_info"
        private const val NID_RUN = 41
        private const val NID_INFO = 42
        private const val KILL_EVERY_MS = 30_000L
        private const val BAT_HOT = 43.0
        private const val BAT_OK = 41.0
        private const val SOC_HOT = 75.0
        private const val SOC_OK = 72.0
        private const val HOT_TEXT = "HP OVERHEAT! Turunkan kecerahan / gunakan pendingin"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private var overlay: GameOverlay? = null
    private var pkg = ""
    private var label = ""
    private var apps: List<AppEntry> = emptyList()
    private var startWall = 0L
    private var startElapsed = 0L
    private var ending = false
    private var killedTotal = 0
    private var sumFree = 0L
    private var nFree = 0
    private var maxTemp = 0.0
    private var sumFps = 0L
    private var nFps = 0
    private var heatNotified = false
    private var lastStats: LiveStats? = null
    private var aiBusy = false
    private val aiHistory = ArrayList<AiMsg>()
    private var aiStatus = ""
    private var optBusy = false
    private var lastReport = ""
    private var smartOn = true
    private var netInfo: NetInfo = NetInfo("unknown", -1, 0, "N/A")

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            if (SessionState.active && !ending) endSession() else stopSelf()
            return START_NOT_STICKY
        }
        // Wajib segera menjadi layanan latar depan
        try {
            val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
            ServiceCompat.startForeground(this, NID_RUN, runNotification("Mode Game aktif"), type)
        } catch (e: Throwable) {
            stopSelf()
            return START_NOT_STICKY
        }
        val game: String = intent?.getStringExtra(EXTRA_PKG) ?: ""
        if (game.isEmpty() || SessionState.active) {
            if (!SessionState.active) stopSelf()
            return START_NOT_STICKY
        }
        startSession(game)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        overlay?.stop()
        overlay = null
        scope.cancel()
        super.onDestroy()
    }

    // ---------------- notifikasi ----------------
    private fun nm(): NotificationManager = getSystemService(NotificationManager::class.java)

    private fun ensureChannels() {
        val m = nm()
        if (m.getNotificationChannel(CH_RUN) == null) {
            m.createNotificationChannel(NotificationChannel(CH_RUN, "Mode Game aktif", NotificationManager.IMPORTANCE_LOW))
        }
        if (m.getNotificationChannel(CH_INFO) == null) {
            m.createNotificationChannel(NotificationChannel(CH_INFO, "Ringkasan sesi", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }

    @Suppress("DEPRECATION")
    private fun runNotification(text: String): Notification {
        ensureChannels()
        val stop = PendingIntent.getService(
            this, 1, Intent(this, GameService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CH_RUN)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Speed Xz Mode Game")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(R.drawable.ic_stat, "AKHIRI", stop)
            .build()
    }

    private fun info(id: Int, title: String, text: String) {
        try {
            ensureChannels()
            val n = Notification.Builder(this, CH_INFO)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .build()
            nm().notify(id, n)
        } catch (e: Throwable) {
        }
    }

    // ---------------- sesi ----------------
    private fun labelOf(game: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(game, 0)).toString()
    } catch (e: Throwable) {
        game
    }

    private fun startSession(game: String) {
        pkg = game
        label = labelOf(game)
        ending = false
        killedTotal = 0
        sumFree = 0L
        nFree = 0
        maxTemp = 0.0
        sumFps = 0L
        nFps = 0
        heatNotified = false
        lastStats = null
        aiHistory.clear()
        aiStatus = ""
        aiBusy = false
        optBusy = false
        lastReport = ""
        smartOn = GameEngine.prefs(this).getBoolean("smart", true)
        startWall = System.currentTimeMillis()
        startElapsed = SystemClock.elapsedRealtime()
        SessionState.pkg = game
        SessionState.label = label
        SessionState.version++

        if (Settings.canDrawOverlays(this)) {
            val o = GameOverlay(
                this, label,
                OverlayActions(
                    boost = { boostAgain() },
                    dnd = { toggleDnd() },
                    dim = { toggleDim() },
                    clean = { cleanCache() },
                    ask = { askAi(it) },
                    maxPerf = { maxPerf() },
                    signal = { signalOpt() },
                    smart = { toggleSmart() },
                    end = { endSession() }
                )
            )
            overlay = o
            o.start()
            val ctx = applicationContext
            scope.launch {
                o.setDnd(GameEngine.dndOn(ctx))
                o.setDim(GameEngine.dimOn(ctx))
                o.setSmart(smartOn)
            }
        }
        job = scope.launch { monitor() }
    }

    private fun boostAgain() {
        scope.launch {
            val strict = GameEngine.prefs(applicationContext).getBoolean("strict", true)
            val names = GameEngine.killBackground(applicationContext, pkg, strict, apps)
            killedTotal += names.size
            overlay?.toast(if (names.isEmpty()) "Tidak ada aplikasi lain yang jalan" else "Ditutup ${names.size} aplikasi")
        }
    }

    private fun toggleDnd() {
        val ctx = applicationContext
        scope.launch {
            val now = GameEngine.dndOn(ctx)
            val ok = GameEngine.setDnd(ctx, !now)
            if (!ok) {
                overlay?.toast("Butuh akses Jangan Ganggu atau Shizuku (tab SETUP)")
                return@launch
            }
            overlay?.setDnd(!now)
            overlay?.toast(if (!now) "Jangan ganggu aktif" else "Jangan ganggu mati")
        }
    }

    private fun toggleDim() {
        val ctx = applicationContext
        scope.launch {
            val now = GameEngine.dimOn(ctx)
            val ok = GameEngine.setDim(ctx, !now)
            if (!ok) {
                overlay?.toast("Butuh Shizuku")
                return@launch
            }
            overlay?.setDim(!now)
            overlay?.toast(if (!now) "Layar diredupkan" else "Kecerahan dikembalikan")
        }
    }

    private fun cleanCache() {
        scope.launch {
            val ok = GameEngine.trimCaches()
            overlay?.toast(if (ok) "Cache dibersihkan" else "Butuh Shizuku")
        }
    }

    // ---------------- AI ----------------
    private fun num(v: Int, unit: String): String = if (v >= 0) "$v$unit" else "N/A"

    private fun aiContext(): String {
        val ctx = applicationContext
        val f = Device.facts(ctx)
        val mem = Device.memory(ctx)
        val s = lastStats
        val sb = StringBuilder(Gemini.SYSTEM)
        sb.append("\nDATA HP: ").append(f.name).append(", ").append(f.android)
            .append(", chip ").append(f.chip).append(", ").append(f.cores).append(" inti, RAM ")
            .append(mem.first).append(" MB total.")
        sb.append(" Game: ").append(label).append(".")
        if (s != null) {
            sb.append(" FPS ").append(num(s.fps, ""))
                .append(", CPU ").append(num(s.cpu, "%"))
                .append(", RAM bebas ").append(s.freeMb).append(" MB")
                .append(", suhu baterai ").append(String.format("%.1f", s.temp)).append(" C")
                .append(", suhu CPU ").append(if (s.zone >= 0) String.format("%.0f C", s.zone) else "N/A")
                .append(", thermal ").append(s.thermal)
                .append(", ping ").append(num(s.pingMs, " ms"))
                .append(", jaringan ").append(s.net)
                .append(", sesi ").append(s.elapsedSec / 60).append(" menit")
                .append(", aplikasi latar ditutup ").append(s.killed).append(".")
        }
        if (lastReport.isNotEmpty()) {
            sb.append(" Hasil optimasi terakhir: ").append(lastReport.replace("\n", " ")).append(".")
        }
        return sb.toString()
    }

    private fun pushChat() {
        overlay?.setChat(ArrayList(aiHistory), aiStatus)
    }

    private fun askAi(text: String) {
        val q = text.trim()
        if (q.isEmpty()) return
        if (aiBusy) {
            overlay?.toast("Tunggu jawaban sebelumnya")
            return
        }
        val p = GameEngine.prefs(applicationContext)
        val key = p.getString("ai_key", "") ?: ""
        if (key.isBlank()) {
            aiStatus = "API key Gemini belum diisi. Buka aplikasi Speed Xz, tab SETUP, kolom Kunci AI."
            pushChat()
            return
        }
        val model = p.getString("ai_model", Gemini.DEFAULT_MODEL) ?: Gemini.DEFAULT_MODEL
        aiBusy = true
        aiStatus = "Gemini sedang menjawab..."
        aiHistory.add(AiMsg(true, q))
        pushChat()
        val system = aiContext()
        var hist: List<AiMsg> = aiHistory.takeLast(8).toList()
        if (hist.isNotEmpty() && !hist.first().fromUser) hist = hist.drop(1)
        scope.launch {
            val r = Gemini.ask(key, model, system, hist)
            if (r.ok) {
                aiHistory.add(AiMsg(false, r.text))
                aiStatus = ""
            } else {
                // buang pertanyaan yang gagal supaya riwayat tetap bergantian user dan model
                if (aiHistory.isNotEmpty()) aiHistory.removeAt(aiHistory.size - 1)
                aiStatus = r.text
            }
            aiBusy = false
            pushChat()
        }
    }

    // ---------------- Optimalkan ----------------
    private fun maxPerf() {
        if (optBusy) {
            overlay?.toast("Masih berjalan")
            return
        }
        optBusy = true
        overlay?.setOpt("Memeriksa suhu, RAM, dan menerapkan optimasi...")
        val ctx = applicationContext
        val zone = lastStats?.zone ?: -1.0
        scope.launch {
            try {
                val strict = GameEngine.prefs(ctx).getBoolean("strict", true)
                val r = GameEngine.maxPerformance(ctx, pkg, strict, apps, zone)
                killedTotal += r.killed
                lastReport = r.text
                overlay?.setOpt(r.text)
            } catch (e: Throwable) {
                overlay?.setOpt("Gagal mengoptimalkan: ${e.message}")
            }
            optBusy = false
        }
    }

    private fun signalOpt() {
        if (optBusy) {
            overlay?.toast("Masih berjalan")
            return
        }
        optBusy = true
        overlay?.setOpt("Mengukur jaringan dan menyetel sinyal...")
        val ctx = applicationContext
        scope.launch {
            try {
                val strict = GameEngine.prefs(ctx).getBoolean("strict", true)
                val r = GameEngine.optimizeSignal(ctx, pkg, strict, apps)
                killedTotal += r.killed
                lastReport = r.text
                overlay?.setOpt(r.text)
            } catch (e: Throwable) {
                overlay?.setOpt("Gagal menyetel sinyal: ${e.message}")
            }
            optBusy = false
        }
    }

    private fun toggleSmart() {
        smartOn = !smartOn
        GameEngine.prefs(applicationContext).edit().putBoolean("smart", smartOn).apply()
        overlay?.setSmart(smartOn)
        overlay?.toast(if (smartOn) "Auto pintar aktif" else "Auto pintar mati")
    }

    private fun endSession() {
        if (ending) return
        ending = true
        job?.cancel()
        val dur = ((SystemClock.elapsedRealtime() - startElapsed) / 1000L).toInt()
        val rec = SessionRec(
            label, startWall, dur,
            if (nFree > 0) (sumFree / nFree).toInt() else 0,
            maxTemp,
            if (nFps > 0) (sumFps / nFps).toInt() else -1,
            killedTotal
        )
        overlay?.stop()
        overlay = null
        val appCtx = applicationContext
        scope.launch(Dispatchers.IO) {
            val ok = GameEngine.restore(appCtx)
            SessionLog.add(appCtx, rec)
            withContext(Dispatchers.Main) {
                SessionState.pkg = ""
                SessionState.label = ""
                SessionState.version++
                val fpsText = if (rec.avgFps >= 0) "${rec.avgFps}" else "N/A"
                info(
                    NID_INFO, "Sesi ${rec.label} selesai",
                    "Durasi ${rec.durSec / 60} menit ${rec.durSec % 60} detik. RAM bebas rata-rata ${rec.avgFreeMb} MB, " +
                        "FPS rata-rata $fpsText, suhu baterai tertinggi ${String.format("%.1f", rec.maxTemp)} C, " +
                        "${rec.killed} aplikasi ditutup. " +
                        if (ok) "Pengaturan HP sudah dikembalikan." else "Pengaturan belum bisa dikembalikan: buka Speed Xz lalu tekan Kembalikan Normal."
                )
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    // ---------------- pemantau ----------------
    private val markers = listOf("##GAME", "##FPS", "##TEMP")

    private fun section(lines: List<String>, name: String): List<String>? {
        val i = lines.indexOf(name)
        if (i < 0) return null
        var end = lines.size
        for (m in markers) {
            val j = lines.indexOf(m)
            if (j > i && j < end) end = j
        }
        return lines.subList(i + 1, end)
    }

    private suspend fun monitor() {
        val ctx = applicationContext
        val prefs = GameEngine.prefs(ctx)
        apps = withContext(Dispatchers.IO) { GameEngine.thirdParty(ctx) }
        var missing = 0
        var layer: String? = null
        var noFps = 0
        var lastTotal = 0L
        var lastIdle = 0L
        var ping = -1
        var zone = -1.0
        var hot = false
        var lastKill = SystemClock.elapsedRealtime()
        var lastPing = 0L
        var lastZone = 0L
        var lastLayerTry = 0L
        var lastHotToast = 0L
        var lastNet = 0L
        var lastSmart = SystemClock.elapsedRealtime()

        while (scope.isActive && !ending) {
            val now = SystemClock.elapsedRealtime()
            val open = overlay?.isPanelOpen() == true
            val shz = Sh.granted()
            var cpu = -1
            var fps = -1

            if (shz) {
                if (layer == null && now - lastLayerTry > 10_000L) {
                    lastLayerTry = now
                    layer = pickLayer(Sh.run("dumpsys SurfaceFlinger --list | grep -F '$pkg'").out)
                }
                val needZone = now - lastZone >= 10_000L
                val sb = StringBuilder("head -n 1 /proc/stat; echo '##GAME'; ps -A -o NAME | grep -x -F '$pkg'")
                val lay = layer
                if (lay != null) sb.append("; echo '##FPS'; dumpsys SurfaceFlinger --latency '$lay'")
                if (needZone) {
                    sb.append("; echo '##TEMP'; for z in /sys/class/thermal/thermal_zone*; do ")
                    sb.append("echo \"\$(cat \$z/type 2>/dev/null) \$(cat \$z/temp 2>/dev/null)\"; done")
                }
                val r = Sh.run(sb.toString())
                if (r.code != -1 && r.code != -2) {
                    val lines = r.out.lines().map { it.trim() }
                    val cur = parseCpuLine(lines.firstOrNull() ?: "")
                    if (cur != null) {
                        val dT = cur.first - lastTotal
                        val dI = cur.second - lastIdle
                        if (lastTotal != 0L && dT > 0) cpu = (((dT - dI) * 100) / dT).toInt().coerceIn(0, 100)
                        lastTotal = cur.first
                        lastIdle = cur.second
                    }
                    section(lines, "##GAME")?.let { g ->
                        missing = if (g.any { it == pkg }) 0 else missing + 1
                    }
                    section(lines, "##FPS")?.let { f ->
                        fps = parseFps(f)
                        if (fps < 0) noFps++ else noFps = 0
                        if (noFps >= 5) {
                            layer = null
                            noFps = 0
                        }
                    }
                    if (needZone) {
                        zone = section(lines, "##TEMP")?.let { parseZone(it) } ?: -1.0
                        lastZone = now
                    }
                }
                // game ditutup (beri waktu 30 detik untuk game yang masih memuat)
                if (now - startElapsed > 30_000L && missing >= 3) {
                    withContext(Dispatchers.Main) { endSession() }
                    break
                }
            }

            // penutup aplikasi latar berkala
            if (now - lastKill >= KILL_EVERY_MS) {
                lastKill = now
                val strict = prefs.getBoolean("strict", true)
                val names = GameEngine.killBackground(ctx, pkg, strict, apps)
                if (names.isNotEmpty()) {
                    killedTotal += names.size
                    if (open) overlay?.toast("Ditutup ${names.size} aplikasi latar")
                }
            }

            if (now - lastPing >= (if (open) 10_000L else 30_000L)) {
                lastPing = now
                ping = withContext(Dispatchers.IO) { Net.pingMs() }
            }
            if (now - lastNet >= (if (open) 10_000L else 30_000L)) {
                lastNet = now
                netInfo = withContext(Dispatchers.IO) { Net.read(ctx) }
            }

            val mem = Device.memory(ctx)
            val b = Device.battery(ctx)
            sumFree += mem.second
            nFree++
            if (b.temp > maxTemp) maxTemp = b.temp
            if (fps > 0) {
                sumFps += fps
                nFps++
            }

            // peringatan overheat dengan histeresis supaya tidak berkedip terus
            val nowHot = b.temp >= BAT_HOT || zone >= SOC_HOT || (hot && (b.temp >= BAT_OK || zone >= SOC_OK))
            if (nowHot != hot) {
                hot = nowHot
                overlay?.setWarn(hot, HOT_TEXT)
                if (hot) {
                    overlay?.toastLong(HOT_TEXT)
                    lastHotToast = now
                    if (!heatNotified) {
                        heatNotified = true
                        info(
                            NID_INFO + 1, "HP mulai panas",
                            "Suhu baterai ${String.format("%.1f", b.temp)} C. Turunkan kecerahan atau pakai pendingin supaya performa tidak turun."
                        )
                    }
                }
            } else if (hot && now - lastHotToast > 90_000L) {
                overlay?.toastLong(HOT_TEXT)
                lastHotToast = now
            }

            // mode pintar: jaga RAM dan suhu tanpa diminta
            if (smartOn && !ending && now - lastSmart >= 60_000L) {
                lastSmart = now
                val ramLow = mem.first > 0 && mem.second * 100 / mem.first < 12
                if (ramLow) {
                    val names = GameEngine.killBackground(ctx, pkg, prefs.getBoolean("strict", true), apps)
                    if (shz) GameEngine.trimCaches()
                    killedTotal += names.size
                    if (open) overlay?.toast("Pintar: RAM sempit, ${names.size} aplikasi ditutup")
                }
                if (shz) {
                    val locked = GameEngine.perfLocked(ctx)
                    if (hot && locked) {
                        GameEngine.setPerfLock(ctx, false)
                        if (open) overlay?.toast("Pintar: HP panas, performa tetap dilepas")
                    } else if (!hot && !locked && prefs.getBoolean("perf", true)) {
                        GameEngine.setPerfLock(ctx, true)
                    }
                }
            }

            val st = LiveStats(
                fps, cpu, mem.second, mem.first, b.temp, zone, thermalName(), ping, netInfo.label,
                ((now - startElapsed) / 1000L).toInt(), killedTotal
            )
            lastStats = st
            overlay?.update(st)
            delay(if (open) 2000L else 6000L)
        }
    }

    private fun parseCpuLine(line: String): Pair<Long, Long>? {
        val parts = line.trim().split(Regex("\\s+"))
        if (parts.size < 8 || parts[0] != "cpu") return null
        val nums = parts.drop(1).take(8).mapNotNull { it.toLongOrNull() }
        if (nums.size < 8) return null
        return Pair(nums.sum(), nums[3] + nums[4])
    }

    private fun pickLayer(out: String): String? {
        val cands = out.lines().map { it.trim() }.filter { it.isNotEmpty() && it.contains(pkg) && !it.contains('\'') }
        return cands.firstOrNull { it.startsWith("SurfaceView") }
            ?: cands.firstOrNull { it.contains("BLAST") }
            ?: cands.firstOrNull()
    }

    /** Baris pertama: periode refresh. Baris berikutnya: tiga waktu (ns). Kolom kedua = waktu tampil. */
    private fun parseFps(lines: List<String>): Int {
        val times = ArrayList<Long>()
        for (l in lines.drop(1)) {
            val p = l.trim().split(Regex("\\s+"))
            if (p.size < 3) continue
            val t = p[1].toLongOrNull() ?: continue
            if (t > 0L && t < Long.MAX_VALUE / 2) times.add(t)
        }
        if (times.size < 10) return -1
        val span = times.last() - times.first()
        if (span <= 0L) return -1
        return ((times.size - 1) * 1_000_000_000.0 / span).roundToInt().coerceIn(1, 240)
    }

    /**
     * Baca /sys/class/thermal/thermal_zone* lewat Shizuku dan ambil suhu tertinggi dari zona CPU/SoC/GPU.
     * Satuan sensor berbeda tiap HP (miliderajat atau derajat), jadi dinormalkan dulu.
     */
    private fun parseZone(lines: List<String>): Double {
        var best = -1.0
        for (l in lines) {
            val p = l.trim().split(Regex("\\s+"))
            if (p.size < 2) continue
            val raw = p.last().toLongOrNull() ?: continue
            val type = p.dropLast(1).joinToString(" ").lowercase()
            val chip = listOf("cpu", "soc", "tsens", "cluster", "gpu", "big", "little", "mtk", "apc").any { type.contains(it) }
            if (!chip || type.contains("batt")) continue
            val t = when {
                raw > 1000L -> raw / 1000.0
                raw > 200L -> raw / 10.0
                else -> raw.toDouble()
            }
            if (t in 15.0..130.0 && t > best) best = t
        }
        return best
    }

    private fun thermalName(): String {
        if (Build.VERSION.SDK_INT < 29) return "N/A"
        return try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            when (pm.currentThermalStatus) {
                0 -> "Aman"
                1 -> "Ringan"
                2 -> "Sedang"
                3 -> "Berat"
                4 -> "Kritis"
                else -> "Darurat"
            }
        } catch (e: Throwable) {
            "N/A"
        }
    }
}
