package com.imranperatama.speedxz

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

/**
 * Sesi game: selama game dimainkan layanan ini
 *  - menutup aplikasi non-sistem yang hidup lagi (tiap sekitar 16 detik),
 *  - memantau FPS, CPU, RAM, suhu, thermal, dan ping,
 *  - menampilkan jendela mengambang Xz,
 *  - mengembalikan pengaturan HP saat game ditutup atau sesi diakhiri.
 */
class GameService : Service() {
    companion object {
        const val EXTRA_PKG = "pkg"
        const val ACTION_STOP = "com.imranperatama.speedxz.STOP"
        private const val CH_RUN = "speedxz_game"
        private const val CH_INFO = "speedxz_info"
        private const val NID_RUN = 41
        private const val NID_INFO = 42
        private const val PING_HOST = "8.8.8.8"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private var overlay: GameOverlay? = null
    private var pkg = ""
    private var label = ""
    private var apps: List<AppEntry> = emptyList()
    private var startWall = 0L
    private var startElapsed = 0L
    private var ending = false
    private var killedTotal = 0
    private var sumFree = 0L
    private var nFree = 0
    private var maxTemp = 0.0
    private var sumFps = 0L
    private var nFps = 0
    private var heatAlerted = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            if (SessionState.active && !ending) endSession() else stopSelf()
            return START_NOT_STICKY
        }
        // Wajib segera menjadi layanan latar depan
        try {
            val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
            ServiceCompat.startForeground(this, NID_RUN, runNotification("Mode Game aktif"), type)
        } catch (e: Throwable) {
            stopSelf()
            return START_NOT_STICKY
        }
        val game: String = intent?.getStringExtra(EXTRA_PKG) ?: ""
        if (game.isEmpty() || SessionState.active) {
            if (!SessionState.active) stopSelf()
            return START_NOT_STICKY
        }
        startSession(game)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        overlay?.stop()
        overlay = null
        scope.cancel()
        super.onDestroy()
    }

    // ---------------- notifikasi ----------------
    private fun nm(): NotificationManager = getSystemService(NotificationManager::class.java)

    private fun ensureChannels() {
        val m = nm()
        if (m.getNotificationChannel(CH_RUN) == null) {
            m.createNotificationChannel(NotificationChannel(CH_RUN, "Mode Game aktif", NotificationManager.IMPORTANCE_LOW))
        }
        if (m.getNotificationChannel(CH_INFO) == null) {
            m.createNotificationChannel(NotificationChannel(CH_INFO, "Ringkasan sesi", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }

    @Suppress("DEPRECATION")
    private fun runNotification(text: String): Notification {
        ensureChannels()
        val stop = PendingIntent.getService(
            this, 1, Intent(this, GameService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CH_RUN)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Speed Xz Mode Game")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(R.drawable.ic_stat, "AKHIRI", stop)
            .build()
    }

    private fun info(id: Int, title: String, text: String) {
        try {
            ensureChannels()
            val n = Notification.Builder(this, CH_INFO)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .build()
            nm().notify(id, n)
        } catch (e: Throwable) {
        }
    }

    // ---------------- sesi ----------------
    private fun labelOf(game: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(game, 0)).toString()
    } catch (e: Throwable) {
        game
    }

    private fun startSession(game: String) {
        pkg = game
        label = labelOf(game)
        ending = false
        killedTotal = 0
        sumFree = 0L
        nFree = 0
        maxTemp = 0.0
        sumFps = 0L
        nFps = 0
        heatAlerted = false
        startWall = System.currentTimeMillis()
        startElapsed = SystemClock.elapsedRealtime()
        SessionState.pkg = game
        SessionState.label = label
        SessionState.version++

        if (Settings.canDrawOverlays(this)) {
            val o = GameOverlay(this, label, { boostAgain() }, { toggleDnd() }, { endSession() })
            o.setDnd(GameEngine.prefs(this).getBoolean("dnd", true) && Sh.granted())
            o.start()
            overlay = o
        }
        job = scope.launch { monitor() }
    }

    private fun boostAgain() {
        scope.launch {
            val strict = GameEngine.prefs(applicationContext).getBoolean("strict", true)
            val names = GameEngine.killBackground(applicationContext, pkg, strict, apps)
            killedTotal += names.size
            overlay?.toast(if (names.isEmpty()) "Tidak ada aplikasi lain yang jalan" else "Ditutup ${names.size} aplikasi")
        }
    }

    private fun toggleDnd() {
        scope.launch(Dispatchers.IO) {
            if (!Sh.granted()) {
                overlay?.toast("Butuh Shizuku")
                return@launch
            }
            val on = Sh.run("settings get global zen_mode").out.trim() == "1"
            Sh.run("settings put global zen_mode ${if (on) 0 else 1}")
            overlay?.setDnd(!on)
            overlay?.toast(if (!on) "Jangan ganggu aktif" else "Jangan ganggu mati")
        }
    }

    private fun endSession() {
        if (ending) return
        ending = true
        job?.cancel()
        val dur = ((SystemClock.elapsedRealtime() - startElapsed) / 1000L).toInt()
        val rec = SessionRec(
            label, startWall, dur,
            if (nFree > 0) (sumFree / nFree).toInt() else 0,
            maxTemp,
            if (nFps > 0) (sumFps / nFps).toInt() else -1,
            killedTotal
        )
        overlay?.stop()
        overlay = null
        val appCtx = applicationContext
        scope.launch(Dispatchers.IO) {
            val ok = GameEngine.restore(appCtx)
            SessionLog.add(appCtx, rec)
            withContext(Dispatchers.Main) {
                SessionState.pkg = ""
                SessionState.label = ""
                SessionState.version++
                val fpsText = if (rec.avgFps >= 0) "${rec.avgFps}" else "N/A"
                info(
                    NID_INFO, "Sesi ${rec.label} selesai",
                    "Durasi ${rec.durSec / 60} menit ${rec.durSec % 60} detik. RAM bebas rata-rata ${rec.avgFreeMb} MB, " +
                        "FPS rata-rata $fpsText, suhu tertinggi ${String.format("%.1f", rec.maxTemp)} C, " +
                        "${rec.killed} aplikasi ditutup. " +
                        if (ok) "Pengaturan HP sudah dikembalikan." else "Pengaturan belum bisa dikembalikan: buka Speed Xz lalu tekan Kembalikan Normal."
                )
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    // ---------------- pemantau ----------------
    private suspend fun monitor() {
        val ctx = applicationContext
        val prefs = GameEngine.prefs(ctx)
        apps = withContext(Dispatchers.IO) { GameEngine.thirdParty(ctx) }
        var tick = 0
        var missing = 0
        var layer: String? = null
        var noFps = 0
        var lastTotal = 0L
        var lastIdle = 0L
        var ping = -1

        while (scope.isActive && !ending) {
            val shz = Sh.granted()
            var cpu = -1
            var fps = -1

            if (shz) {
                // cari lapisan layar game untuk FPS
                if (layer == null && tick % 5 == 0) {
                    val l = Sh.run("dumpsys SurfaceFlinger --list | grep -F '$pkg'")
                    layer = pickLayer(l.out)
                }
                val sb = StringBuilder("head -n 1 /proc/stat; echo '##GAME'; ps -A -o NAME | grep -x -F '$pkg'")
                val lay = layer
                if (lay != null) sb.append("; echo '##FPS'; dumpsys SurfaceFlinger --latency '$lay'")
                val r = Sh.run(sb.toString())
                if (r.code != -1 && r.code != -2) {
                    val lines = r.out.lines()
                    val iGame = lines.indexOf("##GAME")
                    val iFps = lines.indexOf("##FPS")
                    val cur = parseCpuLine(lines.firstOrNull() ?: "")
                    if (cur != null) {
                        val dT = cur.first - lastTotal
                        val dI = cur.second - lastIdle
                        if (lastTotal != 0L && dT > 0) cpu = (((dT - dI) * 100) / dT).toInt().coerceIn(0, 100)
                        lastTotal = cur.first
                        lastIdle = cur.second
                    }
                    if (iGame >= 0) {
                        val end = if (iFps >= 0) iFps else lines.size
                        val running = lines.subList(iGame + 1, end).any { it.trim() == pkg }
                        if (running) missing = 0 else missing++
                    }
                    if (iFps >= 0) {
                        fps = parseFps(lines.subList(iFps + 1, lines.size))
                        if (fps < 0) noFps++ else noFps = 0
                        if (noFps >= 5) {
                            layer = null
                            noFps = 0
                        }
                    }
                }
                // game ditutup (beri waktu 24 detik untuk game yang masih memuat)
                if (tick > 12 && missing >= 3) {
                    withContext(Dispatchers.Main) { endSession() }
                    break
                }
            }

            // penutup aplikasi latar berkala
            if (tick % 8 == 2) {
                val strict = prefs.getBoolean("strict", true)
                val names = GameEngine.killBackground(ctx, pkg, strict, apps)
                if (names.isNotEmpty()) {
                    killedTotal += names.size
                    overlay?.toast("Ditutup ${names.size} aplikasi latar")
                }
            }

            if (tick % 5 == 0) ping = withContext(Dispatchers.IO) { pingMs() }

            val mem = Device.memory(ctx)
            val b = Device.battery(ctx)
            sumFree += mem.second
            nFree++
            if (b.temp > maxTemp) maxTemp = b.temp
            if (fps > 0) {
                sumFps += fps
                nFps++
            }
            if (b.temp >= 43.0 && !heatAlerted) {
                heatAlerted = true
                info(NID_INFO + 1, "HP mulai panas", "Suhu baterai ${String.format("%.1f", b.temp)} C. Istirahat sebentar agar tidak menurun performanya.")
            }
            overlay?.update(
                LiveStats(
                    fps, cpu, mem.second, b.temp, thermalName(), ping,
                    ((SystemClock.elapsedRealtime() - startElapsed) / 1000L).toInt(), killedTotal
                )
            )
            tick++
            delay(2000)
        }
    }

    private fun parseCpuLine(line: String): Pair<Long, Long>? {
        val parts = line.trim().split(Regex("\\s+"))
        if (parts.size < 8 || parts[0] != "cpu") return null
        val nums = parts.drop(1).take(8).mapNotNull { it.toLongOrNull() }
        if (nums.size < 8) return null
        return Pair(nums.sum(), nums[3] + nums[4])
    }

    private fun pickLayer(out: String): String? {
        val cands = out.lines().map { it.trim() }.filter { it.isNotEmpty() && it.contains(pkg) && !it.contains('\'') }
        return cands.firstOrNull { it.startsWith("SurfaceView") }
            ?: cands.firstOrNull { it.contains("BLAST") }
            ?: cands.firstOrNull()
    }

    /** Baris pertama: periode refresh. Baris berikutnya: tiga waktu (ns). Kolom kedua = waktu tampil. */
    private fun parseFps(lines: List<String>): Int {
        val times = ArrayList<Long>()
        for (l in lines.drop(1)) {
            val p = l.trim().split(Regex("\\s+"))
            if (p.size < 3) continue
            val t = p[1].toLongOrNull() ?: continue
            if (t > 0L && t < Long.MAX_VALUE / 2) times.add(t)
        }
        if (times.size < 10) return -1
        val span = times.last() - times.first()
        if (span <= 0L) return -1
        return ((times.size - 1) * 1_000_000_000.0 / span).roundToInt().coerceIn(1, 240)
    }

    private fun thermalName(): String {
        if (Build.VERSION.SDK_INT < 29) return "N/A"
        return try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            when (pm.currentThermalStatus) {
                0 -> "Aman"
                1 -> "Ringan"
                2 -> "Sedang"
                3 -> "Berat"
                4 -> "Kritis"
                else -> "Darurat"
            }
        } catch (e: Throwable) {
            "N/A"
        }
    }

    private fun pingMs(): Int = try {
        val p = ProcessBuilder("ping", "-c", "1", "-W", "1", PING_HOST).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().use { it.readText() }
        p.waitFor(3, TimeUnit.SECONDS)
        val m = Regex("time=([0-9.]+)").find(out)
        if (m != null) m.groupValues[1].toDouble().roundToInt() else -1
    } catch (e: Throwable) {
        -1
    }
}
