package com.imranperatama.speedxz

import android.app.ActivityManager
import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import kotlin.math.max
import kotlin.math.roundToInt

data class AppEntry(val pkg: String, val label: String, val isGame: Boolean)
data class PermEntry(val pkg: String, val label: String, val granted: List<String>)
data class Notice(val text: String, val needSetup: Boolean)

val SENSITIVE: Map<String, String> = linkedMapOf(
    "android.permission.CAMERA" to "KAMERA",
    "android.permission.RECORD_AUDIO" to "MIKROFON",
    "android.permission.ACCESS_FINE_LOCATION" to "LOKASI",
    "android.permission.ACCESS_BACKGROUND_LOCATION" to "LOKASI LATAR",
    "android.permission.READ_SMS" to "SMS",
    "android.permission.READ_CONTACTS" to "KONTAK"
)

private val DEFAULT_KEEP = setOf(
    "com.whatsapp",
    "com.whatsapp.w4b",
    "org.telegram.messenger",
    "com.google.android.apps.messaging",
    "com.android.vending"
)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context = app.applicationContext
    private val prefs = ctx.getSharedPreferences("speedxz", Context.MODE_PRIVATE)

    // ---------- Intro ----------
    var introOn by mutableStateOf(!prefs.getBoolean("intro_seen", false))
        private set

    fun finishIntro() {
        prefs.edit().putBoolean("intro_seen", true).apply()
        introOn = false
    }

    fun replayIntro() {
        introOn = true
    }

    // ---------- Shizuku ----------
    var shzInstalled by mutableStateOf(false)
        private set
    var shzRunning by mutableStateOf(false)
        private set
    var shzGranted by mutableStateOf(false)
        private set
    var shzUid by mutableStateOf(-1)
        private set
    val shzReady: Boolean get() = shzRunning && shzGranted

    // ---------- Pengaturan pengembang ----------
    var devOn by mutableStateOf(false)
        private set
    var usbOn by mutableStateOf(false)
        private set
    var wifiOn by mutableStateOf(false)
        private set
    var secureOk by mutableStateOf(false)
        private set
    val adbCommand: String
        get() = "adb shell pm grant ${ctx.packageName} android.permission.WRITE_SECURE_SETTINGS"

    // ---------- Info HP ----------
    val facts: DeviceFacts = Device.facts(ctx)
    var ramTotal by mutableStateOf(0L)
        private set
    var ramAvail by mutableStateOf(0L)
        private set
    var stoTotal by mutableStateOf(0.0)
        private set
    var stoFree by mutableStateOf(0.0)
        private set
    var batt by mutableStateOf(Batt())
        private set
    var cpu by mutableStateOf(-1)
        private set
    var saverOn by mutableStateOf(false)
        private set

    // ---------- Status kerja ----------
    var busy by mutableStateOf<String?>(null)
        private set
    val log = mutableStateListOf<String>()
    var lastClean by mutableStateOf("")
        private set
    var notice by mutableStateOf<Notice?>(null)
        private set
    private var noticeJob: Job? = null

    // ---------- Aplikasi ----------
    var thirdParty by mutableStateOf<List<AppEntry>>(emptyList())
        private set
    var perms by mutableStateOf<List<PermEntry>>(emptyList())
        private set
    var scanned by mutableStateOf(false)
        private set
    var showAll by mutableStateOf(false)
    val keep = mutableStateListOf<String>()

    // ---------- Opsi Mode Game ----------
    var optDnd by mutableStateOf(prefs.getBoolean("dnd", true))
        private set
    var optAnim by mutableStateOf(prefs.getBoolean("anim", true))
        private set
    var optHz by mutableStateOf(prefs.getBoolean("hz", true))
        private set
    var optPerf by mutableStateOf(prefs.getBoolean("perf", true))
        private set
    var gameActive by mutableStateOf(prefs.getString("game_pkg", "") ?: "")
        private set

    private var lastTotal = 0L
    private var lastIdle = 0L

    private val onBinder = Shizuku.OnBinderReceivedListener {
        refreshShizuku()
        loadApps()
    }
    private val onDead = Shizuku.OnBinderDeadListener { refreshShizuku() }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, result ->
        refreshShizuku()
        if (result == PackageManager.PERMISSION_GRANTED) {
            say("Izin Shizuku diberikan. Semua fungsi penuh sekarang aktif.")
        } else {
            say("Izin ditolak. Tekan Beri Izin lagi lalu pilih Izinkan.", true)
        }
    }

    init {
        keep.addAll(prefs.getStringSet("keep", null) ?: DEFAULT_KEEP)
        try {
            Shizuku.addBinderReceivedListenerSticky(onBinder)
            Shizuku.addBinderDeadListener(onDead)
            Shizuku.addRequestPermissionResultListener(onPerm)
        } catch (e: Throwable) {
        }
        refreshShizuku()
        loadApps()
        viewModelScope.launch {
            while (true) {
                refreshLive()
                delay(2500)
            }
        }
    }

    override fun onCleared() {
        try {
            Shizuku.removeBinderReceivedListener(onBinder)
            Shizuku.removeBinderDeadListener(onDead)
            Shizuku.removeRequestPermissionResultListener(onPerm)
        } catch (e: Throwable) {
        }
        super.onCleared()
    }

    /** Catat ke riwayat dan tampilkan bar pesan di semua layar. needSetup menambah tombol HUBUNGKAN. */
    fun say(msg: String, needSetup: Boolean = false) {
        log.add(0, msg)
        while (log.size > 40) log.removeAt(log.size - 1)
        notice = Notice(msg, needSetup)
        noticeJob?.cancel()
        noticeJob = viewModelScope.launch {
            delay(6000)
            notice = null
        }
    }

    fun dismissNotice() {
        notice = null
    }

    private fun startFirst(intents: List<Intent>): Boolean {
        for (i in intents) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                ctx.startActivity(i)
                return true
            } catch (e: Throwable) {
            }
        }
        return false
    }

    fun refreshDev() {
        devOn = DevSetup.devOptionsOn(ctx)
        usbOn = DevSetup.usbOn(ctx)
        wifiOn = DevSetup.wifiOn(ctx)
        secureOk = DevSetup.hasSecure(ctx)
    }

    fun refreshShizuku() {
        shzInstalled = try {
            ctx.packageManager.getPackageInfo(Sh.SHIZUKU_PKG, 0)
            true
        } catch (e: Throwable) {
            false
        }
        shzRunning = Sh.binderAlive()
        shzGranted = Sh.granted()
        shzUid = if (shzRunning) Sh.uid() else -1
        refreshDev()
    }

    fun requestShizuku() {
        refreshShizuku()
        when {
            !shzInstalled -> say("Shizuku belum terpasang. Lakukan langkah 1.", false)
            !shzRunning -> say("Shizuku belum berjalan. Lakukan langkah 4: buka Shizuku lalu Mulai.", false)
            shzGranted -> say("Izin sudah diberikan.")
            else -> if (!Sh.requestPermission()) say("Gagal meminta izin Shizuku.")
        }
    }

    // ---------- Tombol pengaturan ----------
    fun openShizuku() {
        val launch = ctx.packageManager.getLaunchIntentForPackage(Sh.SHIZUKU_PKG)
        val list = ArrayList<Intent>()
        if (launch != null) {
            list.add(launch)
        } else {
            list.add(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${Sh.SHIZUKU_PKG}")))
            list.add(Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/RikkaApps/Shizuku/releases")))
        }
        if (!startFirst(list)) say("Tidak bisa membuka. Cari Shizuku di Play Store.")
    }

    fun openSettings(kind: String) {
        if (!startFirst(DevSetup.intentsFor(kind))) {
            say("Tidak bisa membuka pengaturan. Buka manual: Pengaturan, lalu Tentang ponsel.")
        }
    }

    fun copy(text: String) {
        try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("speedxz", text))
            say("Perintah disalin.")
        } catch (e: Throwable) {
            say("Gagal menyalin.")
        }
    }

    private suspend fun grantSecure(): Boolean = withContext(Dispatchers.IO) {
        val a = Sh.run("pm grant ${ctx.packageName} android.permission.WRITE_SECURE_SETTINGS")
        // Izin ini juga membuat Shizuku bisa mulai sendiri setelah HP restart (Android 13+).
        Sh.run("pm grant ${Sh.SHIZUKU_PKG} android.permission.WRITE_SECURE_SETTINGS")
        a.ok
    }

    /** Langkah 6: beri Speed Xz izin pengaturan aman, sekali saja, lewat Shizuku. */
    fun grantAuto() {
        if (!shzReady) {
            say("Langkah 6 butuh Shizuku jalan dulu (langkah 1 sampai 5). Atau pakai perintah komputer di bawah.")
            return
        }
        viewModelScope.launch {
            val ok = grantSecure()
            refreshDev()
            say(
                if (ok) "Izin otomatis diberikan. Tombol Nyalakan Debug Otomatis sekarang berfungsi."
                else "Gagal memberi izin. Pakai perintah komputer di bawah."
            )
        }
    }

    /** Tombol besar: nyalakan Opsi Pengembang dan Debug sekaligus kalau izinnya sudah ada. */
    fun autoEnable() {
        viewModelScope.launch {
            if (!DevSetup.hasSecure(ctx) && shzReady) grantSecure()
            if (DevSetup.hasSecure(ctx)) {
                val ok = DevSetup.enableAll(ctx)
                refreshDev()
                say(
                    if (ok) "Opsi pengembang dan debug dinyalakan. Debug nirkabel butuh Wi-Fi tersambung."
                    else "Sistem menolak perubahan. Nyalakan manual lewat langkah 2 dan 3."
                )
            } else {
                say("Tombol ini butuh izin sekali: selesaikan langkah 1 sampai 5, lalu langkah 6.")
            }
        }
    }

    // ---------- Pembacaan langsung ----------
    private suspend fun refreshLive() {
        val mem = Device.memory(ctx)
        val sto = Device.storage()
        val b = Device.battery(ctx)
        var cpuNow = -1
        var saver = saverOn
        if (shzReady) {
            val r = withContext(Dispatchers.IO) { Sh.run("head -n 1 /proc/stat; settings get global low_power") }
            if (r.ok) {
                val lines = r.out.lines()
                cpuNow = parseCpu(lines.firstOrNull() ?: "")
                if (lines.size > 1) saver = lines[1].trim() == "1"
            }
        }
        refreshDev()
        ramTotal = mem.first
        ramAvail = mem.second
        stoTotal = sto.first
        stoFree = sto.second
        batt = b
        cpu = cpuNow
        saverOn = saver
    }

    private fun parseCpu(line: String): Int {
        val parts = line.trim().split(Regex("\\s+"))
        if (parts.size < 8 || parts[0] != "cpu") return -1
        val nums = parts.drop(1).take(8).mapNotNull { it.toLongOrNull() }
        if (nums.size < 8) return -1
        val total = nums.sum()
        val idle = nums[3] + nums[4]
        val dTotal = total - lastTotal
        val dIdle = idle - lastIdle
        val first = lastTotal == 0L
        lastTotal = total
        lastIdle = idle
        if (first || dTotal <= 0) return -1
        return (((dTotal - dIdle) * 100) / dTotal).toInt().coerceIn(0, 100)
    }

    fun score(): Int {
        val ramPct = if (ramTotal > 0) (ramTotal - ramAvail).toFloat() / ramTotal else 0.5f
        val stoPct = if (stoTotal > 0.0) ((stoTotal - stoFree) / stoTotal).toFloat() else 0.5f
        val tempPenalty = max(0f, (batt.temp - 32.0).toFloat()) * 1.5f
        val cpuPenalty = if (cpu > 0) cpu * 0.18f else 0f
        val s = 100f - ramPct * 42f - stoPct * 12f - tempPenalty - cpuPenalty
        return s.roundToInt().coerceIn(5, 100)
    }

    // ---------- Daftar aplikasi ----------
    @Suppress("DEPRECATION")
    fun loadApps() {
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) {
                val pm = ctx.packageManager
                pm.getInstalledApplications(0)
                    .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 && it.packageName != ctx.packageName }
                    .map {
                        val game = it.category == ApplicationInfo.CATEGORY_GAME ||
                            (it.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                        AppEntry(it.packageName, pm.getApplicationLabel(it).toString(), game)
                    }
                    .sortedBy { it.label.lowercase() }
            }
            thirdParty = list
        }
    }

    fun toggleKeep(pkg: String) {
        if (keep.contains(pkg)) keep.remove(pkg) else keep.add(pkg)
        prefs.edit().putStringSet("keep", keep.toSet()).apply()
    }

    private fun hardKeep(extra: String?): Set<String> {
        val pm = ctx.packageManager
        val set = HashSet<String>()
        set.add(ctx.packageName)
        set.add(Sh.SHIZUKU_PKG)
        if (extra != null) set.add(extra)
        try {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            pm.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName?.let { set.add(it) }
        } catch (e: Throwable) {
        }
        try {
            Settings.Secure.getString(ctx.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
                ?.substringBefore('/')?.let { set.add(it) }
        } catch (e: Throwable) {
        }
        return set
    }

    // ---------- BOOST ----------
    private class BoostResult(val names: List<String>, val freedMb: Long, val viaShizuku: Boolean)

    private suspend fun doBoost(extraKeep: String?): BoostResult = withContext(Dispatchers.IO) {
        val before = Device.memory(ctx).second
        val protect = HashSet<String>(keep)
        protect.addAll(hardKeep(extraKeep))
        val viaShz = shzReady
        val names: List<String>
        if (viaShz) {
            // Penuh: hanya aplikasi yang benar-benar sedang jalan, ditutup paksa.
            val ps = Sh.run("ps -A -o NAME")
            val running = ps.out.lineSequence().map { it.trim().substringBefore(':') }.toSet()
            val victims = thirdParty.filter { it.pkg in running && it.pkg !in protect }
            if (victims.isNotEmpty()) {
                Sh.run(victims.joinToString("; ") { "am force-stop ${it.pkg}" })
            }
            Sh.run("am kill-all")
            names = victims.map { it.label }
        } else {
            // Tanpa Shizuku: minta Android membersihkan proses latar tiap aplikasi.
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val victims = thirdParty.filter { it.pkg !in protect }
            for (v in victims) {
                try {
                    am.killBackgroundProcesses(v.pkg)
                } catch (e: Throwable) {
                }
            }
            names = victims.map { it.label }
        }
        delay(900)
        val after = Device.memory(ctx).second
        BoostResult(names, max(0L, after - before), viaShz)
    }

    fun boost() {
        if (busy != null) return
        viewModelScope.launch {
            busy = "BOOST"
            val r = doBoost(null)
            if (r.viaShizuku) {
                say("Boost selesai: ${r.names.size} aplikasi ditutup, RAM lega +${r.freedMb} MB.")
                if (r.names.isNotEmpty()) log.add(0, "Ditutup: " + r.names.take(8).joinToString(", "))
            } else {
                say(
                    "Boost lewat Android selesai: proses latar ${r.names.size} aplikasi dibersihkan, RAM lega +${r.freedMb} MB. " +
                        "Hubungkan Shizuku untuk boost penuh.",
                    true
                )
            }
            refreshLive()
            busy = null
        }
    }

    // ---------- Pembersih ----------
    fun clean() {
        if (busy != null) return
        if (!shzReady) {
            try {
                ctx.cacheDir.deleteRecursively()
            } catch (e: Throwable) {
            }
            val opened = startFirst(
                listOf(
                    Intent("android.os.storage.action.CLEAR_APP_CACHE"),
                    Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS),
                    Intent(Settings.ACTION_SETTINGS)
                )
            )
            if (opened) {
                say("Membuka pembersih sistem. Pilih Hapus di layar itu. Dengan Shizuku, cukup satu tombol.", true)
            } else {
                say("Tidak bisa membuka pengaturan penyimpanan.")
            }
            return
        }
        viewModelScope.launch {
            busy = "CLEAN"
            val before = Device.storage().second
            withContext(Dispatchers.IO) {
                Sh.run("pm trim-caches 999G")
                Sh.run("logcat -b all -c")
                delay(700)
            }
            val after = Device.storage().second
            val mb = max(0.0, (after - before) * 1024.0).roundToInt()
            lastClean = "Cache dibersihkan. Ruang bebas bertambah $mb MB."
            say(lastClean)
            refreshLive()
            busy = null
        }
    }

    // ---------- Mode Game ----------
    fun setOpt(key: String, value: Boolean) {
        prefs.edit().putBoolean(key, value).apply()
        when (key) {
            "dnd" -> optDnd = value
            "anim" -> optAnim = value
            "hz" -> optHz = value
            "perf" -> optPerf = value
        }
    }

    fun playGame(pkg: String) {
        if (busy != null) return
        viewModelScope.launch {
            busy = "GAME"
            val r = doBoost(pkg)
            say("Mode Game: RAM lega +${r.freedMb} MB (${if (r.viaShizuku) "aplikasi ditutup: ${r.names.size}" else "lewat Android"}).")
            if (shzReady) {
                withContext(Dispatchers.IO) {
                    Sh.run("cmd game mode performance $pkg")
                    Sh.run("cmd game set --mode performance --user 0 $pkg")
                    if (optDnd) {
                        val prev = Sh.run("settings get global zen_mode").out.trim()
                        prefs.edit().putString("prev_zen", if (prev == "null" || prev.isEmpty()) "0" else prev).apply()
                        Sh.run("settings put global zen_mode 1")
                    }
                    if (optAnim) {
                        val a = Sh.run("settings get global window_animation_scale").out.trim()
                        val b = Sh.run("settings get global transition_animation_scale").out.trim()
                        val c = Sh.run("settings get global animator_duration_scale").out.trim()
                        prefs.edit().putString("prev_anim", "$a|$b|$c").apply()
                        Sh.run("settings put global window_animation_scale 0.5; settings put global transition_animation_scale 0.5; settings put global animator_duration_scale 0.5")
                    }
                    if (optHz) {
                        val hz = facts.maxHz
                        Sh.run("settings put system min_refresh_rate $hz; settings put system peak_refresh_rate $hz")
                    }
                    if (optPerf) {
                        Sh.run("cmd power set-fixed-performance-mode-enabled true")
                    }
                }
                prefs.edit().putString("game_pkg", pkg).apply()
                gameActive = pkg
                log.add(0, "Pengaturan performa diterapkan.")
            } else {
                log.add(0, "Jangan ganggu, Hz, dan mode performa butuh Shizuku. Game tetap dibuka.")
            }
            val intent = ctx.packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try {
                    ctx.startActivity(intent)
                } catch (e: Throwable) {
                    say("Game tidak bisa dibuka: ${e.message}")
                }
            } else {
                say("Game ini tidak punya layar utama yang bisa dibuka.")
            }
            if (!shzReady) say("Game dibuka. Hubungkan Shizuku untuk jangan ganggu, Hz maksimal, dan mode performa.", true)
            refreshLive()
            busy = null
        }
    }

    fun restoreDefaults() {
        if (busy != null) return
        if (!shzReady) {
            say("Belum ada pengaturan yang diubah. Mengembalikan butuh Shizuku.", true)
            return
        }
        viewModelScope.launch {
            busy = "RESTORE"
            val game = prefs.getString("game_pkg", "") ?: ""
            withContext(Dispatchers.IO) {
                if (game.isNotEmpty()) Sh.run("cmd game mode standard $game")
                val zen = prefs.getString("prev_zen", null)
                if (zen != null) Sh.run("settings put global zen_mode $zen")
                val anim = (prefs.getString("prev_anim", null) ?: "1.0|1.0|1.0").split("|")
                fun fix(v: String?): String = if (v == null || v.isEmpty() || v == "null") "1.0" else v
                Sh.run(
                    "settings put global window_animation_scale ${fix(anim.getOrNull(0))}; " +
                        "settings put global transition_animation_scale ${fix(anim.getOrNull(1))}; " +
                        "settings put global animator_duration_scale ${fix(anim.getOrNull(2))}"
                )
                Sh.run("settings delete system min_refresh_rate; settings delete system peak_refresh_rate")
                Sh.run("cmd power set-fixed-performance-mode-enabled false")
            }
            prefs.edit().remove("game_pkg").apply()
            gameActive = ""
            say("Pengaturan dikembalikan ke normal.")
            busy = null
        }
    }

    // ---------- Baterai ----------
    fun setSaver(on: Boolean) {
        if (!shzReady) {
            val opened = startFirst(listOf(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS), Intent(Settings.ACTION_SETTINGS)))
            say(
                if (opened) "Membuka pengaturan Hemat baterai. Hubungkan Shizuku agar bisa diatur dari sini."
                else "Tidak bisa membuka pengaturan baterai.",
                true
            )
            return
        }
        viewModelScope.launch {
            withContext(Dispatchers.IO) { Sh.run("settings put global low_power ${if (on) 1 else 0}") }
            refreshLive()
            say(if (saverOn) "Hemat baterai sistem aktif." else "Hemat baterai sistem mati.")
        }
    }

    // ---------- Keamanan: audit izin ----------
    @Suppress("DEPRECATION")
    fun scanPerms() {
        if (busy != null) return
        viewModelScope.launch {
            busy = "SCAN"
            val result = withContext(Dispatchers.IO) {
                val pm = ctx.packageManager
                val out = ArrayList<PermEntry>()
                for (app in thirdParty) {
                    try {
                        val pi = pm.getPackageInfo(app.pkg, PackageManager.GET_PERMISSIONS)
                        val req = pi.requestedPermissions ?: continue
                        val flags = pi.requestedPermissionsFlags ?: continue
                        val granted = ArrayList<String>()
                        for (i in req.indices) {
                            val ok = (flags[i] and android.content.pm.PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0
                            if (ok && SENSITIVE.containsKey(req[i])) granted.add(req[i])
                        }
                        if (granted.isNotEmpty()) out.add(PermEntry(app.pkg, app.label, granted))
                    } catch (e: Throwable) {
                    }
                }
                out.sortedByDescending { it.granted.size }
            }
            perms = result
            scanned = true
            say("Pemindaian izin selesai: ${result.size} aplikasi memakai izin sensitif.")
            busy = null
        }
    }

    fun revoke(pkg: String, perm: String) {
        if (!shzReady) {
            val opened = startFirst(
                listOf(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
            )
            say(
                if (opened) "Membuka halaman izin aplikasi. Pilih Izin lalu matikan. Dengan Shizuku, cukup satu tombol."
                else "Tidak bisa membuka pengaturan aplikasi.",
                true
            )
            return
        }
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { Sh.run("pm revoke $pkg $perm") }
            val name = SENSITIVE[perm] ?: perm
            if (r.ok) {
                perms = perms.map {
                    if (it.pkg == pkg) it.copy(granted = it.granted - perm) else it
                }.filter { it.granted.isNotEmpty() }
                say("Izin $name dicabut dari $pkg.")
            } else {
                say("Gagal mencabut izin $name: ${r.out.take(120)}")
            }
        }
    }
}
