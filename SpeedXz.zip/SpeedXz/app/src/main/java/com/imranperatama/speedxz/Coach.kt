package com.imranperatama.speedxz

import android.content.Context
import org.json.JSONArray

/**
 * Ingatan pelatih per game. Menyimpan pelajaran dari kalah atau menang yang diceritakan pengguna,
 * lalu dikirim ke AI sebagai konteks supaya saran berikutnya menghindari kesalahan yang sama.
 * Ingatan ini tersimpan di HP (bukan pelatihan model) dan bisa dihapus lewat chat: "lupakan pelajaran".
 */
object Coach {
    private const val MAX = 30

    private fun key(pkg: String): String = "coach_$pkg"

    fun lessons(ctx: Context, pkg: String): List<String> {
        val raw = GameEngine.prefs(ctx).getString(key(pkg), null) ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map { a.getString(it) }
        } catch (e: Throwable) {
            emptyList()
        }
    }

    fun add(ctx: Context, pkg: String, text: String) {
        val t = text.trim().take(220)
        if (t.isEmpty() || pkg.isEmpty()) return
        val list = (lessons(ctx, pkg) + t).takeLast(MAX)
        val a = JSONArray()
        for (s in list) a.put(s)
        GameEngine.prefs(ctx).edit().putString(key(pkg), a.toString()).apply()
    }

    fun clear(ctx: Context, pkg: String) {
        GameEngine.prefs(ctx).edit().remove(key(pkg)).apply()
    }

    private val WORDS = listOf(
        "strategi", "senjata", "bertahan", "rotasi", "meta", "build", "loadout", "counter", "taktik",
        "tips main", "cara menang", "posisi", "kalah", "menang", "ranked", "push", "rush", "camp",
        "karakter", "skill", "peta", "map"
    )

    /** Pertanyaan soal cara bermain, bukan soal HP: pakai peran pelatih dan pencarian info terbaru. */
    fun isCoachQuestion(q: String): Boolean {
        val t = q.lowercase()
        return WORDS.any { t.contains(it) }
    }

    /** Pelajaran dan riwayat sesi untuk game ini, dalam satu paragraf buat AI. */
    fun context(ctx: Context, pkg: String, label: String): String {
        val sb = StringBuilder()
        val ls = lessons(ctx, pkg)
        if (ls.isNotEmpty()) {
            sb.append(" PELAJARAN DARI MATCH SEBELUMNYA (dari pengguna, terbaru di akhir): ")
            val recent = ls.takeLast(10)
            for (i in recent.indices) sb.append(i + 1).append(") ").append(recent[i]).append(" ")
        }
        val recs = SessionLog.load(ctx).filter { it.label == label }.take(3)
        if (recs.isNotEmpty()) {
            sb.append(" RIWAYAT SESI ").append(label).append(": ")
            for (r in recs) {
                sb.append(r.durSec / 60).append(" menit, FPS rata-rata ")
                    .append(if (r.avgFps >= 0) r.avgFps.toString() else "N/A")
                    .append(", suhu tertinggi ").append(r.maxTemp.toInt()).append(" C; ")
            }
        }
        return sb.toString()
    }
}
