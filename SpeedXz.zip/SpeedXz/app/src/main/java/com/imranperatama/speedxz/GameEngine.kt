package com.imranperatama.speedxz

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.provider.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Pekerjaan nyata untuk Mode Game. Dipakai bersama oleh aplikasi dan GameService.
 * Semua perubahan pengaturan HP dicatat nilai awalnya, lalu dikembalikan saat sesi berakhir.
 */
object GameEngine {
    fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences("speedxz", Context.MODE_PRIVATE)

    @Suppress("DEPRECATION")
    fun thirdParty(ctx: Context): List<AppEntry> {
        val pm = ctx.packageManager
        return pm.getInstalledApplications(0)
            .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 && it.packageName != ctx.packageName }
            .map {
                val game = it.category == ApplicationInfo.CATEGORY_GAME ||
                    (it.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                AppEntry(it.packageName, pm.getApplicationLabel(it).toString(), game)
            }
            .sortedBy { it.label.lowercase() }
    }

    fun keepList(ctx: Context): Set<String> = prefs(ctx).getStringSet("keep", null) ?: DEFAULT_KEEP

    /** Yang tidak pernah ditutup: Speed Xz, Shizuku, game, layar utama, papan ketik. */
    fun hardKeep(ctx: Context, extra: String?): Set<String> {
        val pm = ctx.packageManager
        val set = HashSet<String>()
        set.add(ctx.packageName)
        set.add(Sh.SHIZUKU_PKG)
        if (extra != null) set.add(extra)
        try {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            pm.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName?.let { set.add(it) }
        } catch (e: Throwable) {
        }
        try {
            Settings.Secure.getString(ctx.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
                ?.substringBefore('/')?.let { set.add(it) }
        } catch (e: Throwable) {
        }
        return set
    }

    private fun protectSet(ctx: Context, game: String?, strict: Boolean): Set<String> {
        val protect = HashSet<String>(hardKeep(ctx, game))
        if (!strict) protect.addAll(keepList(ctx))
        return protect
    }

    /**
     * Tutup paksa semua aplikasi non-sistem yang sedang berjalan.
     * Mode ketat mengabaikan daftar lindung (WhatsApp, VPN, dan lainnya ikut ditutup).
     * Dengan Shizuku: hanya yang benar-benar jalan. Tanpa Shizuku: minta Android membersihkan proses latar.
     * Mengembalikan nama aplikasi yang ditutup.
     */
    suspend fun killBackground(ctx: Context, game: String?, strict: Boolean, apps: List<AppEntry>): List<String> =
        withContext(Dispatchers.IO) {
            val protect = protectSet(ctx, game, strict)
            if (Sh.granted()) {
                val ps = Sh.run("ps -A -o NAME")
                if (ps.out.isBlank()) return@withContext emptyList<String>()
                val running = ps.out.lineSequence().map { it.trim().substringBefore(':') }.toSet()
                val victims = apps.filter { it.pkg in running && it.pkg !in protect }
                if (victims.isNotEmpty()) {
                    Sh.run(victims.joinToString("; ") { "am force-stop ${it.pkg}" })
                }
                Sh.run("am kill-all")
                victims.map { it.label }
            } else {
                val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val victims = apps.filter { it.pkg !in protect }
                for (v in victims) {
                    try {
                        am.killBackgroundProcesses(v.pkg)
                    } catch (e: Throwable) {
                    }
                }
                victims.map { it.label }
            }
        }

    private fun clean(v: String, def: String): String {
        val t = v.trim()
        return if (t.isEmpty() || t == "null") def else t
    }

    /** Terapkan pengaturan performa. Nilai awal disimpan sekali per sesi. */
    suspend fun apply(ctx: Context, game: String, maxHz: Int) = withContext(Dispatchers.IO) {
        val p = prefs(ctx)
        val dnd = p.getBoolean("dnd", true)
        val anim = p.getBoolean("anim", true)
        val hz = p.getBoolean("hz", true)
        val perf = p.getBoolean("perf", true)
        val heads = p.getBoolean("heads", true)

        if (!p.getBoolean("applied", false)) {
            val ed = p.edit()
            ed.putBoolean("applied", true)
            ed.putString("game_pkg", game)
            ed.putBoolean("ap_dnd", dnd)
            ed.putBoolean("ap_anim", anim)
            ed.putBoolean("ap_hz", hz)
            ed.putBoolean("ap_perf", perf)
            ed.putBoolean("ap_heads", heads)
            ed.putString("prev_zen", clean(Sh.run("settings get global zen_mode").out, "0"))
            ed.putString(
                "prev_anim",
                clean(Sh.run("settings get global window_animation_scale").out, "1.0") + "|" +
                    clean(Sh.run("settings get global transition_animation_scale").out, "1.0") + "|" +
                    clean(Sh.run("settings get global animator_duration_scale").out, "1.0")
            )
            ed.putString("prev_heads", clean(Sh.run("settings get global heads_up_notifications_enabled").out, "1"))
            ed.commit()
        }

        Sh.run("cmd game mode performance $game")
        Sh.run("cmd game set --mode performance --user 0 $game")
        if (dnd) Sh.run("settings put global zen_mode 1")
        if (heads) Sh.run("settings put global heads_up_notifications_enabled 0")
        if (anim) {
            Sh.run(
                "settings put global window_animation_scale 0.5; " +
                    "settings put global transition_animation_scale 0.5; " +
                    "settings put global animator_duration_scale 0.5"
            )
        }
        if (hz) Sh.run("settings put system min_refresh_rate $maxHz; settings put system peak_refresh_rate $maxHz")
        if (perf) Sh.run("cmd power set-fixed-performance-mode-enabled true")
    }

    fun pending(ctx: Context): Boolean = prefs(ctx).getBoolean("applied", false)

    /** Kembalikan semua yang diubah apply(). Mengembalikan false kalau Shizuku tidak tersedia. */
    suspend fun restore(ctx: Context): Boolean = withContext(Dispatchers.IO) {
        val p = prefs(ctx)
        if (!p.getBoolean("applied", false)) return@withContext true
        if (!Sh.granted()) return@withContext false

        val game = p.getString("game_pkg", "") ?: ""
        if (game.isNotEmpty()) Sh.run("cmd game mode standard $game")
        if (p.getBoolean("ap_dnd", false)) {
            Sh.run("settings put global zen_mode ${p.getString("prev_zen", "0")}")
        }
        if (p.getBoolean("ap_heads", false)) {
            Sh.run("settings put global heads_up_notifications_enabled ${p.getString("prev_heads", "1")}")
        }
        if (p.getBoolean("ap_anim", false)) {
            val a = (p.getString("prev_anim", "1.0|1.0|1.0") ?: "1.0|1.0|1.0").split("|")
            Sh.run(
                "settings put global window_animation_scale ${a.getOrElse(0) { "1.0" }}; " +
                    "settings put global transition_animation_scale ${a.getOrElse(1) { "1.0" }}; " +
                    "settings put global animator_duration_scale ${a.getOrElse(2) { "1.0" }}"
            )
        }
        if (p.getBoolean("ap_hz", false)) {
            Sh.run("settings delete system min_refresh_rate; settings delete system peak_refresh_rate")
        }
        if (p.getBoolean("ap_perf", false)) {
            Sh.run("cmd power set-fixed-performance-mode-enabled false")
        }
        p.edit()
            .putBoolean("applied", false)
            .remove("game_pkg")
            .remove("prev_zen").remove("prev_anim").remove("prev_heads")
            .remove("ap_dnd").remove("ap_anim").remove("ap_hz").remove("ap_perf").remove("ap_heads")
            .commit()
        true
    }
}
