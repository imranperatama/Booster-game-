package com.imranperatama.speedxz

import android.app.ActivityManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.PowerManager
import android.provider.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.max

/**
 * Pekerjaan nyata untuk Mode Game. Dipakai bersama oleh aplikasi dan GameService.
 * Semua perubahan pengaturan HP dicatat nilai awalnya, lalu dikembalikan saat sesi berakhir.
 */
/** Hasil Optimalkan: teks laporan untuk panel Xz dan jumlah aplikasi yang ditutup. */
class OptResult(val text: String, val killed: Int)

object GameEngine {
    fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences("speedxz", Context.MODE_PRIVATE)

    @Suppress("DEPRECATION")
    fun thirdParty(ctx: Context): List<AppEntry> {
        val pm = ctx.packageManager
        return pm.getInstalledApplications(0)
            .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 && it.packageName != ctx.packageName }
            .map {
                val game = it.category == ApplicationInfo.CATEGORY_GAME ||
                    (it.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                AppEntry(it.packageName, pm.getApplicationLabel(it).toString(), game)
            }
            .sortedBy { it.label.lowercase() }
    }

    fun keepList(ctx: Context): Set<String> = prefs(ctx).getStringSet("keep", null) ?: DEFAULT_KEEP

    /** Yang tidak pernah ditutup: Speed Xz, Shizuku, game, layar utama, papan ketik. */
    fun hardKeep(ctx: Context, extra: String?): Set<String> {
        val pm = ctx.packageManager
        val set = HashSet<String>()
        set.add(ctx.packageName)
        set.add(Sh.SHIZUKU_PKG)
        if (extra != null) set.add(extra)
        try {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            pm.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName?.let { set.add(it) }
        } catch (e: Throwable) {
        }
        try {
            Settings.Secure.getString(ctx.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
                ?.substringBefore('/')?.let { set.add(it) }
        } catch (e: Throwable) {
        }
        return set
    }

    private fun protectSet(ctx: Context, game: String?, strict: Boolean): Set<String> {
        val protect = HashSet<String>(hardKeep(ctx, game))
        if (!strict) protect.addAll(keepList(ctx))
        return protect
    }

    /**
     * Tutup aplikasi non-sistem yang sedang berjalan.
     * Dengan Shizuku: baca memori tiap proses (ps), tutup paksa mulai dari yang paling rakus RAM,
     * lalu bersihkan proses cache. Pada mode tidak ketat, aplikasi di daftar lindung hanya dikurangi
     * memorinya (send-trim-memory), tidak ditutup.
     * Tanpa Shizuku: minta Android membersihkan proses latar tiap aplikasi (killBackgroundProcesses).
     * Catatan: ActivityManager.getRunningAppProcesses() tidak bisa melihat aplikasi lain sejak Android 5.1,
     * jadi daftar proses dibaca lewat Shizuku.
     * Mengembalikan nama aplikasi yang ditutup, urut dari yang terbesar.
     */
    suspend fun killBackground(ctx: Context, game: String?, strict: Boolean, apps: List<AppEntry>): List<String> =
        withContext(Dispatchers.IO) {
            val protect = protectSet(ctx, game, strict)
            val byPkg = apps.associateBy { it.pkg }
            if (Sh.granted()) {
                val ps = Sh.run("ps -A -o RSS,NAME")
                if (ps.out.isBlank()) return@withContext emptyList<String>()
                val rss = HashMap<String, Long>()
                for (line in ps.out.lineSequence()) {
                    val p = line.trim().split(Regex("\\s+"))
                    if (p.size < 2) continue
                    val kb = p[0].toLongOrNull() ?: continue
                    val name = p[1].substringBefore(':')
                    if (byPkg.containsKey(name)) rss[name] = (rss[name] ?: 0L) + kb
                }
                val victims = rss.entries.filter { it.key !in protect }.sortedByDescending { it.value }
                val cmds = ArrayList<String>()
                for (v in victims) cmds.add("am force-stop ${v.key}")
                if (!strict) {
                    val keep = keepList(ctx)
                    for (k in rss.keys) {
                        if (k in keep && k != game) cmds.add("am send-trim-memory --user 0 $k COMPLETE")
                    }
                }
                cmds.add("am kill-all")
                Sh.run(cmds.joinToString("; "))
                victims.map { byPkg[it.key]?.label ?: it.key }
            } else {
                val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val victims = apps.filter { it.pkg !in protect }
                for (v in victims) {
                    try {
                        am.killBackgroundProcesses(v.pkg)
                    } catch (e: Throwable) {
                    }
                }
                victims.map { it.label }
            }
        }

    // ---------------- Jangan Ganggu ----------------
    private fun nm(ctx: Context): NotificationManager = ctx.getSystemService(NotificationManager::class.java)

    fun dndAccess(ctx: Context): Boolean = try {
        nm(ctx).isNotificationPolicyAccessGranted
    } catch (e: Throwable) {
        false
    }

    /** Hanya alarm yang boleh berbunyi saat aktif. Lewat NotificationManager jika diizinkan, kalau tidak lewat Shizuku. */
    suspend fun setDnd(ctx: Context, on: Boolean): Boolean = withContext(Dispatchers.IO) {
        if (dndAccess(ctx)) {
            try {
                nm(ctx).setInterruptionFilter(
                    if (on) NotificationManager.INTERRUPTION_FILTER_ALARMS else NotificationManager.INTERRUPTION_FILTER_ALL
                )
                true
            } catch (e: Throwable) {
                false
            }
        } else if (Sh.granted()) {
            Sh.run("settings put global zen_mode ${if (on) 1 else 0}").ok
        } else {
            false
        }
    }

    suspend fun dndOn(ctx: Context): Boolean = withContext(Dispatchers.IO) {
        if (dndAccess(ctx)) {
            nm(ctx).currentInterruptionFilter in 2..4
        } else if (Sh.granted()) {
            Sh.run("settings get global zen_mode").out.trim().let { it != "0" && it != "null" && it.isNotEmpty() }
        } else {
            false
        }
    }

    // ---------------- Layar redup ----------------
    suspend fun setDim(ctx: Context, on: Boolean): Boolean = withContext(Dispatchers.IO) {
        if (!Sh.granted()) return@withContext false
        val p = prefs(ctx)
        if (on) {
            if (!p.getBoolean("dim_on", false)) {
                val cur = Sh.run("settings get system screen_brightness").out.trim().toIntOrNull() ?: 128
                val mode = Sh.run("settings get system screen_brightness_mode").out.trim().toIntOrNull() ?: 1
                p.edit().putInt("prev_bright", cur).putInt("prev_bmode", mode).putBoolean("dim_on", true).commit()
            }
            val target = max(20, (p.getInt("prev_bright", 128) * 0.6).toInt())
            Sh.run("settings put system screen_brightness_mode 0; settings put system screen_brightness $target").ok
        } else {
            restoreDim(ctx)
        }
    }

    private fun restoreDim(ctx: Context): Boolean {
        val p = prefs(ctx)
        if (!p.getBoolean("dim_on", false)) return true
        if (!Sh.granted()) return false
        val r = Sh.run(
            "settings put system screen_brightness ${p.getInt("prev_bright", 128)}; " +
                "settings put system screen_brightness_mode ${p.getInt("prev_bmode", 1)}"
        )
        if (r.ok) p.edit().putBoolean("dim_on", false).commit()
        return r.ok
    }

    fun dimOn(ctx: Context): Boolean = prefs(ctx).getBoolean("dim_on", false)

    suspend fun trimCaches(): Boolean = withContext(Dispatchers.IO) {
        if (!Sh.granted()) return@withContext false
        Sh.run("pm trim-caches 999G").ok
    }

    // ---------------- Terapkan dan kembalikan ----------------
    private fun clean(v: String, def: String): String {
        val t = v.trim()
        return if (t.isEmpty() || t == "null") def else t
    }

    /** Terapkan pengaturan performa. Nilai awal disimpan sekali per sesi. Aman dipanggil tanpa Shizuku. */
    suspend fun apply(ctx: Context, game: String, maxHz: Int) = withContext(Dispatchers.IO) {
        val p = prefs(ctx)
        val shz = Sh.granted()
        val dnd = p.getBoolean("dnd", true)
        val anim = p.getBoolean("anim", true) && shz
        val hz = p.getBoolean("hz", true) && shz
        val perf = p.getBoolean("perf", true) && shz
        val heads = p.getBoolean("heads", true) && shz

        if (!p.getBoolean("applied", false)) {
            val ed = p.edit()
            ed.putBoolean("applied", true)
            ed.putString("game_pkg", game)
            ed.putBoolean("ap_shell", shz)
            ed.putBoolean("ap_anim", anim)
            ed.putBoolean("ap_hz", hz)
            ed.putBoolean("ap_perf", perf)
            ed.putBoolean("ap_heads", heads)
            if (dnd) {
                if (dndAccess(ctx)) {
                    ed.putString("dnd_via", "nm")
                    ed.putInt("prev_filter", nm(ctx).currentInterruptionFilter)
                } else if (shz) {
                    ed.putString("dnd_via", "zen")
                    ed.putString("prev_zen", clean(Sh.run("settings get global zen_mode").out, "0"))
                } else {
                    ed.putString("dnd_via", "none")
                }
            } else {
                ed.putString("dnd_via", "none")
            }
            if (shz) {
                ed.putString(
                    "prev_anim",
                    clean(Sh.run("settings get global window_animation_scale").out, "1.0") + "|" +
                        clean(Sh.run("settings get global transition_animation_scale").out, "1.0") + "|" +
                        clean(Sh.run("settings get global animator_duration_scale").out, "1.0")
                )
                ed.putString("prev_heads", clean(Sh.run("settings get global heads_up_notifications_enabled").out, "1"))
            }
            ed.commit()
        }

        if (dnd && p.getString("dnd_via", "none") != "none") setDnd(ctx, true)
        if (shz) {
            Sh.run("cmd game mode performance $game")
            Sh.run("cmd game set --mode performance --user 0 $game")
            if (heads) Sh.run("settings put global heads_up_notifications_enabled 0")
            if (anim) {
                Sh.run(
                    "settings put global window_animation_scale 0.5; " +
                        "settings put global transition_animation_scale 0.5; " +
                        "settings put global animator_duration_scale 0.5"
                )
            }
            if (hz) Sh.run("settings put system min_refresh_rate $maxHz; settings put system peak_refresh_rate $maxHz")
            if (perf) {
                Sh.run("cmd power set-fixed-performance-mode-enabled true")
                p.edit().putBoolean("perf_locked", true).commit()
            }
        }
    }

    // ---------------- Optimalkan pintar ----------------
    private fun cmdOk(r: ShResult): Boolean {
        if (!r.ok) return false
        val o = r.out.lowercase()
        return !(o.contains("unknown") || o.contains("exception") || o.contains("error") || o.contains("not found"))
    }

    private fun powerSave(ctx: Context): Boolean = try {
        (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isPowerSaveMode
    } catch (e: Throwable) {
        false
    }

    /** Kunci atau lepas mode performa tetap. Status disimpan supaya mode pintar tahu keadaannya. */
    suspend fun setPerfLock(ctx: Context, on: Boolean): Boolean = withContext(Dispatchers.IO) {
        if (!Sh.granted()) return@withContext false
        val ok = cmdOk(Sh.run("cmd power set-fixed-performance-mode-enabled $on"))
        if (ok) {
            val ed = prefs(ctx).edit().putBoolean("perf_locked", on)
            if (on) ed.putBoolean("opt_perf", true)
            ed.commit()
        }
        ok
    }

    fun perfLocked(ctx: Context): Boolean = prefs(ctx).getBoolean("perf_locked", false)

    /**
     * Optimalkan Kinerja Max. Memeriksa suhu, RAM, dan mode hemat baterai dulu, lalu memilih langkah:
     * tutup proses latar, bersihkan cache hanya jika RAM sempit, aktifkan mode performa game, beri prioritas
     * ke game, dan kunci performa tetap hanya jika HP tidak sedang panas.
     */
    suspend fun maxPerformance(ctx: Context, game: String, strict: Boolean, apps: List<AppEntry>, zone: Double): OptResult =
        withContext(Dispatchers.IO) {
            val out = ArrayList<String>()
            val shz = Sh.granted()
            val p = prefs(ctx)
            val before = Device.memory(ctx)
            val batt = Device.battery(ctx)
            val hot = batt.temp >= 43.0 || zone >= 75.0

            val names = killBackground(ctx, game, strict, apps)
            if (names.isEmpty()) {
                out.add("Tidak ada aplikasi lain yang perlu ditutup.")
            } else {
                out.add(
                    "Menutup ${names.size} aplikasi latar: " + names.take(4).joinToString(", ") +
                        (if (names.size > 4) ", dan lainnya." else ".")
                )
            }
            if (powerSave(ctx)) out.add("Hemat baterai sistem AKTIF dan membatasi CPU. Matikan di tab BATERAI.")

            if (shz) {
                val lowRam = before.first > 0 && before.second * 100 / before.first < 25
                if (lowRam) {
                    if (trimCaches()) out.add("RAM sempit, cache semua aplikasi dibersihkan.")
                } else {
                    out.add("RAM masih lega, cache tidak disentuh supaya game tidak memuat ulang.")
                }
                Sh.run("cmd game mode performance $game")
                out.add("Mode performa game diaktifkan.")
                val idle = Sh.run("cmd deviceidle whitelist +$game; am set-standby-bucket $game active")
                if (cmdOk(idle)) {
                    p.edit().putString("opt_idle", game).commit()
                    out.add("Game dikecualikan dari penghemat daya dan diberi prioritas aktif.")
                }
                if (hot) {
                    setPerfLock(ctx, false)
                    out.add("HP sedang panas: performa tetap TIDAK dikunci supaya tidak throttle lebih parah. Dinginkan dulu.")
                } else if (setPerfLock(ctx, true)) {
                    out.add("Mode performa tetap aktif, frekuensi dijaga stabil.")
                }
            } else {
                out.add("Tanpa Shizuku hanya penutupan proses latar yang jalan. Hubungkan Shizuku di tab SETUP untuk mode penuh.")
            }

            delay(700)
            val after = Device.memory(ctx)
            val gain = after.second - before.second
            val head = "KINERJA MAX SELESAI\nRAM bebas ${before.second} -> ${after.second} MB " +
                (if (gain >= 0) "(+$gain)" else "($gain)")
            OptResult(head + "\n" + out.joinToString("\n") { "- $it" }, names.size)
        }

    /**
     * Optimalkan Sinyal. Sinyal radio tidak bisa dinaikkan oleh aplikasi; yang bisa dilakukan:
     * kurangi rebutan jaringan, matikan penghemat data, mode latensi rendah Wi-Fi, siagakan data seluler
     * sebagai cadangan saat Wi-Fi lemah, lalu ukur ping sebelum dan sesudah.
     */
    suspend fun optimizeSignal(ctx: Context, game: String, strict: Boolean, apps: List<AppEntry>): OptResult =
        withContext(Dispatchers.IO) {
            val out = ArrayList<String>()
            val shz = Sh.granted()
            val p = prefs(ctx)
            val info = Net.read(ctx)
            if (info.kind == "none") {
                return@withContext OptResult("Tidak ada koneksi internet. Nyalakan Wi-Fi atau data seluler dulu.", 0)
            }
            val pingBefore = Net.pingAvg(3)
            out.add("Jaringan sekarang: ${info.label}.")
            val weak = info.level in 0..1

            val names = killBackground(ctx, game, strict, apps)
            out.add(
                if (names.isEmpty()) "Tidak ada aplikasi latar yang berebut jaringan."
                else "Menutup ${names.size} aplikasi latar supaya tidak berebut jaringan."
            )

            if (shz) {
                val ds = Sh.run("cmd netpolicy get restrict-background").out.lowercase()
                if (ds.contains("enabled")) {
                    if (cmdOk(Sh.run("cmd netpolicy set restrict-background false"))) {
                        p.edit().putBoolean("opt_ds", true).commit()
                        out.add("Penghemat data dimatikan selama sesi.")
                    }
                }
                if (info.kind == "wifi") {
                    val low = cmdOk(Sh.run("cmd wifi force-low-latency-mode enabled"))
                    val hi = cmdOk(Sh.run("cmd wifi force-hi-perf-mode enabled"))
                    p.edit().putBoolean("opt_lowlat", low).putBoolean("opt_hiperf", hi).commit()
                    if (low || hi) {
                        out.add("Wi-Fi diset ke mode latensi rendah dan performa tinggi.")
                    } else {
                        out.add("HP ini tidak mengizinkan mode latensi rendah Wi-Fi lewat shell.")
                    }
                    if (weak) {
                        out.add("Sinyal Wi-Fi lemah: dekatkan HP ke router atau pindah ke jalur 5 GHz.")
                        if (!p.contains("opt_mdao")) {
                            val prev = Sh.run("settings get global mobile_data_always_on").out.trim()
                            p.edit().putString("opt_mdao", if (prev.isEmpty() || prev == "null") "0" else prev).commit()
                        }
                        if (cmdOk(Sh.run("settings put global mobile_data_always_on 1"))) {
                            out.add("Data seluler disiagakan sebagai cadangan jika Wi-Fi putus.")
                        }
                    }
                } else if (info.kind == "cell") {
                    if (weak) {
                        out.add("Sinyal seluler lemah: pindah ke dekat jendela atau tempat terbuka, atau pakai Wi-Fi jika ada.")
                    } else {
                        out.add("Sinyal seluler cukup baik.")
                    }
                }
            } else {
                out.add("Tanpa Shizuku hanya pengukuran dan penutupan proses latar. Hubungkan Shizuku di tab SETUP untuk pengaturan jaringan.")
            }

            delay(600)
            val pingAfter = Net.pingAvg(3)
            val pt = when {
                pingBefore >= 0 && pingAfter >= 0 -> "Ping: $pingBefore ms -> $pingAfter ms"
                pingAfter >= 0 -> "Ping: $pingAfter ms"
                else -> "Ping tidak terukur"
            }
            val note = "Catatan: kekuatan sinyal radio tidak bisa dinaikkan aplikasi mana pun. Ini mengurangi beban dan menyiagakan pengaturan jaringan."
            OptResult("OPTIMAL SINYAL SELESAI\n$pt\n" + out.joinToString("\n") { "- $it" } + "\n" + note, names.size)
        }

    fun pending(ctx: Context): Boolean {
        val p = prefs(ctx)
        return p.getBoolean("applied", false) || p.getBoolean("dim_on", false) || optPending(p)
    }

    private fun optPending(p: SharedPreferences): Boolean =
        p.getBoolean("opt_perf", false) || !p.getString("opt_idle", "").isNullOrEmpty() ||
            p.getBoolean("opt_lowlat", false) || p.getBoolean("opt_hiperf", false) ||
            p.getBoolean("opt_ds", false) || p.contains("opt_mdao")

    /** Kembalikan semua yang diubah. false jika ada yang butuh Shizuku tapi Shizuku tidak tersedia. */
    suspend fun restore(ctx: Context): Boolean = withContext(Dispatchers.IO) {
        val p = prefs(ctx)
        if (!pending(ctx)) return@withContext true

        // DND lewat NotificationManager tidak butuh Shizuku
        var ok = true
        when (p.getString("dnd_via", "none")) {
            "nm" -> if (dndAccess(ctx)) {
                val f = p.getInt("prev_filter", NotificationManager.INTERRUPTION_FILTER_ALL)
                try {
                    nm(ctx).setInterruptionFilter(if (f <= 0) NotificationManager.INTERRUPTION_FILTER_ALL else f)
                } catch (e: Throwable) {
                    ok = false
                }
            }
            "zen" -> if (Sh.granted()) {
                Sh.run("settings put global zen_mode ${p.getString("prev_zen", "0")}")
            } else {
                ok = false
            }
        }

        val needShell = p.getBoolean("ap_shell", false) || p.getBoolean("dim_on", false) || optPending(p)
        if (needShell && !Sh.granted()) return@withContext false

        if (p.getBoolean("ap_shell", false)) {
            val game = p.getString("game_pkg", "") ?: ""
            if (game.isNotEmpty()) Sh.run("cmd game mode standard $game")
            if (p.getBoolean("ap_heads", false)) {
                Sh.run("settings put global heads_up_notifications_enabled ${p.getString("prev_heads", "1")}")
            }
            if (p.getBoolean("ap_anim", false)) {
                val a = (p.getString("prev_anim", "1.0|1.0|1.0") ?: "1.0|1.0|1.0").split("|")
                Sh.run(
                    "settings put global window_animation_scale ${a.getOrElse(0) { "1.0" }}; " +
                        "settings put global transition_animation_scale ${a.getOrElse(1) { "1.0" }}; " +
                        "settings put global animator_duration_scale ${a.getOrElse(2) { "1.0" }}"
                )
            }
            if (p.getBoolean("ap_hz", false)) {
                Sh.run("settings delete system min_refresh_rate; settings delete system peak_refresh_rate")
            }
            if (p.getBoolean("ap_perf", false)) {
                Sh.run("cmd power set-fixed-performance-mode-enabled false")
            }
        }
        if (p.getBoolean("opt_perf", false)) Sh.run("cmd power set-fixed-performance-mode-enabled false")
        val idle = p.getString("opt_idle", "") ?: ""
        if (idle.isNotEmpty()) Sh.run("cmd deviceidle whitelist -$idle")
        if (p.getBoolean("opt_lowlat", false)) Sh.run("cmd wifi force-low-latency-mode disabled")
        if (p.getBoolean("opt_hiperf", false)) Sh.run("cmd wifi force-hi-perf-mode disabled")
        if (p.getBoolean("opt_ds", false)) Sh.run("cmd netpolicy set restrict-background true")
        val md = p.getString("opt_mdao", null)
        if (md != null) Sh.run("settings put global mobile_data_always_on $md")
        restoreDim(ctx)
        p.edit()
            .remove("opt_perf").remove("opt_idle").remove("opt_lowlat").remove("opt_hiperf")
            .remove("opt_ds").remove("opt_mdao").remove("perf_locked")
            .putBoolean("applied", false)
            .remove("game_pkg").remove("dnd_via")
            .remove("prev_zen").remove("prev_filter").remove("prev_anim").remove("prev_heads")
            .remove("ap_shell").remove("ap_anim").remove("ap_hz").remove("ap_perf").remove("ap_heads")
            .commit()
        ok
    }
}
