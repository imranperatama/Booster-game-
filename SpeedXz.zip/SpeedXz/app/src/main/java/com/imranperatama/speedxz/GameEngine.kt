package com.imranperatama.speedxz

import android.app.ActivityManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.provider.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max

/**
 * Pekerjaan nyata untuk Mode Game. Dipakai bersama oleh aplikasi dan GameService.
 * Semua perubahan pengaturan HP dicatat nilai awalnya, lalu dikembalikan saat sesi berakhir.
 */
object GameEngine {
    fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences("speedxz", Context.MODE_PRIVATE)

    @Suppress("DEPRECATION")
    fun thirdParty(ctx: Context): List<AppEntry> {
        val pm = ctx.packageManager
        return pm.getInstalledApplications(0)
            .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 && it.packageName != ctx.packageName }
            .map {
                val game = it.category == ApplicationInfo.CATEGORY_GAME ||
                    (it.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                AppEntry(it.packageName, pm.getApplicationLabel(it).toString(), game)
            }
            .sortedBy { it.label.lowercase() }
    }

    fun keepList(ctx: Context): Set<String> = prefs(ctx).getStringSet("keep", null) ?: DEFAULT_KEEP

    /** Yang tidak pernah ditutup: Speed Xz, Shizuku, game, layar utama, papan ketik. */
    fun hardKeep(ctx: Context, extra: String?): Set<String> {
        val pm = ctx.packageManager
        val set = HashSet<String>()
        set.add(ctx.packageName)
        set.add(Sh.SHIZUKU_PKG)
        if (extra != null) set.add(extra)
        try {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            pm.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName?.let { set.add(it) }
        } catch (e: Throwable) {
        }
        try {
            Settings.Secure.getString(ctx.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
                ?.substringBefore('/')?.let { set.add(it) }
        } catch (e: Throwable) {
        }
        return set
    }

    private fun protectSet(ctx: Context, game: String?, strict: Boolean): Set<String> {
        val protect = HashSet<String>(hardKeep(ctx, game))
        if (!strict) protect.addAll(keepList(ctx))
        return protect
    }

    /**
     * Tutup aplikasi non-sistem yang sedang berjalan.
     * Dengan Shizuku: baca memori tiap proses (ps), tutup paksa mulai dari yang paling rakus RAM,
     * lalu bersihkan proses cache. Pada mode tidak ketat, aplikasi di daftar lindung hanya dikurangi
     * memorinya (send-trim-memory), tidak ditutup.
     * Tanpa Shizuku: minta Android membersihkan proses latar tiap aplikasi (killBackgroundProcesses).
     * Catatan: ActivityManager.getRunningAppProcesses() tidak bisa melihat aplikasi lain sejak Android 5.1,
     * jadi daftar proses dibaca lewat Shizuku.
     * Mengembalikan nama aplikasi yang ditutup, urut dari yang terbesar.
     */
    suspend fun killBackground(ctx: Context, game: String?, strict: Boolean, apps: List<AppEntry>): List<String> =
        withContext(Dispatchers.IO) {
            val protect = protectSet(ctx, game, strict)
            val byPkg = apps.associateBy { it.pkg }
            if (Sh.granted()) {
                val ps = Sh.run("ps -A -o RSS,NAME")
                if (ps.out.isBlank()) return@withContext emptyList<String>()
                val rss = HashMap<String, Long>()
                for (line in ps.out.lineSequence()) {
                    val p = line.trim().split(Regex("\\s+"))
                    if (p.size < 2) continue
                    val kb = p[0].toLongOrNull() ?: continue
                    val name = p[1].substringBefore(':')
                    if (byPkg.containsKey(name)) rss[name] = (rss[name] ?: 0L) + kb
                }
                val victims = rss.entries.filter { it.key !in protect }.sortedByDescending { it.value }
                val cmds = ArrayList<String>()
                for (v in victims) cmds.add("am force-stop ${v.key}")
                if (!strict) {
                    val keep = keepList(ctx)
                    for (k in rss.keys) {
                        if (k in keep && k != game) cmds.add("am send-trim-memory --user 0 $k COMPLETE")
                    }
                }
                cmds.add("am kill-all")
                Sh.run(cmds.joinToString("; "))
                victims.map { byPkg[it.key]?.label ?: it.key }
            } else {
                val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val victims = apps.filter { it.pkg !in protect }
                for (v in victims) {
                    try {
                        am.killBackgroundProcesses(v.pkg)
                    } catch (e: Throwable) {
                    }
                }
                victims.map { it.label }
            }
        }

    // ---------------- Jangan Ganggu ----------------
    private fun nm(ctx: Context): NotificationManager = ctx.getSystemService(NotificationManager::class.java)

    fun dndAccess(ctx: Context): Boolean = try {
        nm(ctx).isNotificationPolicyAccessGranted
    } catch (e: Throwable) {
        false
    }

    /** Hanya alarm yang boleh berbunyi saat aktif. Lewat NotificationManager jika diizinkan, kalau tidak lewat Shizuku. */
    suspend fun setDnd(ctx: Context, on: Boolean): Boolean = withContext(Dispatchers.IO) {
        if (dndAccess(ctx)) {
            try {
                nm(ctx).setInterruptionFilter(
                    if (on) NotificationManager.INTERRUPTION_FILTER_ALARMS else NotificationManager.INTERRUPTION_FILTER_ALL
                )
                true
            } catch (e: Throwable) {
                false
            }
        } else if (Sh.granted()) {
            Sh.run("settings put global zen_mode ${if (on) 1 else 0}").ok
        } else {
            false
        }
    }

    suspend fun dndOn(ctx: Context): Boolean = withContext(Dispatchers.IO) {
        if (dndAccess(ctx)) {
            nm(ctx).currentInterruptionFilter in 2..4
        } else if (Sh.granted()) {
            Sh.run("settings get global zen_mode").out.trim().let { it != "0" && it != "null" && it.isNotEmpty() }
        } else {
            false
        }
    }

    // ---------------- Layar redup ----------------
    suspend fun setDim(ctx: Context, on: Boolean): Boolean = withContext(Dispatchers.IO) {
        if (!Sh.granted()) return@withContext false
        val p = prefs(ctx)
        if (on) {
            if (!p.getBoolean("dim_on", false)) {
                val cur = Sh.run("settings get system screen_brightness").out.trim().toIntOrNull() ?: 128
                val mode = Sh.run("settings get system screen_brightness_mode").out.trim().toIntOrNull() ?: 1
                p.edit().putInt("prev_bright", cur).putInt("prev_bmode", mode).putBoolean("dim_on", true).commit()
            }
            val target = max(20, (p.getInt("prev_bright", 128) * 0.6).toInt())
            Sh.run("settings put system screen_brightness_mode 0; settings put system screen_brightness $target").ok
        } else {
            restoreDim(ctx)
        }
    }

    private fun restoreDim(ctx: Context): Boolean {
        val p = prefs(ctx)
        if (!p.getBoolean("dim_on", false)) return true
        if (!Sh.granted()) return false
        val r = Sh.run(
            "settings put system screen_brightness ${p.getInt("prev_bright", 128)}; " +
                "settings put system screen_brightness_mode ${p.getInt("prev_bmode", 1)}"
        )
        if (r.ok) p.edit().putBoolean("dim_on", false).commit()
        return r.ok
    }

    fun dimOn(ctx: Context): Boolean = prefs(ctx).getBoolean("dim_on", false)

    suspend fun trimCaches(): Boolean = withContext(Dispatchers.IO) {
        if (!Sh.granted()) return@withContext false
        Sh.run("pm trim-caches 999G").ok
    }

    // ---------------- Terapkan dan kembalikan ----------------
    private fun clean(v: String, def: String): String {
        val t = v.trim()
        return if (t.isEmpty() || t == "null") def else t
    }

    /** Terapkan pengaturan performa. Nilai awal disimpan sekali per sesi. Aman dipanggil tanpa Shizuku. */
    suspend fun apply(ctx: Context, game: String, maxHz: Int) = withContext(Dispatchers.IO) {
        val p = prefs(ctx)
        val shz = Sh.granted()
        val dnd = p.getBoolean("dnd", true)
        val anim = p.getBoolean("anim", true) && shz
        val hz = p.getBoolean("hz", true) && shz
        val perf = p.getBoolean("perf", true) && shz
        val heads = p.getBoolean("heads", true) && shz

        if (!p.getBoolean("applied", false)) {
            val ed = p.edit()
            ed.putBoolean("applied", true)
            ed.putString("game_pkg", game)
            ed.putBoolean("ap_shell", shz)
            ed.putBoolean("ap_anim", anim)
            ed.putBoolean("ap_hz", hz)
            ed.putBoolean("ap_perf", perf)
            ed.putBoolean("ap_heads", heads)
            if (dnd) {
                if (dndAccess(ctx)) {
                    ed.putString("dnd_via", "nm")
                    ed.putInt("prev_filter", nm(ctx).currentInterruptionFilter)
                } else if (shz) {
                    ed.putString("dnd_via", "zen")
                    ed.putString("prev_zen", clean(Sh.run("settings get global zen_mode").out, "0"))
                } else {
                    ed.putString("dnd_via", "none")
                }
            } else {
                ed.putString("dnd_via", "none")
            }
            if (shz) {
                ed.putString(
                    "prev_anim",
                    clean(Sh.run("settings get global window_animation_scale").out, "1.0") + "|" +
                        clean(Sh.run("settings get global transition_animation_scale").out, "1.0") + "|" +
                        clean(Sh.run("settings get global animator_duration_scale").out, "1.0")
                )
                ed.putString("prev_heads", clean(Sh.run("settings get global heads_up_notifications_enabled").out, "1"))
            }
            ed.commit()
        }

        if (dnd && p.getString("dnd_via", "none") != "none") setDnd(ctx, true)
        if (shz) {
            Sh.run("cmd game mode performance $game")
            Sh.run("cmd game set --mode performance --user 0 $game")
            if (heads) Sh.run("settings put global heads_up_notifications_enabled 0")
            if (anim) {
                Sh.run(
                    "settings put global window_animation_scale 0.5; " +
                        "settings put global transition_animation_scale 0.5; " +
                        "settings put global animator_duration_scale 0.5"
                )
            }
            if (hz) Sh.run("settings put system min_refresh_rate $maxHz; settings put system peak_refresh_rate $maxHz")
            if (perf) Sh.run("cmd power set-fixed-performance-mode-enabled true")
        }
    }

    fun pending(ctx: Context): Boolean {
        val p = prefs(ctx)
        return p.getBoolean("applied", false) || p.getBoolean("dim_on", false)
    }

    /** Kembalikan semua yang diubah. false jika ada yang butuh Shizuku tapi Shizuku tidak tersedia. */
    suspend fun restore(ctx: Context): Boolean = withContext(Dispatchers.IO) {
        val p = prefs(ctx)
        if (!pending(ctx)) return@withContext true

        // DND lewat NotificationManager tidak butuh Shizuku
        var ok = true
        when (p.getString("dnd_via", "none")) {
            "nm" -> if (dndAccess(ctx)) {
                val f = p.getInt("prev_filter", NotificationManager.INTERRUPTION_FILTER_ALL)
                try {
                    nm(ctx).setInterruptionFilter(if (f <= 0) NotificationManager.INTERRUPTION_FILTER_ALL else f)
                } catch (e: Throwable) {
                    ok = false
                }
            }
            "zen" -> if (Sh.granted()) {
                Sh.run("settings put global zen_mode ${p.getString("prev_zen", "0")}")
            } else {
                ok = false
            }
        }

        val needShell = p.getBoolean("ap_shell", false) || p.getBoolean("dim_on", false)
        if (needShell && !Sh.granted()) return@withContext false

        if (p.getBoolean("ap_shell", false)) {
            val game = p.getString("game_pkg", "") ?: ""
            if (game.isNotEmpty()) Sh.run("cmd game mode standard $game")
            if (p.getBoolean("ap_heads", false)) {
                Sh.run("settings put global heads_up_notifications_enabled ${p.getString("prev_heads", "1")}")
            }
            if (p.getBoolean("ap_anim", false)) {
                val a = (p.getString("prev_anim", "1.0|1.0|1.0") ?: "1.0|1.0|1.0").split("|")
                Sh.run(
                    "settings put global window_animation_scale ${a.getOrElse(0) { "1.0" }}; " +
                        "settings put global transition_animation_scale ${a.getOrElse(1) { "1.0" }}; " +
                        "settings put global animator_duration_scale ${a.getOrElse(2) { "1.0" }}"
                )
            }
            if (p.getBoolean("ap_hz", false)) {
                Sh.run("settings delete system min_refresh_rate; settings delete system peak_refresh_rate")
            }
            if (p.getBoolean("ap_perf", false)) {
                Sh.run("cmd power set-fixed-performance-mode-enabled false")
            }
        }
        restoreDim(ctx)
        p.edit()
            .putBoolean("applied", false)
            .remove("game_pkg").remove("dnd_via")
            .remove("prev_zen").remove("prev_filter").remove("prev_anim").remove("prev_heads")
            .remove("ap_shell").remove("ap_anim").remove("ap_hz").remove("ap_perf").remove("ap_heads")
            .commit()
        ok
    }
}
