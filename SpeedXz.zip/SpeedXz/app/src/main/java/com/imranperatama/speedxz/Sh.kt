package com.imranperatama.speedxz

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

data class ShResult(val code: Int, val out: String) {
    val ok: Boolean get() = code == 0
}

/**
 * Jalankan perintah shell lewat Shizuku (hak akses ADB atau root).
 * Semua fungsi aman dipanggil walau Shizuku belum siap: hasilnya false atau kode error.
 */
object Sh {
    const val SHIZUKU_PKG = "moe.shizuku.privileged.api"

    private val newProcess by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        ).apply { isAccessible = true }
    }

    fun binderAlive(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    fun granted(): Boolean = try {
        binderAlive() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    fun uid(): Int = try {
        Shizuku.getUid()
    } catch (e: Throwable) {
        -1
    }

    fun requestPermission(): Boolean = try {
        Shizuku.requestPermission(100)
        true
    } catch (e: Throwable) {
        false
    }

    /** Jalankan satu perintah (boleh berisi ; dan |). stderr digabung ke output. */
    fun run(cmd: String): ShResult {
        if (!granted()) return ShResult(-1, "Shizuku belum siap")
        return try {
            val args = arrayOf("sh", "-c", "($cmd) 2>&1")
            val proc = newProcess.invoke(null, args, null, null) as Process
            val text = proc.inputStream.bufferedReader().use { it.readText() }
            val code = proc.waitFor()
            ShResult(code, text.trim())
        } catch (e: Throwable) {
            val root = e.cause ?: e
            ShResult(-2, root.message ?: root.javaClass.simpleName)
        }
    }
}
