package com.imranperatama.speedxz

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

data class AiMsg(val fromUser: Boolean, val text: String)

class AiResult(val ok: Boolean, val text: String)

/**
 * Klien Gemini tanpa library tambahan (HttpURLConnection), supaya aplikasi tetap ringan.
 * API key dan nama model diisi pengguna di tab SETUP, tidak ada di kode sumber.
 */
object Gemini {
    const val DEFAULT_MODEL = "gemini-3.8-flash"

    const val SYSTEM =
        "Kamu asisten performa Android di aplikasi Speed Xz. Jawab dalam bahasa Indonesia, " +
            "sangat singkat (maksimal 3 kalimat pendek), praktis, dan langsung ke langkah yang bisa dilakukan. " +
            "Pakai hanya angka yang diberikan di DATA HP; jika bertuliskan N/A jangan mengarang. " +
            "Jangan menjanjikan FPS naik. Jangan menyarankan cheat, mod game, root, atau mematikan fitur keamanan."

    /** Satu panggilan HTTP. code -1 berarti gagal sebelum ada jawaban; timeout true jika kehabisan waktu. */
    private class Raw(val result: AiResult, val code: Int, val timeout: Boolean, val body: String)

    /**
     * Model Flash terbaru berpikir dulu secara bawaan (tingkat menengah), itu yang membuat jawaban lama.
     * Untuk chat pendek di dalam game, tingkat berpikir diturunkan ke rendah. Model 2.5 memakai anggaran 0.
     * Model Pro tidak bisa dimatikan, jadi dibiarkan.
     */
    private fun thinkingFor(model: String): JSONObject? {
        val m = model.lowercase()
        return when {
            m.contains("pro") -> null
            m.contains("2.5") || m.contains("2.0") -> JSONObject().put("thinkingBudget", 0)
            else -> JSONObject().put("thinkingLevel", "low")
        }
    }

    private fun call(
        key: String,
        model: String,
        system: String,
        history: List<AiMsg>,
        thinking: JSONObject?,
        readMs: Int,
        maxTokens: Int
    ): Raw {
        var conn: HttpURLConnection? = null
        try {
            conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                .openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 10000
            conn.readTimeout = readMs
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", key.trim())

            val body = JSONObject()
            body.put(
                "system_instruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
            )
            val contents = JSONArray()
            for (h in history) {
                contents.put(
                    JSONObject()
                        .put("role", if (h.fromUser) "user" else "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", h.text)))
                )
            }
            body.put("contents", contents)
            val gen = JSONObject().put("temperature", 0.5).put("maxOutputTokens", maxTokens)
            if (thinking != null) gen.put("thinkingConfig", thinking)
            body.put("generationConfig", gen)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.bufferedReader()?.use { it.readText() } ?: ""
            return if (code !in 200..299) {
                Raw(AiResult(false, errorText(code, raw)), code, false, raw)
            } else {
                Raw(parse(raw), code, false, raw)
            }
        } catch (e: UnknownHostException) {
            return Raw(AiResult(false, "Tidak ada koneksi internet."), -1, false, "")
        } catch (e: SocketTimeoutException) {
            return Raw(AiResult(false, "Gemini terlalu lama menjawab. Coba lagi."), -1, true, "")
        } catch (e: Throwable) {
            return Raw(AiResult(false, "Gagal menghubungi Gemini: ${e.message}"), -1, false, "")
        } finally {
            conn?.disconnect()
        }
    }

    suspend fun ask(key: String, model: String, system: String, history: List<AiMsg>): AiResult =
        withContext(Dispatchers.IO) {
            if (key.isBlank()) {
                return@withContext AiResult(false, "API key belum diisi. Buka Speed Xz, tab SETUP, lalu isi Kunci AI.")
            }
            val m = model.trim().removePrefix("models/").ifEmpty { DEFAULT_MODEL }
            val think = thinkingFor(m)
            var r = call(key, m, system, history, think, 25000, 700)
            // model menolak pengaturan berpikir: ulangi tanpa pengaturan itu
            if (!r.result.ok && r.code == 400 && think != null && !r.body.contains("API key", ignoreCase = true)) {
                r = call(key, m, system, history, null, 25000, 700)
            }
            // kehabisan waktu: ulangi sekali dengan pertanyaan terakhir saja dan jawaban lebih pendek
            if (!r.result.ok && r.timeout) {
                val lastQ = history.lastOrNull { it.fromUser }
                val short = if (lastQ != null) listOf(lastQ) else history
                r = call(key, m, system, short, think, 25000, 400)
            }
            r.result
        }

    private fun parse(raw: String): AiResult {
        return try {
            val j = JSONObject(raw)
            val cands = j.optJSONArray("candidates")
            if (cands == null || cands.length() == 0) {
                val block = j.optJSONObject("promptFeedback")?.optString("blockReason") ?: ""
                return AiResult(false, if (block.isNotEmpty()) "Pertanyaan diblokir Gemini ($block)." else "Jawaban kosong.")
            }
            val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            val sb = StringBuilder()
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    if (p.optBoolean("thought", false)) continue
                    sb.append(p.optString("text", ""))
                }
            }
            val t = sb.toString().trim()
            if (t.isEmpty()) AiResult(false, "Jawaban kosong. Coba pertanyaan lain.") else AiResult(true, t)
        } catch (e: Throwable) {
            AiResult(false, "Jawaban tidak bisa dibaca.")
        }
    }

    private fun errorText(code: Int, raw: String): String {
        val msg = try {
            JSONObject(raw).optJSONObject("error")?.optString("message") ?: ""
        } catch (e: Throwable) {
            ""
        }
        val base = when {
            code == 400 && msg.contains("API key", ignoreCase = true) -> "API key tidak valid."
            code == 400 -> "Permintaan ditolak."
            code == 401 || code == 403 -> "API key ditolak atau tidak punya akses ke model ini."
            code == 404 -> "Model tidak ditemukan. Cek nama model di tab SETUP, kolom Kunci AI."
            code == 429 -> "Kuota habis atau terlalu sering. Tunggu sebentar lalu coba lagi."
            code >= 500 -> "Server Gemini sedang sibuk. Coba lagi."
            else -> "Kesalahan $code."
        }
        return if (msg.isNotEmpty()) base + " (" + msg.take(140) + ")" else base
    }
}
