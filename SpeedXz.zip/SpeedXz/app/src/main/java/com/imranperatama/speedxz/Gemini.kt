package com.imranperatama.speedxz

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

data class AiMsg(val fromUser: Boolean, val text: String)

class AiResult(val ok: Boolean, val text: String, val model: String = "")

/**
 * Klien Gemini tanpa library tambahan (HttpURLConnection), supaya aplikasi tetap ringan.
 * API key dan nama model diisi pengguna di tab SETUP, tidak ada di kode sumber.
 */
object Gemini {
    const val DEFAULT_MODEL = "gemini-3.8-flash"

    const val SYSTEM =
        "Kamu asisten performa Android di aplikasi Speed Xz. Jawab dalam bahasa Indonesia, " +
            "sangat singkat (maksimal 3 kalimat pendek), praktis, dan langsung ke langkah yang bisa dilakukan. " +
            "Pakai hanya angka yang diberikan di DATA HP; jika bertuliskan N/A jangan mengarang. " +
            "Jangan menjanjikan FPS naik. Jangan menyarankan cheat, mod game, root, atau mematikan fitur keamanan. " +
            "Jika pengguna meminta memutar lagu, jawab hanya dengan [[PUTAR:judul artis]]."

    /** Peran pelatih game: jawaban lebih panjang dan spesifik, memakai pelajaran pengguna dan info terbaru dari pencarian. */
    const val SYSTEM_COACH =
        "Kamu pelatih game di aplikasi Speed Xz, paham isi game: peta, mode, senjata atau karakter, ekonomi, posisi, rotasi. " +
            "Jawab dalam bahasa Indonesia, ringkas (maksimal 8 baris pendek, boleh daftar singkat). " +
            "Beri langkah spesifik: nama senjata atau karakter beserta perlengkapannya, posisi, cara bertahan, dan urutan bermain. " +
            "Patch dan meta berubah: jika tidak yakin dengan versi sekarang, katakan terus terang dan jangan mengarang nama atau angka. " +
            "Pakai PELAJARAN dan RIWAYAT SESI di bawah supaya pengguna tidak mengulang kesalahan yang sama, dan sebut singkat pelajaran mana yang dipakai. " +
            "Pakai angka DATA HP hanya jika relevan; jika N/A jangan mengarang. " +
            "Jangan menyarankan cheat, hack, atau mod. Jika pengguna meminta memutar lagu, jawab hanya dengan [[PUTAR:judul artis]]."

    /** Satu panggilan HTTP. code -1 berarti gagal sebelum ada jawaban; timeout true jika kehabisan waktu. */
    private class Raw(val result: AiResult, val code: Int, val timeout: Boolean, val body: String)

    /**
     * Model Flash terbaru berpikir dulu secara bawaan (tingkat menengah), itu yang membuat jawaban lama.
     * Untuk chat pendek di dalam game, tingkat berpikir diturunkan ke rendah. Model 2.5 memakai anggaran 0.
     * Model Pro tidak bisa dimatikan, jadi dibiarkan.
     */
    private fun thinkingFor(model: String): JSONObject? {
        val m = model.lowercase()
        return when {
            m.contains("pro") -> null
            m.contains("2.5") || m.contains("2.0") -> JSONObject().put("thinkingBudget", 0)
            else -> JSONObject().put("thinkingLevel", "low")
        }
    }

    private fun call(
        key: String,
        model: String,
        system: String,
        history: List<AiMsg>,
        thinking: JSONObject?,
        readMs: Int,
        maxTokens: Int,
        search: Boolean
    ): Raw {
        var conn: HttpURLConnection? = null
        try {
            conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                .openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 10000
            conn.readTimeout = readMs
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", key.trim())

            val body = JSONObject()
            body.put(
                "system_instruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
            )
            val contents = JSONArray()
            for (h in history) {
                contents.put(
                    JSONObject()
                        .put("role", if (h.fromUser) "user" else "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", h.text)))
                )
            }
            body.put("contents", contents)
            if (search) body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            val gen = JSONObject().put("temperature", 0.5).put("maxOutputTokens", maxTokens)
            if (thinking != null) gen.put("thinkingConfig", thinking)
            body.put("generationConfig", gen)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.bufferedReader()?.use { it.readText() } ?: ""
            return if (code !in 200..299) {
                Raw(AiResult(false, errorText(code, raw)), code, false, raw)
            } else {
                Raw(parse(raw), code, false, raw)
            }
        } catch (e: UnknownHostException) {
            return Raw(AiResult(false, "Tidak ada koneksi internet."), -1, false, "")
        } catch (e: SocketTimeoutException) {
            return Raw(AiResult(false, "Gemini terlalu lama menjawab. Coba lagi."), -1, true, "")
        } catch (e: Throwable) {
            return Raw(AiResult(false, "Gagal menghubungi Gemini: ${e.message}"), -1, false, "")
        } finally {
            conn?.disconnect()
        }
    }

    /** Model yang barusan sibuk atau lambat: dilewati dulu beberapa menit supaya pertanyaan berikutnya langsung ke model yang jalan. */
    private val cool = HashMap<String, Long>()
    private const val COOL_MS = 120_000L

    private val FALLBACK = listOf("gemini-3.6-flash", "gemini-3.5-flash-lite", "gemini-2.5-flash")

    private fun buildChain(primary: String): List<String> {
        val all = ArrayList<String>()
        all.add(primary)
        for (f in FALLBACK) if (f != primary) all.add(f)
        val now = System.currentTimeMillis()
        val ready = ArrayList<String>()
        val resting = ArrayList<String>()
        synchronized(cool) {
            for (m in all) if ((cool[m] ?: 0L) > now) resting.add(m) else ready.add(m)
        }
        return ready + resting
    }

    /** Satu model: panggil dengan tingkat berpikir rendah, ulangi tanpa itu jika ditolak (400). */
    private fun tryModel(key: String, m: String, system: String, history: List<AiMsg>, search: Boolean, maxTokens: Int): Raw {
        val think = thinkingFor(m)
        val readMs = if (search) 30000 else 20000
        var r = call(key, m, system, history, think, readMs, maxTokens, search)
        // ditolak (400): ulangi tanpa pengaturan berpikir dan tanpa pencarian
        if (!r.result.ok && r.code == 400 && (think != null || search) && !r.body.contains("API key", ignoreCase = true)) {
            r = call(key, m, system, history, null, 20000, maxTokens, false)
        }
        return r
    }

    /**
     * Tanya Gemini. Jika model utama sibuk (503), kena batas (429), tidak ada (404), atau terlalu lama,
     * otomatis pindah ke model cadangan. Kesalahan key atau internet langsung dilaporkan.
     */
    suspend fun ask(
        key: String,
        model: String,
        system: String,
        history: List<AiMsg>,
        search: Boolean = false,
        maxTokens: Int = 700
    ): AiResult =
        withContext(Dispatchers.IO) {
            if (key.isBlank()) {
                return@withContext AiResult(false, "API key belum diisi. Buka Speed Xz, tab SETUP, lalu isi Kunci AI.")
            }
            val primary = model.trim().removePrefix("models/").ifEmpty { DEFAULT_MODEL }
            val chain = buildChain(primary)
            var lastText = ""
            var tried = 0
            for (m in chain) {
                tried++
                val r = tryModel(key, m, system, history, search, maxTokens)
                if (r.result.ok) return@withContext AiResult(true, r.result.text, m)
                lastText = r.result.text
                val again = r.timeout || r.code == 503 || r.code == 429 || r.code == 404 || r.code == 500 || r.code == 502 || r.code == 504
                if (!again) break
                synchronized(cool) { cool[m] = System.currentTimeMillis() + COOL_MS }
            }
            AiResult(false, if (tried > 1) "$lastText (sudah dicoba $tried model)" else lastText)
        }

    private fun parse(raw: String): AiResult {
        return try {
            val j = JSONObject(raw)
            val cands = j.optJSONArray("candidates")
            if (cands == null || cands.length() == 0) {
                val block = j.optJSONObject("promptFeedback")?.optString("blockReason") ?: ""
                return AiResult(false, if (block.isNotEmpty()) "Pertanyaan diblokir Gemini ($block)." else "Jawaban kosong.")
            }
            val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            val sb = StringBuilder()
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    if (p.optBoolean("thought", false)) continue
                    sb.append(p.optString("text", ""))
                }
            }
            val t = sb.toString().trim()
            if (t.isEmpty()) AiResult(false, "Jawaban kosong. Coba pertanyaan lain.") else AiResult(true, t)
        } catch (e: Throwable) {
            AiResult(false, "Jawaban tidak bisa dibaca.")
        }
    }

    private fun errorText(code: Int, raw: String): String {
        val msg = try {
            JSONObject(raw).optJSONObject("error")?.optString("message") ?: ""
        } catch (e: Throwable) {
            ""
        }
        val base = when {
            code == 400 && msg.contains("API key", ignoreCase = true) -> "API key tidak valid."
            code == 400 -> "Permintaan ditolak."
            code == 401 || code == 403 -> "API key ditolak atau tidak punya akses ke model ini."
            code == 404 -> "Model tidak ditemukan. Cek nama model di tab SETUP, kolom Kunci AI."
            code == 429 -> "Kuota habis atau terlalu sering. Tunggu sebentar lalu coba lagi."
            code >= 500 -> "Server Gemini sedang sibuk. Coba lagi."
            else -> "Kesalahan $code."
        }
        return if (msg.isNotEmpty() && code < 500 && code != 429) base + " (" + msg.take(140) + ")" else base
    }
}
