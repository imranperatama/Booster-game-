package com.imranperatama.speedxz

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

data class AiMsg(val fromUser: Boolean, val text: String)

class AiResult(val ok: Boolean, val text: String)

/**
 * Klien Gemini tanpa library tambahan (HttpURLConnection), supaya aplikasi tetap ringan.
 * API key dan nama model diisi pengguna di tab SETUP, tidak ada di kode sumber.
 */
object Gemini {
    const val DEFAULT_MODEL = "gemini-3.8-flash"

    const val SYSTEM =
        "Kamu asisten performa Android di aplikasi Speed Xz. Jawab dalam bahasa Indonesia, " +
            "singkat (maksimal 5 kalimat pendek), praktis, dan langsung ke langkah yang bisa dilakukan. " +
            "Pakai hanya angka yang diberikan di DATA HP; jika bertuliskan N/A jangan mengarang. " +
            "Jangan menjanjikan FPS naik. Jangan menyarankan cheat, mod game, root, atau mematikan fitur keamanan."

    suspend fun ask(key: String, model: String, system: String, history: List<AiMsg>): AiResult =
        withContext(Dispatchers.IO) {
            if (key.isBlank()) {
                return@withContext AiResult(false, "API key belum diisi. Buka Speed Xz, tab SETUP, lalu isi Kunci AI.")
            }
            var conn: HttpURLConnection? = null
            try {
                val m = model.trim().removePrefix("models/").ifEmpty { DEFAULT_MODEL }
                conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent")
                    .openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 12000
                conn.readTimeout = 40000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setRequestProperty("x-goog-api-key", key.trim())

                val body = JSONObject()
                body.put(
                    "system_instruction",
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
                )
                val contents = JSONArray()
                for (h in history) {
                    contents.put(
                        JSONObject()
                            .put("role", if (h.fromUser) "user" else "model")
                            .put("parts", JSONArray().put(JSONObject().put("text", h.text)))
                    )
                }
                body.put("contents", contents)
                body.put("generationConfig", JSONObject().put("temperature", 0.5).put("maxOutputTokens", 1500))
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val raw = stream?.bufferedReader()?.use { it.readText() } ?: ""
                if (code !in 200..299) {
                    AiResult(false, errorText(code, raw))
                } else {
                    parse(raw)
                }
            } catch (e: UnknownHostException) {
                AiResult(false, "Tidak ada koneksi internet.")
            } catch (e: SocketTimeoutException) {
                AiResult(false, "Gemini terlalu lama menjawab. Coba lagi.")
            } catch (e: Throwable) {
                AiResult(false, "Gagal menghubungi Gemini: ${e.message}")
            } finally {
                conn?.disconnect()
            }
        }

    private fun parse(raw: String): AiResult {
        return try {
            val j = JSONObject(raw)
            val cands = j.optJSONArray("candidates")
            if (cands == null || cands.length() == 0) {
                val block = j.optJSONObject("promptFeedback")?.optString("blockReason") ?: ""
                return AiResult(false, if (block.isNotEmpty()) "Pertanyaan diblokir Gemini ($block)." else "Jawaban kosong.")
            }
            val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            val sb = StringBuilder()
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    if (p.optBoolean("thought", false)) continue
                    sb.append(p.optString("text", ""))
                }
            }
            val t = sb.toString().trim()
            if (t.isEmpty()) AiResult(false, "Jawaban kosong. Coba pertanyaan lain.") else AiResult(true, t)
        } catch (e: Throwable) {
            AiResult(false, "Jawaban tidak bisa dibaca.")
        }
    }

    private fun errorText(code: Int, raw: String): String {
        val msg = try {
            JSONObject(raw).optJSONObject("error")?.optString("message") ?: ""
        } catch (e: Throwable) {
            ""
        }
        val base = when {
            code == 400 && msg.contains("API key", ignoreCase = true) -> "API key tidak valid."
            code == 400 -> "Permintaan ditolak."
            code == 401 || code == 403 -> "API key ditolak atau tidak punya akses ke model ini."
            code == 404 -> "Model tidak ditemukan. Cek nama model di tab SETUP, kolom Kunci AI."
            code == 429 -> "Kuota habis atau terlalu sering. Tunggu sebentar lalu coba lagi."
            code >= 500 -> "Server Gemini sedang sibuk. Coba lagi."
            else -> "Kesalahan $code."
        }
        return if (msg.isNotEmpty()) base + " (" + msg.take(140) + ")" else base
    }
}
