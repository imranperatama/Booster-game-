package com.imranperatama.speedxz

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Notifikasi sesi game (Android 13+), diminta sekali
        val p = getSharedPreferences("speedxz", MODE_PRIVATE)
        if (Build.VERSION.SDK_INT >= 33 && !p.getBoolean("asked_notif", false) &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            p.edit().putBoolean("asked_notif", true).apply()
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        }
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Red,
                    background = Bg,
                    surface = Bg,
                    onBackground = TextMain,
                    onSurface = TextMain
                )
            ) {
                Surface(color = Bg) {
                    SpeedXzApp(vm)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.refreshShizuku()
    }
}

private val TABS = listOf("HOME", "GAME", "BERSIH", "AMAN", "BATERAI", "SETUP")
private const val SETUP_TAB = 5

@Composable
fun SpeedXzApp(vm: AppViewModel) {
    var tab by remember { mutableIntStateOf(0) }
    val anim = !vm.isGameRunning

    CompositionLocalProvider(LocalAnim provides anim) {
        Crossfade(targetState = vm.introOn, animationSpec = tween(450), label = "intro") { introNow ->
        if (introNow) {
            IntroScreen { vm.finishIntro() }
        } else {
            Column(Modifier.fillMaxSize().background(Bg).systemBarsPadding().imePadding()) {
                Header(vm) { tab = SETUP_TAB }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    Crossfade(
                        targetState = tab,
                        animationSpec = if (anim) tween(160) else snap(),
                        label = "tab"
                    ) { t ->
                        when (t) {
                            0 -> HomeScreen(vm) { tab = SETUP_TAB }
                            1 -> GameScreen(vm)
                            2 -> CleanScreen(vm)
                            3 -> SafeScreen(vm)
                            4 -> BatteryScreen(vm)
                            else -> SetupScreen(vm)
                        }
                    }
                }
                val n = vm.notice
                val last = remember { arrayOfNulls<Notice>(1) }
                if (n != null) last[0] = n
                AnimatedVisibility(
                    visible = n != null,
                    enter = if (anim) slideInVertically(initialOffsetY = { it }) + fadeIn() else fadeIn(snap()),
                    exit = fadeOut(if (anim) tween(150) else snap())
                ) {
                    last[0]?.let {
                        NoticeBar(it, onSetup = { tab = SETUP_TAB; vm.dismissNotice() }, onClose = { vm.dismissNotice() })
                    }
                }
                NavBar(tab) { tab = it }
            }
        }
        }
    }
}

@Composable
private fun NoticeBar(n: Notice, onSetup: () -> Unit, onClose: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(RedDeep).clickable { onClose() }
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Txt(n.text, Modifier.weight(1f), size = 13, weight = FontWeight.Bold)
        if (n.needSetup) SlantButton("HUBUNGKAN", small = true) { onSetup() }
    }
}

@Composable
private fun Header(vm: AppViewModel, onShizuku: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Row {
                Txt("SPEED ", size = 26, weight = FontWeight.Black, italic = true, spacing = 1f)
                Txt("Xz", size = 26, color = Red, weight = FontWeight.Black, italic = true)
            }
            Txt("x IMRAN PERATAMA", size = 11, color = RedGlow, weight = FontWeight.Bold, italic = true, spacing = 3f)
        }
        Box(
            Modifier.clip(SlantShape(7f)).background(Panel2).clickable { onShizuku() }
                .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
            Txt(
                if (vm.shzReady) "SHIZUKU AKTIF" else "HUBUNGKAN",
                size = 11, color = if (vm.shzReady) Good else Warn, weight = FontWeight.Black, italic = true, spacing = 1f
            )
        }
    }
}

@Composable
private fun NavBar(selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().background(PanelColor)) {
        TABS.forEachIndexed { i, name ->
            val on = i == selected
            val c by animateColorAsState(if (on) Red else Muted, spec(150), label = "navc")
            val w by animateDpAsState(if (on) 22.dp else 0.dp, spec(180), label = "navw")
            Column(
                Modifier.weight(1f).clickable { onSelect(i) }.padding(top = 10.dp, bottom = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Txt(name, size = 9, color = c, weight = FontWeight.Black, italic = true)
                Spacer(Modifier.height(6.dp))
                Box(Modifier.width(22.dp).height(4.dp), contentAlignment = Alignment.Center) {
                    Box(Modifier.width(w).height(4.dp).clip(SlantShape(3f)).background(Red))
                }
            }
        }
    }
}
