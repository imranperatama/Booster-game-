package com.imranperatama.speedxz

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Red,
                    background = Bg,
                    surface = Bg,
                    onBackground = TextMain,
                    onSurface = TextMain
                )
            ) {
                Surface(color = Bg) {
                    SpeedXzApp(vm) { startActivity(vm.shizukuIntent()) }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.refreshShizuku()
    }
}

private val TABS = listOf("BERANDA", "GAME", "BERSIH", "AMAN", "BATERAI")

@Composable
fun SpeedXzApp(vm: AppViewModel, onOpenShizuku: () -> Unit) {
    var intro by remember { mutableStateOf(true) }
    var tab by remember { mutableIntStateOf(0) }

    if (intro) {
        IntroScreen { intro = false }
        return
    }

    Column(Modifier.fillMaxSize().background(Bg).systemBarsPadding()) {
        Header(vm)
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                0 -> HomeScreen(vm, onOpenShizuku)
                1 -> GameScreen(vm)
                2 -> CleanScreen(vm)
                3 -> SafeScreen(vm)
                else -> BatteryScreen(vm)
            }
        }
        NavBar(tab) { tab = it }
    }
}

@Composable
private fun Header(vm: AppViewModel) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Row {
                Txt("SPEED ", size = 26, weight = FontWeight.Black, italic = true, spacing = 1f)
                Txt("Xz", size = 26, color = Red, weight = FontWeight.Black, italic = true)
            }
            Txt("x IMRAN PERATAMA", size = 11, color = RedGlow, weight = FontWeight.Bold, italic = true, spacing = 3f)
        }
        Box(
            Modifier.clip(SlantShape(7f)).background(Panel2).padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
            Txt(
                if (vm.shzReady) "SHIZUKU AKTIF" else "SHIZUKU MATI",
                size = 11, color = if (vm.shzReady) Good else Warn, weight = FontWeight.Black, italic = true, spacing = 1f
            )
        }
    }
}

@Composable
private fun NavBar(selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().background(PanelColor)) {
        TABS.forEachIndexed { i, name ->
            val on = i == selected
            Column(
                Modifier.weight(1f).clickable { onSelect(i) }.padding(top = 10.dp, bottom = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Txt(name, size = 11, color = if (on) Red else Muted, weight = FontWeight.Black, italic = true, spacing = 0.5f)
                Spacer(Modifier.height(6.dp))
                Box(
                    Modifier.width(26.dp).height(4.dp).clip(SlantShape(3f))
                        .background(if (on) Red else PanelColor)
                )
            }
        }
    }
}
