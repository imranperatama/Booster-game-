package com.imranperatama.speedxz

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Notifikasi sesi game (Android 13+), diminta sekali
        val p = getSharedPreferences("speedxz", MODE_PRIVATE)
        if (Build.VERSION.SDK_INT >= 33 && !p.getBoolean("asked_notif", false) &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            p.edit().putBoolean("asked_notif", true).apply()
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        }
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Red,
                    background = Bg,
                    surface = Bg,
                    onBackground = TextMain,
                    onSurface = TextMain
                )
            ) {
                Surface(color = Bg) {
                    SpeedXzApp(vm)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.refreshShizuku()
    }
}

private val TABS = listOf("BERANDA", "GAME", "BERSIH", "AMAN", "BATERAI", "SETUP")
private const val SETUP_TAB = 5

@Composable
fun SpeedXzApp(vm: AppViewModel) {
    var tab by remember { mutableIntStateOf(0) }

    if (vm.introOn) {
        IntroScreen { vm.finishIntro() }
    } else {
        Column(Modifier.fillMaxSize().background(Bg).systemBarsPadding()) {
            Header(vm) { tab = SETUP_TAB }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (tab) {
                    0 -> HomeScreen(vm) { tab = SETUP_TAB }
                    1 -> GameScreen(vm)
                    2 -> CleanScreen(vm)
                    3 -> SafeScreen(vm)
                    4 -> BatteryScreen(vm)
                    else -> SetupScreen(vm)
                }
            }
            val n = vm.notice
            if (n != null) {
                NoticeBar(n, onSetup = { tab = SETUP_TAB; vm.dismissNotice() }, onClose = { vm.dismissNotice() })
            }
            NavBar(tab) { tab = it }
        }
    }
}

@Composable
private fun NoticeBar(n: Notice, onSetup: () -> Unit, onClose: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(RedDeep).clickable { onClose() }
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Txt(n.text, Modifier.weight(1f), size = 13, weight = FontWeight.Bold)
        if (n.needSetup) SlantButton("HUBUNGKAN", small = true) { onSetup() }
    }
}

@Composable
private fun Header(vm: AppViewModel, onShizuku: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Row {
                Txt("SPEED ", size = 26, weight = FontWeight.Black, italic = true, spacing = 1f)
                Txt("Xz", size = 26, color = Red, weight = FontWeight.Black, italic = true)
            }
            Txt("x IMRAN PERATAMA", size = 11, color = RedGlow, weight = FontWeight.Bold, italic = true, spacing = 3f)
        }
        Box(
            Modifier.clip(SlantShape(7f)).background(Panel2).clickable { onShizuku() }
                .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
            Txt(
                if (vm.shzReady) "SHIZUKU AKTIF" else "HUBUNGKAN",
                size = 11, color = if (vm.shzReady) Good else Warn, weight = FontWeight.Black, italic = true, spacing = 1f
            )
        }
    }
}

@Composable
private fun NavBar(selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().background(PanelColor)) {
        TABS.forEachIndexed { i, name ->
            val on = i == selected
            Column(
                Modifier.weight(1f).clickable { onSelect(i) }.padding(top = 10.dp, bottom = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Txt(name, size = 10, color = if (on) Red else Muted, weight = FontWeight.Black, italic = true)
                Spacer(Modifier.height(6.dp))
                Box(
                    Modifier.width(24.dp).height(4.dp).clip(SlantShape(3f))
                        .background(if (on) Red else PanelColor)
                )
            }
        }
    }
}
