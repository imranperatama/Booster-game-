package com.imranperatama.speedxz

import android.content.Context
import android.net.Uri
import android.widget.VideoView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

@Composable
private fun SwitchRow(title: String, note: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(Modifier.weight(1f)) {
            Txt(title, size = 15, weight = FontWeight.Bold)
            Txt(note, size = 12, color = Muted)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Red,
                uncheckedThumbColor = Muted,
                uncheckedTrackColor = Panel2,
                uncheckedBorderColor = Muted
            )
        )
    }
}

@Composable
fun ScreenTitle(title: String, sub: String) {
    Column(Modifier.padding(bottom = 4.dp)) {
        Txt(title, size = 26, weight = FontWeight.Black, italic = true, spacing = 1f)
        Txt(sub, size = 13, color = Muted)
    }
}

// ================= INTRO =================
@Composable
fun IntroScreen(onDone: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c: Context ->
                VideoView(c).apply {
                    setVideoURI(Uri.parse("android.resource://" + c.packageName + "/" + R.raw.intro))
                    setOnPreparedListener { mp ->
                        mp.isLooping = false
                        start()
                    }
                    setOnCompletionListener { onDone() }
                    setOnErrorListener { _, _, _ ->
                        onDone()
                        true
                    }
                }
            },
            onRelease = { it.stopPlayback() }
        )
        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xEE070708))))
                .systemBarsPadding()
                .padding(horizontal = 24.dp, vertical = 20.dp)
        ) {
            Column(Modifier.align(Alignment.BottomStart)) {
                Row {
                    Txt("SPEED ", size = 36, weight = FontWeight.Black, italic = true, spacing = 1f)
                    Txt("Xz", size = 36, color = Red, weight = FontWeight.Black, italic = true)
                }
                Txt("x IMRAN PERATAMA", size = 13, color = RedGlow, weight = FontWeight.Bold, italic = true, spacing = 3f)
            }
            SlantButton("LEWATI", Modifier.align(Alignment.BottomEnd), filled = false, small = true) { onDone() }
        }
    }
}

// ================= BERANDA =================
@Composable
fun HomeScreen(vm: AppViewModel, onSetup: () -> Unit) {
    val f = vm.facts
    val ramUsed = vm.ramTotal - vm.ramAvail
    val ramFrac = if (vm.ramTotal > 0) ramUsed.toFloat() / vm.ramTotal else 0f
    val stoUsed = vm.stoTotal - vm.stoFree
    val stoFrac = if (vm.stoTotal > 0) (stoUsed / vm.stoTotal).toFloat() else 0f
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Panel {
            Txt("HP KAMU", size = 11, color = RedGlow, weight = FontWeight.Bold, spacing = 2.5f)
            Txt(f.name, size = 22, weight = FontWeight.Black, italic = true)
            Spacer(Modifier.height(4.dp))
            Txt(f.android, size = 13, color = Muted)
            Txt("Chip: ${f.chip}  |  ${f.cores} inti  |  ${f.hz} Hz (maks ${f.maxHz} Hz)", size = 13, color = Muted)
            Txt("Kode perangkat: ${f.codename}", size = 13, color = Muted)
            Spacer(Modifier.height(4.dp))
            val mode = when (vm.shzUid) {
                0 -> "Shizuku aktif (root)"
                2000 -> "Shizuku aktif (ADB)"
                else -> if (vm.shzReady) "Shizuku aktif" else "Shizuku belum terhubung"
            }
            Txt(mode, size = 13, color = if (vm.shzReady) Good else Warn, weight = FontWeight.Bold)
        }

        if (!vm.shzReady) SetupCard(vm, onSetup)

        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Ring(vm.score(), "SKOR HP", Modifier.size(230.dp))
        }
        SlantButton(
            text = if (vm.busy == "BOOST") "MEMPROSES..." else "BOOST SEKARANG",
            modifier = Modifier.fillMaxWidth(),
            enabled = vm.busy == null
        ) { vm.boost() }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("RAM", String.format("%.1f / %.1f GB", ramUsed / 1024.0, vm.ramTotal / 1024.0), ramFrac, Modifier.weight(1f), hot = ramFrac > 0.85f)
            StatCard("PENYIMPANAN", String.format("%.0f / %.0f GB", stoUsed, vm.stoTotal), stoFrac, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard(
                "SUHU BATERAI", String.format("%.1f C", vm.batt.temp),
                ((vm.batt.temp - 20.0) / 30.0).toFloat(), Modifier.weight(1f), hot = vm.batt.temp >= 40.0
            )
            StatCard(
                "CPU", if (vm.cpu >= 0) "${vm.cpu}%" else "butuh Shizuku",
                if (vm.cpu >= 0) vm.cpu / 100f else 0f, Modifier.weight(1f), hot = vm.cpu >= 80
            )
        }

        Panel {
            Txt("AKTIVITAS", size = 11, color = RedGlow, weight = FontWeight.Bold, spacing = 2.5f)
            Spacer(Modifier.height(6.dp))
            if (vm.log.isEmpty()) {
                Txt("Belum ada aktivitas. Tekan Boost Sekarang.", size = 13, color = Muted)
            } else {
                vm.log.take(6).forEach { Txt(it, size = 13, color = TextMain) }
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun StepRow(ok: Boolean, text: String) {
    Row(Modifier.padding(vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Txt(if (ok) "OK" else "--", size = 13, color = if (ok) Good else Warn, weight = FontWeight.Black, italic = true)
        Txt(text, size = 14)
    }
}

@Composable
private fun SetupCard(vm: AppViewModel, onSetup: () -> Unit) {
    Panel {
        Txt("HUBUNGKAN SHIZUKU", size = 11, color = RedGlow, weight = FontWeight.Bold, spacing = 2.5f)
        Txt("Supaya boost penuh berjalan", size = 18, weight = FontWeight.Black, italic = true)
        Spacer(Modifier.height(8.dp))
        StepRow(vm.shzInstalled, "Aplikasi Shizuku terpasang")
        StepRow(vm.devOn, "Opsi pengembang aktif")
        StepRow(vm.wifiOn || vm.usbOn, "Debug nirkabel atau USB aktif")
        StepRow(vm.shzRunning, "Shizuku berjalan")
        StepRow(vm.shzGranted, "Izin untuk Speed Xz diberikan")
        Spacer(Modifier.height(10.dp))
        SlantButton("BUKA PANDUAN LANGKAH DEMI LANGKAH", Modifier.fillMaxWidth(), small = true) { onSetup() }
    }
}

// ================= GAME =================
@Composable
fun GameScreen(vm: AppViewModel) {
    val games = if (vm.showAll) vm.thirdParty else vm.thirdParty.filter { it.isGame }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { ScreenTitle("MODE GAME", "Tutup aplikasi lain, kunci performa, lalu buka game.") }
        item {
            Panel {
                Txt("OPSI SAAT MAIN", size = 11, color = RedGlow, weight = FontWeight.Bold, spacing = 2.5f)
                if (!vm.shzReady) {
                    Txt("Shizuku belum terhubung: tombol MAIN tetap membersihkan RAM lewat Android lalu membuka game. Opsi di bawah butuh Shizuku.", size = 12, color = Warn)
                }
                SwitchRow("Jangan ganggu", "Matikan notifikasi saat bermain", vm.optDnd) { vm.setOpt("dnd", it) }
                SwitchRow("Animasi cepat", "Skala animasi sistem jadi 0.5x", vm.optAnim) { vm.setOpt("anim", it) }
                SwitchRow("Refresh rate maksimal", "Kunci ${vm.facts.maxHz} Hz (tergantung merek HP)", vm.optHz) { vm.setOpt("hz", it) }
                SwitchRow("Performa tetap", "Minta sistem bertenaga penuh (Android 12+)", vm.optPerf) { vm.setOpt("perf", it) }
                Spacer(Modifier.height(8.dp))
                SlantButton(
                    "KEMBALIKAN NORMAL", Modifier.fillMaxWidth(), enabled = vm.busy == null, filled = false, small = true
                ) { vm.restoreDefaults() }
            }
        }
        item { Txt("PILIH GAME", size = 11, color = RedGlow, weight = FontWeight.Bold, spacing = 2.5f) }
        if (games.isEmpty()) {
            item {
                Txt(
                    if (vm.showAll) "Belum ada aplikasi terbaca." else "Tidak ada game terdeteksi. Tekan Tampilkan semua aplikasi.",
                    size = 13, color = Muted
                )
            }
        }
        items(games, key = { it.pkg }) { app ->
            Row(
                Modifier.fillMaxWidth().clip(SlantShape(10f)).background(PanelColor)
                    .padding(start = 16.dp, end = 20.dp, top = 10.dp, bottom = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                AppIcon(app.pkg)
                Column(Modifier.weight(1f)) {
                    Txt(app.label, size = 15, weight = FontWeight.Bold)
                    Txt(if (vm.gameActive == app.pkg) "Mode Game aktif" else app.pkg, size = 11, color = if (vm.gameActive == app.pkg) Good else Muted)
                }
                SlantButton("MAIN", enabled = vm.busy == null, small = true) { vm.playGame(app.pkg) }
            }
        }
        item {
            SlantButton(
                if (vm.showAll) "HANYA GAME" else "TAMPILKAN SEMUA APLIKASI",
                Modifier.fillMaxWidth(), filled = false, small = true
            ) { vm.showAll = !vm.showAll }
        }
        item { Spacer(Modifier.height(12.dp)) }
    }
}

// ================= BERSIH =================
@Composable
fun CleanScreen(vm: AppViewModel) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { ScreenTitle("PEMBERSIH", "Hapus cache semua aplikasi dan log sistem.") }
        item {
            Panel {
                Txt("RUANG BEBAS", size = 11, color = RedGlow, weight = FontWeight.Bold, spacing = 2.5f)
                Txt(String.format("%.2f GB dari %.0f GB", vm.stoFree, vm.stoTotal), size = 24, weight = FontWeight.Black, italic = true)
                Meter(if (vm.stoTotal > 0) ((vm.stoTotal - vm.stoFree) / vm.stoTotal).toFloat() else 0f)
                if (vm.lastClean.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Txt(vm.lastClean, size = 13, color = Good)
                }
                Spacer(Modifier.height(12.dp))
                SlantButton(
                    if (vm.busy == "CLEAN") "MEMBERSIHKAN..." else "BERSIHKAN CACHE",
                    Modifier.fillMaxWidth(), enabled = vm.busy == null
                ) { vm.clean() }
            }
        }
        item { Txt("DILINDUNGI SAAT BOOST", size = 11, color = RedGlow, weight = FontWeight.Bold, spacing = 2.5f) }
        item { Txt("Aplikasi yang dicentang tidak akan ditutup oleh Boost dan Mode Game.", size = 12, color = Muted) }
        items(vm.thirdParty, key = { it.pkg }) { app ->
            Row(
                Modifier.fillMaxWidth().clip(SlantShape(10f)).background(PanelColor)
                    .clickable { vm.toggleKeep(app.pkg) }
                    .padding(start = 16.dp, end = 20.dp, top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                AppIcon(app.pkg, 36.dp)
                Txt(app.label, Modifier.weight(1f), size = 14, weight = FontWeight.Bold)
                Switch(
                    checked = vm.keep.contains(app.pkg),
                    onCheckedChange = { vm.toggleKeep(app.pkg) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White, checkedTrackColor = Red,
                        uncheckedThumbColor = Muted, uncheckedTrackColor = Panel2, uncheckedBorderColor = Muted
                    )
                )
            }
        }
        item { Spacer(Modifier.height(12.dp)) }
    }
}

// ================= AMAN =================
@Composable
fun SafeScreen(vm: AppViewModel) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { ScreenTitle("KEAMANAN", "Lihat aplikasi yang memakai kamera, mikrofon, lokasi, SMS, dan kontak.") }
        item {
            Panel {
                val n = vm.perms.size
                Txt(
                    if (!vm.scanned) "Belum dipindai" else if (n == 0) "Tidak ada izin sensitif aktif" else "$n aplikasi memakai izin sensitif",
                    size = 18, weight = FontWeight.Black, italic = true
                )
                Spacer(Modifier.height(10.dp))
                SlantButton(
                    if (vm.busy == "SCAN") "MEMINDAI..." else "PINDAI IZIN",
                    Modifier.fillMaxWidth(), enabled = vm.busy == null
                ) { vm.scanPerms() }
                if (!vm.shzReady) {
                    Spacer(Modifier.height(8.dp))
                    Txt("Tanpa Shizuku, tombol CABUT membuka halaman izin aplikasi di pengaturan HP.", size = 12, color = Warn)
                }
            }
        }
        items(vm.perms, key = { it.pkg }) { p ->
            Panel {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    AppIcon(p.pkg, 38.dp)
                    Column(Modifier.weight(1f)) {
                        Txt(p.label, size = 15, weight = FontWeight.Bold)
                        Txt(p.pkg, size = 11, color = Muted)
                    }
                }
                Spacer(Modifier.height(6.dp))
                p.granted.forEach { perm ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Txt(SENSITIVE[perm] ?: perm, Modifier.weight(1f), size = 13, color = RedGlow, weight = FontWeight.Black, italic = true, spacing = 1f)
                        SlantButton("CABUT", filled = false, small = true) { vm.revoke(p.pkg, perm) }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(12.dp)) }
    }
}

// ================= BATERAI =================
@Composable
fun BatteryScreen(vm: AppViewModel) {
    val b = vm.batt
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ScreenTitle("BATERAI", "Kondisi baterai dibaca langsung dari sistem.")
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Ring(b.level, if (b.charging) "MENGISI" else "TERSISA", Modifier.size(220.dp))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("SUHU", String.format("%.1f C", b.temp), ((b.temp - 20.0) / 30.0).toFloat(), Modifier.weight(1f), hot = b.temp >= 40.0)
            StatCard("TEGANGAN", "${b.voltage} mV", (b.voltage / 4600f), Modifier.weight(1f))
        }
        Panel {
            Txt("KESEHATAN", size = 11, color = RedGlow, weight = FontWeight.Bold, spacing = 2.5f)
            Txt(b.health, size = 20, weight = FontWeight.Black, italic = true)
            Spacer(Modifier.height(8.dp))
            SwitchRow(
                "Hemat baterai sistem",
                if (vm.shzReady) "Mengatur mode hemat bawaan Android" else "Butuh Shizuku",
                vm.saverOn
            ) { vm.setSaver(it) }
        }
        Spacer(Modifier.height(12.dp))
    }
}
