package com.imranperatama.speedxz

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings

/**
 * Membaca dan menyalakan pengaturan pengembang Android.
 * Menyalakan langsung hanya bisa kalau Speed Xz sudah diberi izin WRITE_SECURE_SETTINGS (sekali).
 * Kalau belum, tombol membuka halaman pengaturan yang tepat.
 */
object DevSetup {
    private const val WIFI_KEY = "adb_wifi_enabled"

    private fun gi(ctx: Context, key: String): Int = try {
        Settings.Global.getInt(ctx.contentResolver, key, 0)
    } catch (e: Throwable) {
        0
    }

    fun devOptionsOn(ctx: Context): Boolean = gi(ctx, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED) == 1
    fun usbOn(ctx: Context): Boolean = gi(ctx, Settings.Global.ADB_ENABLED) == 1
    fun wifiOn(ctx: Context): Boolean = gi(ctx, WIFI_KEY) == 1

    fun hasSecure(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED

    fun enableAll(ctx: Context): Boolean = try {
        val cr = ctx.contentResolver
        Settings.Global.putInt(cr, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 1)
        Settings.Global.putInt(cr, Settings.Global.ADB_ENABLED, 1)
        if (Build.VERSION.SDK_INT >= 30) Settings.Global.putInt(cr, WIFI_KEY, 1)
        true
    } catch (e: Throwable) {
        false
    }

    /** Daftar intent yang dicoba berurutan sampai ada yang berhasil dibuka. */
    fun intentsFor(kind: String): List<Intent> = when (kind) {
        "about" -> listOf(
            Intent(Settings.ACTION_DEVICE_INFO_SETTINGS),
            Intent(Settings.ACTION_SETTINGS)
        )
        "dev" -> listOf(
            Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS),
            Intent(Settings.ACTION_DEVICE_INFO_SETTINGS),
            Intent(Settings.ACTION_SETTINGS)
        )
        else -> listOf(
            // Sorot langsung baris Debug nirkabel (didukung di banyak HP; kalau tidak, halaman biasa terbuka)
            Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).apply {
                putExtra(":settings:fragment_args_key", "toggle_adb_wireless")
                putExtra(
                    ":settings:show_fragment_args",
                    Bundle().apply { putString(":settings:fragment_args_key", "toggle_adb_wireless") }
                )
            },
            Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS),
            Intent(Settings.ACTION_DEVICE_INFO_SETTINGS),
            Intent(Settings.ACTION_SETTINGS)
        )
    }
}
