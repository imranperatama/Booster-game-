package com.imranperatama.speedxz

import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap

// Palet merah hitam
val Bg = Color(0xFF070708)
val PanelColor = Color(0xFF121214)
val Panel2 = Color(0xFF1C1316)
val Red = Color(0xFFE8142C)
val RedDeep = Color(0xFF8A0B1A)
val RedGlow = Color(0xFFFF4D5E)
val TextMain = Color(0xFFF4EFEF)
val Muted = Color(0xFF9A8F92)
val Good = Color(0xFF3DDC84)
val Warn = Color(0xFFFFB020)

/** false selama game berjalan: semua animasi aplikasi dimatikan supaya GPU penuh untuk game. */
val LocalAnim = compositionLocalOf { true }

/** Animasi singkat, atau langsung (tanpa animasi) saat game berjalan. */
@Composable
fun <T> spec(ms: Int): FiniteAnimationSpec<T> = if (LocalAnim.current) tween(ms) else snap()

/** Jajar genjang miring ke kanan, bentuk khas UI Speed Xz. */
class SlantShape(private val slantDp: Float = 16f) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val s = (slantDp * density.density).coerceAtMost(size.width / 3f)
        val p = Path()
        p.moveTo(s, 0f)
        p.lineTo(size.width, 0f)
        p.lineTo(size.width - s, size.height)
        p.lineTo(0f, size.height)
        p.close()
        return Outline.Generic(p)
    }
}

@Composable
fun Txt(
    text: String,
    modifier: Modifier = Modifier,
    size: Int = 14,
    color: Color = TextMain,
    weight: FontWeight = FontWeight.Normal,
    italic: Boolean = false,
    spacing: Float = 0f
) {
    Text(
        text = text,
        modifier = modifier,
        color = color,
        fontSize = size.sp,
        fontWeight = weight,
        fontStyle = if (italic) FontStyle.Italic else FontStyle.Normal,
        letterSpacing = spacing.sp
    )
}

@Composable
fun SlantButton(
    text: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    filled: Boolean = true,
    small: Boolean = false,
    onClick: () -> Unit
) {
    val shape = SlantShape(if (small) 9f else 16f)
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed && enabled) 0.96f else 1f,
        animationSpec = spec(90),
        label = "press"
    )
    val base = modifier.graphicsLayer {
        scaleX = scale
        scaleY = scale
    }.clip(shape)
    val styled = when {
        !enabled -> base.background(Panel2)
        filled -> base.background(Brush.horizontalGradient(listOf(RedDeep, Red)), shape)
        else -> base.border(1.5.dp, Red, shape)
    }
    Box(
        modifier = styled
            .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
            .padding(horizontal = if (small) 16.dp else 24.dp, vertical = if (small) 8.dp else 15.dp),
        contentAlignment = Alignment.Center
    ) {
        Txt(
            text = text,
            size = if (small) 13 else 17,
            color = if (enabled) TextMain else Muted,
            weight = FontWeight.Black,
            italic = true,
            spacing = 1.2f
        )
    }
}

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(SlantShape(14f))
            .background(PanelColor)
            .padding(start = 22.dp, end = 26.dp, top = 14.dp, bottom = 14.dp),
        content = content
    )
}

private fun DrawScope.slantBar(x0: Float, w: Float, h: Float, color: Color, skew: Float) {
    val width = if (w < skew * 2f) skew * 2f else w
    val p = Path()
    p.moveTo(x0 + skew, 0f)
    p.lineTo(x0 + width, 0f)
    p.lineTo(x0 + width - skew, h)
    p.lineTo(x0, h)
    p.close()
    drawPath(p, color)
}

@Composable
fun Meter(fraction: Float, modifier: Modifier = Modifier, hot: Boolean = false) {
    val f by animateFloatAsState(targetValue = fraction.coerceIn(0f, 1f), animationSpec = spec(600), label = "meter")
    Canvas(modifier.fillMaxWidth().height(9.dp)) {
        val skew = size.height
        slantBar(0f, size.width, size.height, Panel2, skew)
        if (f > 0.01f) slantBar(0f, size.width * f, size.height, if (hot) Warn else Red, skew)
    }
}

/** Busur kecil yang berputar di dalam cincin selama Boost, Pembersih, atau pemindaian bekerja. */
@Composable
private fun BusySweep() {
    val t = rememberInfiniteTransition(label = "sweep")
    val a by t.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing)),
        label = "angle"
    )
    Canvas(Modifier.fillMaxSize()) {
        val inset = size.minDimension * 0.17f
        drawArc(
            color = RedGlow, startAngle = a, sweepAngle = 48f, useCenter = false,
            topLeft = Offset(inset, inset), size = Size(size.width - inset * 2f, size.height - inset * 2f),
            style = Stroke(width = size.minDimension * 0.02f, cap = StrokeCap.Round)
        )
    }
}

@Composable
fun Ring(value: Int, label: String, modifier: Modifier = Modifier, big: Int = 64, busy: Boolean = false) {
    val v = value.coerceIn(0, 100)
    val f by animateFloatAsState(targetValue = v / 100f, animationSpec = spec(900), label = "ring")
    val shown by animateIntAsState(targetValue = v, animationSpec = spec(800), label = "count")
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = size.minDimension * 0.07f
            val topLeft = Offset(stroke / 2f, stroke / 2f)
            val arc = Size(size.width - stroke, size.height - stroke)
            drawArc(
                color = Panel2, startAngle = 135f, sweepAngle = 270f, useCenter = false,
                topLeft = topLeft, size = arc, style = Stroke(width = stroke, cap = StrokeCap.Butt)
            )
            drawArc(
                color = Red.copy(alpha = 0.25f), startAngle = 135f, sweepAngle = 270f * f, useCenter = false,
                topLeft = topLeft, size = arc, style = Stroke(width = stroke * 1.9f, cap = StrokeCap.Butt)
            )
            drawArc(
                color = Red, startAngle = 135f, sweepAngle = 270f * f, useCenter = false,
                topLeft = topLeft, size = arc, style = Stroke(width = stroke, cap = StrokeCap.Butt)
            )
        }
        if (busy && LocalAnim.current) BusySweep()
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Txt(shown.toString(), size = big, weight = FontWeight.Black, italic = true)
            Txt(label, size = 12, color = Muted, weight = FontWeight.Bold, spacing = 2.5f)
        }
    }
}

@Composable
fun AppIcon(pkg: String, size: Dp = 44.dp) {
    val ctx = LocalContext.current
    val bmp = remember(pkg) {
        try {
            ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
        } catch (e: Throwable) {
            null
        }
    }
    if (bmp != null) {
        Image(bitmap = bmp, contentDescription = null, modifier = Modifier.size(size).clip(RoundedCornerShape(10.dp)))
    } else {
        Box(Modifier.size(size).clip(RoundedCornerShape(10.dp)).background(Panel2))
    }
}

@Composable
fun StatCard(title: String, value: String, fraction: Float, modifier: Modifier = Modifier, hot: Boolean = false) {
    Column(
        modifier = modifier
            .clip(SlantShape(12f))
            .background(PanelColor)
            .padding(start = 18.dp, end = 22.dp, top = 12.dp, bottom = 14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Txt(title, size = 11, color = Muted, weight = FontWeight.Bold, spacing = 2f)
        Txt(value, size = 16, weight = FontWeight.Bold, italic = true)
        Meter(fraction, hot = hot)
    }
}


// ---------------- Api ----------------
private val FireOuter = Color(0xFFFF3B1F)
private val FireBlue = Color(0xFF2F7BFF)
private val FireCore = Color(0xFFBFE4FF)

/** Satu lidah api berbentuk tetes, dari titik dasar ke arah (dx, dy) sepanjang h. */
private fun DrawScope.tongue(base: Offset, dx: Float, dy: Float, w: Float, h: Float, sway: Float, color: Color) {
    if (h <= 1f) return
    val px = -dy
    val py = dx
    val lx = base.x - px * w / 2f
    val ly = base.y - py * w / 2f
    val rx = base.x + px * w / 2f
    val ry = base.y + py * w / 2f
    val tx = base.x + dx * h + px * sway
    val ty = base.y + dy * h + py * sway
    val p = Path()
    p.moveTo(lx, ly)
    p.quadraticBezierTo(lx + dx * h * 0.6f, ly + dy * h * 0.6f, tx, ty)
    p.quadraticBezierTo(rx + dx * h * 0.6f, ry + dy * h * 0.6f, rx, ry)
    p.close()
    drawPath(p, color)
}

/** Kedipan api: dua gelombang dengan kelipatan bulat supaya putarannya mulus tanpa loncatan. */
private fun flick(ph: Float, i: Int): Float {
    val a = 0.5f + 0.5f * sin(ph * 2f + i * 1.9f)
    val b = 0.5f + 0.5f * sin(ph * 3f + i * 0.7f)
    return 0.4f + 0.6f * (a * 0.6f + b * 0.4f)
}

private fun DrawScope.flameLayers(base: Offset, dx: Float, dy: Float, w: Float, hMax: Float, f: Float, sway: Float) {
    tongue(base, dx, dy, w, hMax * f, sway, FireOuter.copy(alpha = 0.6f))
    tongue(base, dx, dy, w * 0.78f, hMax * f * 0.74f, sway * 0.7f, FireBlue.copy(alpha = 0.85f))
    tongue(base, dx, dy, w * 0.45f, hMax * f * 0.42f, sway * 0.4f, FireCore.copy(alpha = 0.9f))
}

/** Lingkaran api di sekeliling cincin skor. Diam (tanpa gerak) selama game berjalan. */
@Composable
fun FlameRing(radius: Dp, power: Float, modifier: Modifier = Modifier) {
    val anim = LocalAnim.current
    val t = rememberInfiniteTransition(label = "fireRing")
    val phase = t.animateFloat(
        initialValue = 0f,
        targetValue = 6.2831855f,
        animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing)),
        label = "fireRingPhase"
    )
    Canvas(modifier) {
        val ph = if (anim) phase.value else 1.3f
        val cx = size.width / 2f
        val cy = size.height / 2f
        val r = radius.toPx()
        val n = 30
        val w = (2f * 3.1415927f * r / n) * 1.35f
        val hMax = (size.minDimension / 2f - r).coerceAtLeast(8f)
        for (i in 0 until n) {
            val a = i * 6.2831855f / n
            val dx = cos(a)
            val dy = sin(a)
            val base = Offset(cx + dx * r, cy + dy * r)
            flameLayers(base, dx, dy, w, hMax, flick(ph, i) * power, hMax * 0.18f * sin(ph + i * 0.9f))
        }
    }
}

/** Deretan api yang naik dari tepi atas tombol Boost. */
@Composable
fun FlameBar(power: Float, modifier: Modifier = Modifier) {
    val anim = LocalAnim.current
    val t = rememberInfiniteTransition(label = "fireBar")
    val phase = t.animateFloat(
        initialValue = 0f,
        targetValue = 6.2831855f,
        animationSpec = infiniteRepeatable(tween(2000, easing = LinearEasing)),
        label = "fireBarPhase"
    )
    Canvas(modifier) {
        val ph = if (anim) phase.value else 0.9f
        val n = 26
        val step = size.width / n
        val hMax = size.height
        for (i in 0 until n) {
            val base = Offset(step * (i + 0.5f), size.height)
            flameLayers(base, 0f, -1f, step * 1.5f, hMax, flick(ph, i) * power, hMax * 0.16f * sin(ph + i * 0.9f))
        }
    }
}
