package com.imranperatama.speedxz

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap

// Palet merah hitam
val Bg = Color(0xFF070708)
val PanelColor = Color(0xFF121214)
val Panel2 = Color(0xFF1C1316)
val Red = Color(0xFFE8142C)
val RedDeep = Color(0xFF8A0B1A)
val RedGlow = Color(0xFFFF4D5E)
val TextMain = Color(0xFFF4EFEF)
val Muted = Color(0xFF9A8F92)
val Good = Color(0xFF3DDC84)
val Warn = Color(0xFFFFB020)

/** Jajar genjang miring ke kanan, bentuk khas UI Speed Xz. */
class SlantShape(private val slantDp: Float = 16f) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val s = (slantDp * density.density).coerceAtMost(size.width / 3f)
        val p = Path()
        p.moveTo(s, 0f)
        p.lineTo(size.width, 0f)
        p.lineTo(size.width - s, size.height)
        p.lineTo(0f, size.height)
        p.close()
        return Outline.Generic(p)
    }
}

@Composable
fun Txt(
    text: String,
    modifier: Modifier = Modifier,
    size: Int = 14,
    color: Color = TextMain,
    weight: FontWeight = FontWeight.Normal,
    italic: Boolean = false,
    spacing: Float = 0f
) {
    Text(
        text = text,
        modifier = modifier,
        color = color,
        fontSize = size.sp,
        fontWeight = weight,
        fontStyle = if (italic) FontStyle.Italic else FontStyle.Normal,
        letterSpacing = spacing.sp
    )
}

@Composable
fun SlantButton(
    text: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    filled: Boolean = true,
    small: Boolean = false,
    onClick: () -> Unit
) {
    val shape = SlantShape(if (small) 9f else 16f)
    val base = modifier.clip(shape)
    val styled = when {
        !enabled -> base.background(Panel2)
        filled -> base.background(Brush.horizontalGradient(listOf(RedDeep, Red)), shape)
        else -> base.border(1.5.dp, Red, shape)
    }
    Box(
        modifier = styled
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = if (small) 16.dp else 24.dp, vertical = if (small) 8.dp else 15.dp),
        contentAlignment = Alignment.Center
    ) {
        Txt(
            text = text,
            size = if (small) 13 else 17,
            color = if (enabled) TextMain else Muted,
            weight = FontWeight.Black,
            italic = true,
            spacing = 1.2f
        )
    }
}

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(SlantShape(14f))
            .background(PanelColor)
            .padding(start = 22.dp, end = 26.dp, top = 14.dp, bottom = 14.dp),
        content = content
    )
}

private fun DrawScope.slantBar(x0: Float, w: Float, h: Float, color: Color, skew: Float) {
    val width = if (w < skew * 2f) skew * 2f else w
    val p = Path()
    p.moveTo(x0 + skew, 0f)
    p.lineTo(x0 + width, 0f)
    p.lineTo(x0 + width - skew, h)
    p.lineTo(x0, h)
    p.close()
    drawPath(p, color)
}

@Composable
fun Meter(fraction: Float, modifier: Modifier = Modifier, hot: Boolean = false) {
    val f by animateFloatAsState(targetValue = fraction.coerceIn(0f, 1f), animationSpec = tween(600), label = "meter")
    Canvas(modifier.fillMaxWidth().height(9.dp)) {
        val skew = size.height
        slantBar(0f, size.width, size.height, Panel2, skew)
        if (f > 0.01f) slantBar(0f, size.width * f, size.height, if (hot) Warn else Red, skew)
    }
}

@Composable
fun Ring(value: Int, label: String, modifier: Modifier = Modifier, big: Int = 64) {
    val f by animateFloatAsState(targetValue = value.coerceIn(0, 100) / 100f, animationSpec = tween(900), label = "ring")
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = size.minDimension * 0.07f
            val topLeft = Offset(stroke / 2f, stroke / 2f)
            val arc = Size(size.width - stroke, size.height - stroke)
            drawArc(
                color = Panel2, startAngle = 135f, sweepAngle = 270f, useCenter = false,
                topLeft = topLeft, size = arc, style = Stroke(width = stroke, cap = StrokeCap.Butt)
            )
            drawArc(
                color = Red.copy(alpha = 0.25f), startAngle = 135f, sweepAngle = 270f * f, useCenter = false,
                topLeft = topLeft, size = arc, style = Stroke(width = stroke * 1.9f, cap = StrokeCap.Butt)
            )
            drawArc(
                color = Red, startAngle = 135f, sweepAngle = 270f * f, useCenter = false,
                topLeft = topLeft, size = arc, style = Stroke(width = stroke, cap = StrokeCap.Butt)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Txt(value.toString(), size = big, weight = FontWeight.Black, italic = true)
            Txt(label, size = 12, color = Muted, weight = FontWeight.Bold, spacing = 2.5f)
        }
    }
}

@Composable
fun AppIcon(pkg: String, size: Dp = 44.dp) {
    val ctx = LocalContext.current
    val bmp = remember(pkg) {
        try {
            ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
        } catch (e: Throwable) {
            null
        }
    }
    if (bmp != null) {
        Image(bitmap = bmp, contentDescription = null, modifier = Modifier.size(size).clip(RoundedCornerShape(10.dp)))
    } else {
        Box(Modifier.size(size).clip(RoundedCornerShape(10.dp)).background(Panel2))
    }
}

@Composable
fun StatCard(title: String, value: String, fraction: Float, modifier: Modifier = Modifier, hot: Boolean = false) {
    Column(
        modifier = modifier
            .clip(SlantShape(12f))
            .background(PanelColor)
            .padding(start = 18.dp, end = 22.dp, top = 12.dp, bottom = 14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Txt(title, size = 11, color = Muted, weight = FontWeight.Bold, spacing = 2f)
        Txt(value, size = 16, weight = FontWeight.Bold, italic = true)
        Meter(fraction, hot = hot)
    }
}
