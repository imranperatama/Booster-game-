# Speed Xz x Imran Peratama

Booster game Android buatan sendiri. Semua fungsi memakai Shizuku (izin sistem tingkat ADB/root).

## Fungsi nyata
- Info HP: merek, tipe, Android, chip, jumlah inti, refresh rate (dibaca dari sistem)
- RAM, penyimpanan, suhu dan level baterai, beban CPU: dibaca langsung, diperbarui tiap 2,5 detik
- Boost: menutup aplikasi pihak ketiga yang sedang jalan (am force-stop) dan proses cache (am kill-all)
- Mode Game: boost, mode performa game (cmd game), jangan ganggu, animasi cepat, kunci refresh rate, performa tetap, lalu buka game
- Pembersih: pm trim-caches untuk cache semua aplikasi, plus bersihkan log sistem
- Keamanan: daftar aplikasi dengan izin kamera, mikrofon, lokasi, SMS, kontak; cabut izin (pm revoke)
- Baterai: kesehatan, suhu, tegangan, hemat baterai sistem

## Jendela Xz di dalam game (v1.2)
Tekan MAIN di tab GAME. Speed Xz menutup aplikasi non-sistem, menerapkan pengaturan performa, membuka game, lalu menampilkan jendela mengambang:
- Gelembung logo Xz di tepi layar: geser bebas, ketuk untuk membuka panel (logo Xz, FPS perkiraan, CPU, RAM bebas, suhu, thermal, ping, tombol Boost Ulang, Jangan Ganggu, Sembunyikan, Akhiri Sesi).
- Tidak disentuh 10 detik, atau ditarik ke pojok layar: gelembung menyelinap ke tepi dan hilang. Garis merah tipis tersisa di tepi.
- Tarik garis merah ke arah tengah (atau ketuk) untuk memunculkan gelembung lagi. Sisi kiri/kanan diatur di tab GAME.
- Selama sesi, aplikasi non-sistem yang hidup lagi ditutup tiap sekitar 16 detik. Mode ketat (bawaan) menutup semuanya, termasuk WhatsApp dan VPN; matikan untuk memakai daftar lindung.
- Sesi berakhir saat game ditutup (butuh Shizuku untuk mendeteksi) atau lewat tombol Akhiri Sesi. Semua pengaturan dikembalikan otomatis, dan ringkasan tersimpan di Riwayat Sesi.
- FPS dibaca dari SurfaceFlinger lewat Shizuku. Jika HP tidak menyediakannya, tampil N/A.

## Cara pakai
Buka tab SETUP di aplikasi. Isinya 6 langkah dengan status otomatis dan tombol yang membuka halaman pengaturan HP yang tepat:
1. Pasang Shizuku
2. Aktifkan Opsi Pengembang (ketuk Nomor build 7 kali)
3. Nyalakan Debug Nirkabel (atau Debug USB)
4. Mulai Shizuku (Mulai lewat Debug nirkabel, pairing sekali)
5. Izinkan Speed Xz
6. Nyala otomatis (opsional): izin pengaturan aman sekali, supaya tombol NYALAKAN DEBUG OTOMATIS bisa menyalakan Opsi Pengembang dan Debug sendiri

Tanpa Shizuku semua tombol tetap bisa ditekan: Boost memakai pembersih proses latar Android, Pembersih membuka layar cache sistem, CABUT membuka halaman izin aplikasi.
Intro video diputar sekali pada peluncuran pertama; putar ulang dari tab SETUP.

## Build
Lihat main.yml (GitHub Actions). Build manual: `gradle assembleRelease` (Gradle 8.9, JDK 17, Android SDK 35).

Kunci tanda tangan ada di `app/keystore/speedxz.jks` (sandi di `app/build.gradle.kts`). Karena kuncinya tetap, APK baru bisa dipasang menimpa yang lama.
