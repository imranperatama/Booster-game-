# Speed Xz x Imran Peratama

Booster game Android buatan sendiri. Semua fungsi memakai Shizuku (izin sistem tingkat ADB/root).

## Fungsi nyata
- Info HP: merek, tipe, Android, chip, jumlah inti, refresh rate (dibaca dari sistem)
- RAM, penyimpanan, suhu dan level baterai, beban CPU: dibaca langsung, diperbarui tiap 2,5 detik
- Boost: menutup aplikasi pihak ketiga yang sedang jalan (am force-stop) dan proses cache (am kill-all)
- Mode Game: boost, mode performa game (cmd game), jangan ganggu, animasi cepat, kunci refresh rate, performa tetap, lalu buka game
- Pembersih: pm trim-caches untuk cache semua aplikasi, plus bersihkan log sistem
- Keamanan: daftar aplikasi dengan izin kamera, mikrofon, lokasi, SMS, kontak; cabut izin (pm revoke)
- Baterai: kesehatan, suhu, tegangan, hemat baterai sistem

## Cara pakai
Buka tab SETUP di aplikasi. Isinya 6 langkah dengan status otomatis dan tombol yang membuka halaman pengaturan HP yang tepat:
1. Pasang Shizuku
2. Aktifkan Opsi Pengembang (ketuk Nomor build 7 kali)
3. Nyalakan Debug Nirkabel (atau Debug USB)
4. Mulai Shizuku (Mulai lewat Debug nirkabel, pairing sekali)
5. Izinkan Speed Xz
6. Nyala otomatis (opsional): izin pengaturan aman sekali, supaya tombol NYALAKAN DEBUG OTOMATIS bisa menyalakan Opsi Pengembang dan Debug sendiri

Tanpa Shizuku semua tombol tetap bisa ditekan: Boost memakai pembersih proses latar Android, Pembersih membuka layar cache sistem, CABUT membuka halaman izin aplikasi.
Intro video diputar sekali pada peluncuran pertama; putar ulang dari tab SETUP.

## Build
Lihat main.yml (GitHub Actions). Build manual: `gradle assembleRelease` (Gradle 8.9, JDK 17, Android SDK 35).

Kunci tanda tangan ada di `app/keystore/speedxz.jks` (sandi di `app/build.gradle.kts`). Karena kuncinya tetap, APK baru bisa dipasang menimpa yang lama.
