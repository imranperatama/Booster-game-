# Speed Xz x Imran Peratama

Booster game Android buatan sendiri. Semua fungsi memakai Shizuku (izin sistem tingkat ADB/root).

## Fungsi nyata
- Info HP: merek, tipe, Android, chip, jumlah inti, refresh rate (dibaca dari sistem)
- RAM, penyimpanan, suhu dan level baterai, beban CPU: dibaca langsung, diperbarui tiap 2,5 detik
- Boost: menutup aplikasi pihak ketiga yang sedang jalan (am force-stop) dan proses cache (am kill-all)
- Mode Game: boost, mode performa game (cmd game), jangan ganggu, animasi cepat, kunci refresh rate, performa tetap, lalu buka game
- Pembersih: pm trim-caches untuk cache semua aplikasi, plus bersihkan log sistem
- Keamanan: daftar aplikasi dengan izin kamera, mikrofon, lokasi, SMS, kontak; cabut izin (pm revoke)
- Baterai: kesehatan, suhu, tegangan, hemat baterai sistem

## Yang baru di v1.6
- AI: jika model utama sibuk (503), kena batas (429), tidak ada (404), atau terlalu lama, otomatis pindah ke model cadangan (gemini-3.6-flash, gemini-3.5-flash-lite, gemini-2.5-flash). Model yang baru gagal dilewati 2 menit. Panel menampilkan model yang menjawab. Kesalahan key dan internet langsung dilaporkan. Tombol TES AI di tab SETUP.
- Intro: video kembali penuh (tidak lagi dipotong miring), diencode ulang 1080x1920 dengan kualitas tinggi. Kemiringan hanya pada teks, garis aksen, dan tombol LEWATI.

## Yang baru di v1.5
- AI tidak lagi lama menjawab: model Gemini 3.x berpikir dulu secara bawaan (tingkat menengah), sekarang diturunkan ke rendah. Jika model menolak pengaturan itu, diulang tanpa pengaturan. Jika timeout, diulang sekali dengan pertanyaan terakhir saja. Status menampilkan detik berjalan.
- Intro video baru (video dari pengguna, dimiringkan dengan bingkai merah), diputar setiap aplikasi dibuka. Tombol LEWATI atau Kembali melewati intro, lalu layar memudar ke aplikasi.
- Efek api biru dan merah di cincin skor dan tombol Boost di Beranda; makin besar saat Boost berjalan. Efek berhenti bergerak saat game berjalan.

## Yang baru di v1.4
- Perbaikan build: import animateFloat di Ui.kt yang hilang (error "Unresolved reference animateFloat").
- AI hanya ada di dalam game. Tab AI di aplikasi dihapus. Isi API key Gemini sekali di tab SETUP (kolom Kunci AI).
- Jendela Xz di game punya tiga tab:
  - PANTAU: FPS, CPU, suhu CPU, RAM bebas dan terpakai (MB), suhu baterai, ping, sinyal (Wi-Fi atau seluler), thermal, plus tombol Boost Ulang, Jangan Ganggu, Redup, Bersih Cache.
  - AI: chat dengan Gemini yang membaca angka HP langsung, dengan tombol cepat Analisis, Panas?, Lag?, Sinyal?. Papan ketik muncul hanya saat mengetik; jendela pindah ke atas lalu kembali normal setelah kirim.
  - OPTIMAL: Optimalkan Kinerja Max, Optimalkan Sinyal, dan Auto Pintar.
- Optimalkan Kinerja Max (pintar): periksa suhu, RAM, dan hemat baterai dulu. Tutup proses latar; bersihkan cache hanya jika RAM bebas di bawah 25%; aktifkan mode performa game; kecualikan game dari penghemat daya; kunci performa tetap hanya jika HP tidak panas. Semua dikembalikan saat sesi berakhir.
- Optimalkan Sinyal: ukur ping sebelum dan sesudah, tutup aplikasi yang berebut jaringan, matikan penghemat data, mode latensi rendah Wi-Fi, siagakan data seluler sebagai cadangan jika Wi-Fi lemah. Sinyal radio sendiri tidak bisa dinaikkan aplikasi mana pun, dan laporan menyebut itu.
- Auto Pintar (bawaan aktif): tiap menit, jika RAM bebas di bawah 12% maka tutup proses latar dan bersihkan cache; jika HP panas maka lepas kunci performa, dan kunci lagi saat sudah dingin.

## Yang baru di v1.3
- Penutup aplikasi latar urut dari yang paling rakus RAM (ps lewat Shizuku), diulang tiap 30 detik selama sesi. Aplikasi yang dilindungi (mode tidak ketat) dikurangi memorinya lewat send-trim-memory, tidak ditutup. Tanpa Shizuku: killBackgroundProcesses.
- Jangan Ganggu lewat NotificationManager (hanya alarm yang berbunyi), perlu akses di SETUP langkah 9. Dikembalikan otomatis saat sesi berakhir.
- SETUP langkah 8: Tanpa Pembatasan baterai untuk Speed Xz, supaya layanan pengawas game tidak dimatikan Android.
- Pemantau suhu: baterai dan zona thermal CPU/SoC/GPU (/sys/class/thermal lewat Shizuku). Di atas 43 C (baterai) atau 75 C (CPU), gelembung Xz berkedip merah, panel menampilkan peringatan, dan muncul notifikasi.
- Jendela Xz: panel dua kolom di layar landscape, tombol Boost Ulang, Jangan Ganggu, Redup Layar, Bersih Cache, dan tiga tombol AI sekali ketuk (Analisis, Kenapa Panas, Kenapa Lag). Panel hanya diperbarui saat terbuka, pemantau melambat saat panel tertutup, dan jendela dibuat dari View bawaan Android (bukan Compose) tanpa animasi.
- AI Gemini (model dan API key kamu isi sendiri, bawaan gemini-3.8-flash). Tanpa library tambahan. Sejak v1.4 hanya muncul di jendela Xz saat main.
- Animasi ringan di aplikasi (transisi tab, efek tekan, skor menghitung naik, putaran saat Boost). Semuanya otomatis mati selama sesi game berjalan (isGameRunning).

## Jendela Xz di dalam game (v1.2)
Tekan MAIN di tab GAME. Speed Xz menutup aplikasi non-sistem, menerapkan pengaturan performa, membuka game, lalu menampilkan jendela mengambang:
- Gelembung logo Xz di tepi layar: geser bebas, ketuk untuk membuka panel (logo Xz, FPS perkiraan, CPU, RAM bebas, suhu, thermal, ping, tombol Boost Ulang, Jangan Ganggu, Sembunyikan, Akhiri Sesi).
- Tidak disentuh 10 detik, atau ditarik ke pojok layar: gelembung menyelinap ke tepi dan hilang. Garis merah tipis tersisa di tepi.
- Tarik garis merah ke arah tengah (atau ketuk) untuk memunculkan gelembung lagi. Sisi kiri/kanan diatur di tab GAME.
- Selama sesi, aplikasi non-sistem yang hidup lagi ditutup tiap sekitar 16 detik. Mode ketat (bawaan) menutup semuanya, termasuk WhatsApp dan VPN; matikan untuk memakai daftar lindung.
- Sesi berakhir saat game ditutup (butuh Shizuku untuk mendeteksi) atau lewat tombol Akhiri Sesi. Semua pengaturan dikembalikan otomatis, dan ringkasan tersimpan di Riwayat Sesi.
- FPS dibaca dari SurfaceFlinger lewat Shizuku. Jika HP tidak menyediakannya, tampil N/A.

## v1.7: Mode Bantai, musik, pelatih game
- MODE BANTAI (tab OPTIMAL di jendela Xz): Auto Pintar, Jangan Ganggu, dan Kinerja Max sekali tekan.
- Tab MUSIK dan chat AI: ketik "putarkan saya lagu manusia kuat atau bebas". Dicari di lagu HP dulu, kalau tidak ada diminta ke aplikasi musik terpasang (Spotify, YouTube Music, dll), lalu game dibuka lagi ke depan.
- Perintah lagu, jeda, lanjut, berikutnya, sebelumnya dan catatan kalah/menang jalan tanpa API key.
- Pelatih game: tanya STRATEGI, SENJATA, BERTAHAN, ANALISIS. Ceritakan "aku kalah karena ..." dan pelajaran disimpan di HP per game, lalu dipakai di jawaban berikutnya (bukan melatih ulang model). "lupakan pelajaran" menghapusnya.
- Izin musik ada di SETUP langkah 10.
- Perbaikan: Jangan Ganggu yang dinyalakan dari jendela Xz kini dikembalikan saat sesi berakhir.

## v1.8: musik internet
- Audius dipakai lebih dulu tanpa API key. Jamendo opsional.
- KINERJA MAX dan MODE BANTAI membatasi aplikasi non-sistem di latar (bucket restricted + larang jalan di latar), dikembalikan saat sesi selesai. Aplikasi sistem tidak disentuh.
- Jamendo (gratis, tanpa iklan, musik berlisensi bebas): isi Client ID di SETUP. Urutan cari: lagu HP, lalu Jamendo.
- App musik lain (YT Music, Spotify, dll) tidak lagi dibuka otomatis.

## Cara pakai
Buka tab SETUP di aplikasi. Isinya 6 langkah dengan status otomatis dan tombol yang membuka halaman pengaturan HP yang tepat:
1. Pasang Shizuku
2. Aktifkan Opsi Pengembang (ketuk Nomor build 7 kali)
3. Nyalakan Debug Nirkabel (atau Debug USB)
4. Mulai Shizuku (Mulai lewat Debug nirkabel, pairing sekali)
5. Izinkan Speed Xz
6. Nyala otomatis (opsional): izin pengaturan aman sekali, supaya tombol NYALAKAN DEBUG OTOMATIS bisa menyalakan Opsi Pengembang dan Debug sendiri

Tanpa Shizuku semua tombol tetap bisa ditekan: Boost memakai pembersih proses latar Android, Pembersih membuka layar cache sistem, CABUT membuka halaman izin aplikasi.
Intro video diputar sekali pada peluncuran pertama; putar ulang dari tab SETUP.

## Build
Lihat main.yml (GitHub Actions). Build manual: `gradle assembleRelease` (Gradle 8.9, JDK 17, Android SDK 35).

Kunci tanda tangan ada di `app/keystore/speedxz.jks` (sandi di `app/build.gradle.kts`). Karena kuncinya tetap, APK baru bisa dipasang menimpa yang lama.
